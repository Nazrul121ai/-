const $app = document.getElementById('app');
let tab = 'home', stack = [];

const esc = s => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const bn = n => LANG === 'en' ? String(n) : String(n).replace(/\d/g, d => '০১২৩৪৫৬৭৮৯'[d]);
const load = (k, def) => { try { return JSON.parse(localStorage.getItem(k)) || def; } catch (e) { return def; } };

// ---------- ভয়েস ----------
function speak(text) {
  if (!('speechSynthesis' in window)) { alert('এই ডিভাইসে ভয়েস সাপোর্ট নেই।'); return; }
  speechSynthesis.cancel();
  const u = new SpeechSynthesisUtterance(text); u.lang = /[\u0980-\u09FF]/.test(text) ? 'bn-BD' : 'en-US'; u.rate = .9;
  speechSynthesis.speak(u);
}

// ---------- কাঠামো ----------
function nav() {
  const items = [['home','🏠','হোম'],['study','🎓','প্রস্তুতি'],['quiz','📋','মডেল টেস্ট'],['job','💼','চাকরি'],['profile','👤','প্রোফাইল']];
  return '<div class="nav">' + items.map(i =>
    `<div class="${tab===i[0]?'on':''}" onclick="go('${i[0]}')"><b>${i[1]}</b>${i[2]}</div>`).join('') + '</div>';
}
function drawer() {
  const m = [['test','🛞','ড্রাইভিং টেস্টের প্রশ্ন'],['book','📘','ড্রাইভিং বই'],['road','🛣️','রাস্তার নিয়ম'],['signs','🛑','ট্রাফিক সাইন'],
    ['lessons','🎓','ড্রাইভ লেসন'],['paper','📰','সাপ্তাহিক চাকরির পত্রিকা'],['account','☁️','লগইন ও ব্যাকআপ'],['profile','👤','আমার প্রোফাইল'],...(CLOUD_ON() ? [['board','📢','নোটিশ বোর্ড'],['community','💬','কমিউনিটি'],['seeker','🪪','চাকরিপ্রার্থী আইডি']] : []),['admin','🛡️','অ্যাডমিন প্যানেল'],...(PAID_ENABLED ? [['courses','🎓','পেইড কোর্স']] : []),['parts','⚙️','গাড়ির যন্ত্রাংশ'],['learn','🚗','গাড়ি চালানো শিখুন'],['ledger','💰','আয়-খরচ খাতা'],['remind','⏰','রিমাইন্ডার'],['sos','🆘','জরুরি নম্বর'],['hacks','🛠️','দ্রুত সমাধান'],['govguide','🏛️','সরকারি চাকরির প্রস্তুতি'],['govqa','📝','সরকারি চাকরির প্রশ্ন ও সমাধান'],['licguide','🪪','লাইসেন্স করার নিয়ম'],['idp','🌐','আন্তর্জাতিক লাইসেন্স (IDP)'],['warn','🚨','ড্যাশবোর্ড বাতি'],['police','👮','পুলিশের ইশারা'],['signquiz','🧠','সাইন চিনুন কুইজ'],['care','🔧','গাড়ির যত্ন'],['cockpit','🎛️','ককপিট গাইড'],['links','🔗','দরকারি লিংক'],['contact','📞','যোগাযোগ'],['share','📤','অ্যাপ শেয়ার করুন'],['quiz','📋','মডেল টেস্ট'],['jobprep','💼','চাকরির প্রস্তুতি'],['job','🧑‍✈️','ড্রাইভিং জব'],['cv','🪪','ডিজিটাল সিভি'],['lang','🌐',LANG === 'bn' ? 'ভাষা: English' : 'Language: বাংলা']];
  const byId = {}; m.forEach(i => { byId[i[0]] = i; });
  const DG = [['⭐ আমার অ্যাকাউন্ট ও চাকরি', ['account', 'profile', 'seeker', 'govguide', 'govqa', 'admin']],
    ['💼 চাকরি', ['job', 'jobprep', 'paper', 'cv']],
    ['📚 শেখা ও পরীক্ষা', ['test', 'book', 'road', 'signs', 'lessons', 'quiz', 'signquiz', 'police', 'warn', 'cockpit', 'licguide', 'idp']],
    ['🚗 গাড়ি', ['parts', 'learn', 'care', 'hacks']],
    ['📒 আমার খাতা', ['ledger', 'remind', 'sos']], ['💬 কমিউনিটি ও নোটিশ', ['board', 'community', 'contact']],
    ['⚙️ অ্যাপ', ['courses', 'links', 'share', 'lang']]];
  const used = new Set(); let html = '';
  const row = i => `<div class="it" onclick="toggleDrawer();open_('${i[0]}')"><span>${i[1]}</span>${i[2]}</div>`;
  DG.forEach(g => { const items = g[1].map(id => byId[id]).filter(Boolean); items.forEach(i => used.add(i[0])); if (items.length) html += `<div class="dg">${g[0]}</div>` + items.map(row).join(''); });
  const other = m.filter(i => !used.has(i[0])); if (other.length) html += '<div class="dg">অন্যান্য</div>' + other.map(row).join('');
  const ci = typeof cloudInfo === 'function' ? cloudInfo() : null;
  return `<div class="drawer-bg" id="dbg" onclick="toggleDrawer()"></div><div class="drawer" id="drw">
    <div class="dh"><div class="dt">${appLogoHtml()}<div><div class="dn">${esc(appName())}</div><div class="ds">${esc(appSub())}</div></div></div>
      <div class="du" onclick="toggleDrawer();open_('account')"><span>${ci ? '👤 ' + esc(ci.name || ci.id) : '👤 অতিথি • লগইন করুন'}</span><span>›</span></div></div>` + html + `<div class="it" onclick="exitNow()"><span>🚪</span>অ্যাপ থেকে বের হন</div><div class="foot">${esc(appName())}</div></div>`;
}
function toggleDrawer() {
  const d = document.getElementById('drw'), b = document.getElementById('dbg');
  const o = d.classList.toggle('open'); b.style.display = o ? 'block' : 'none';
}
function render(html) { $app.innerHTML = html + drawer(); window.scrollTo(0, 0); }
function hero(ic, t, sub) { return `<div class="hero"><div class="hi">${ic}</div><div><b>${esc(t)}</b>${sub ? `<small>${esc(sub)}</small>` : ''}</div></div>`; }
function pageHead(t, back = true) {
  return `<div class="page-h">${back ? '<button class="back" onclick="back()">←</button>' : ''}<h2 style="flex:1">${esc(t)}</h2><button class="back" style="font-size:20px" aria-label="হোম" onclick="home()">🏠</button><button class="back" aria-label="মেনু" onclick="toggleDrawer()">☰</button></div>`;
}
function back() { const p = stack.pop(); if (p) p(); else home(); }
function push(fn) { stack.push(fn); }

// ---------- হোম ----------
let tipIdx = Math.floor(Math.random() * TIPS.length);
const SHORT = {intjob:'বিদেশে চাকরি', govqa:'সরকারি চাকরির প্রশ্ন', govguide:'সরকারি চাকরি গাইড', paper:'সাপ্তাহিক পত্রিকা', idp:'আন্তর্জাতিক লাইসেন্স', licguide:'লাইসেন্সের নিয়ম', signquiz:'সাইন কুইজ', roadtest:'রোড টেস্ট', jobprep:'চাকরির প্রস্তুতি', test:'লিখিত প্রশ্ন', book:'ড্রাইভিং বই', road:'রাস্তার নিয়ম', warn:'ড্যাশবোর্ড বাতি', police:'পুলিশের ইশারা', care:'গাড়ির যত্ন', cockpit:'ককপিট গাইড', learn:'গাড়ি চালানো শিখুন', hacks:'দ্রুত সমাধান', parts:'গাড়ির যন্ত্রাংশ', ledger:'আয়-খরচ খাতা', remind:'রিমাইন্ডার', sos:'জরুরি নম্বর', links:'দরকারি লিংক', lessons:'ড্রাইভ লেসন', job:'ড্রাইভিং জব', signs:'ট্রাফিক সাইন', gk:'সাধারণ জ্ঞান'};
const GROUPS = [
  ['চাকরি ও প্রস্তুতি', ['job','intjob','paper','govguide','govqa','jobprep','bangla','english','math','gk']],
  ['লাইসেন্স ও পরীক্ষা', ['licguide','test','signs','signquiz','roadtest','police','idp','book','road']],
  ['গাড়ি চেনা ও চালানো', ['learn','parts','warn','cockpit','care','hacks','lessons']],
  ['কমিউনিটি ও যোগাযোগ', ['board','community','seeker','contact']],
  ['আমার খাতা', ['ledger','remind','sos','links']]
];
const QUICK = [['home','🏠','হোম'],['paper','📰','সাপ্তাহিক পত্রিকা'],['govguide','🏛️','সরকারি চাকরি'],['licguide','🪪','লাইসেন্সের নিয়ম'],['job','💼','চাকরি']];
function tile(c) { const o = tileOv(c.id); if (o.hide) return ''; return `<div class="tile" onclick="open_('${c.id}')"><div class="ti" style="background:${c.color}26">${esc(o.ic || c.ic)}</div><span>${esc(o.name || SHORT[c.id] || c.name)}</span></div>`; }
const bismOn = () => { try { return APPCFG().bism !== false; } catch (e) { return true; } };
function dayIdx() { const d = new Date(); return Math.floor(new Date(d.getFullYear(), d.getMonth(), d.getDate()) / 864e5); }
function dailyCard() {
  const q = QUIZ[dayIdx() % QUIZ.length], st = load('daily', {}), ans = st.d === todayISO() ? st.a : -1;
  return `<div class="daily" id="daily"><div class="dh2"><b>আজকের প্রশ্ন</b><span>${ans >= 0 ? (ans === q[2] ? '✅ সঠিক' : '❌ ভুল') : ''}</span></div><div class="dq">${esc(q[0])}</div>` +
    q[1].map((o, i) => `<div class="opt ${ans >= 0 ? (i === q[2] ? 'ok' : (i === ans ? 'no' : '')) : ''}" onclick="dailyPick(${i})">${esc(o)}</div>`).join('') + '</div>';
}
function dailyPick(i) {
  const st = load('daily', {}); if (st.d === todayISO()) return;
  localStorage.setItem('daily', JSON.stringify({d: todayISO(), a: i}));
  document.getElementById('daily').outerHTML = dailyCard();
}
function homeGroups(includeHidden) {
  const used = new Set(); GROUPS.forEach(g => g[1].forEach(x => used.add(x)));
  const known = ['quiz','signquiz','links','share','paper','parts','learn','hacks','ledger','remind','sos','govqa','signs','lessons','job','intjob','cv','jobprep','roadtest','account','board','community','seeker','contact'];
  if (PAID_ENABLED) known.push('courses');
  const canOpen = id => known.includes(id) || INFO[id] || STUDY[id] || QA[id];
  const shown = new Set(GROUPS.flatMap(g => g[1].map(id => (CATS.find(c => c.id === id) || {}).name)));
  const rest = CATS.filter((c, i) => !used.has(c.id) && canOpen(c.id) && !shown.has(c.name) && CATS.findIndex(x => x.id === c.id) === i);
  const groups = GROUPS.map(g => [g[0], g[1].map(id => CATS.find(c => c.id === id)).filter(Boolean)]).filter(g => g[1].length);
  if (rest.length) groups[groups.length - 1][1] = groups[groups.length - 1][1].concat(rest);
  if (typeof adminTiles === 'function') { const t = adminTiles(); if (t.length) groups.splice(Math.min(1, groups.length), 0, ['📌 নতুন ও বিশেষ', t]); }
  const lg = typeof applyLayout === 'function' ? applyLayout(groups) : groups;
  return includeHidden ? lg : lg.map(g => [g[0], g[1].filter(c => !tileOv(c.id).hide)]).filter(g => g[1].length);
}
function home(q = '') {
  tab = 'home'; stack = [];
  const list = CATS.filter(c => !q || c.name.includes(q) || (SHORT[c.id] || '').includes(q) || c.sub.includes(q));
  let body;
  if (q) body = `<div class="tgrid" style="margin-top:14px">${list.map(tile).join('') || '<div class="empty" style="grid-column:span 3">কিছু পাওয়া যায়নি</div>'}</div>`;
  else {
    const groups = homeGroups();
    body = `<div class="qrow">${QUICK.filter(x => !tileOv(x[0]).hide).map(x => { const o = tileOv(x[0]); return `<div class="qk" onclick="${x[0] === 'home' ? 'home()' : `open_('${x[0]}')`}"><b>${esc(o.ic || x[1])}</b>${esc(o.name || x[2])}</div>`; }).join('')}</div>` +
      alertBanner() + (typeof homeNotice === 'function' ? homeNotice() : '') +
      `<div class="stats"><span>🔥 ধারাবাহিক ${bn(updateStreak().n)} দিন</span><span>🏆 সেরা স্কোর ${bn(load('best', 0))}/${bn(QUIZ.length)}</span></div>` +
      dailyCard() +
      `<div class="tip"><div><b>💡 আজকের টিপস</b><div id="tip-t">${esc(TIPS[tipIdx])}</div></div><button class="btn sm" onclick="speak(document.getElementById('tip-t').innerText)">🔊</button></div>` +
      groups.map(g => `<div class="sec-h">${esc(g[0])}</div><div class="tgrid">${g[1].map(tile).join('')}</div>`).join('') + '<div style="height:14px"></div>';
  }
  render((q || typeof topAd !== 'function' ? '' : topAd()) + (!q && bismOn() ? '<div class="bism2">بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ</div>' : '') + `<div class="sign"><div class="hrow"><div class="brand">${appLogoHtml()}<div>${esc(appName())}<small>${esc(appSub())}</small></div></div>
      <div style="display:flex;gap:6px"><button class="iconbtn" onclick="toggleDark()">🌙</button><button class="iconbtn" style="width:auto;padding:0 10px;font-weight:800;font-size:14px" onclick="toggleLang()">${LANG === 'bn' ? 'EN' : 'বাং'}</button><button class="iconbtn" onclick="toggleDrawer()">☰</button></div></div>
      <div class="search"><span>🔍</span><input id="q" value="${esc(q)}" placeholder="কী শিখতে চান? যেমন: ব্রেক, লাইসেন্স" oninput="home(this.value)"></div></div>` + body);
  if (q) { const i = document.getElementById('q'); i.focus(); i.setSelectionRange(q.length, q.length); }
}

function open_(id) {
  push(() => home());
  if (id === 'roadtest' || id === 'quiz') return startQuiz();
  if (id === 'signs') return signsPage();
  if (id === 'account') return accountPage();
  if (id === 'profile') return profile();
  if (id.indexOf('sec_') === 0 && typeof sectionPage === 'function') return sectionPage(id.slice(4));
  if (id === 'contact') return contactPage();
  if (id === 'board') return boardPage();
  if (id === 'community') return communityPage();
  if (id === 'seeker') return seekerPage();
  if (id === 'admin') return adminPage();
  if (id === 'courses' && PAID_ENABLED) return paidHome();
  if (id === 'lang') { stack.pop(); return toggleLang(); }
  if (id === 'parts') return partsHome();
  if (id === 'learn') return learnPage();
  if (id === 'hacks') return hacksPage();
  if (id === 'ledger') return ledgerPage();
  if (id === 'remind') return remindPage();
  if (id === 'sos') return sosPage();
  if (id === 'govqa') return govHome();
  if (INFO[id]) return infoPage(id);
  if (id === 'signquiz') return startSignQuiz();
  if (id === 'links') return linksPage();
  if (id === 'share') { stack.pop(); return shareApp(); }
  if (id === 'paper') return paperPage();
  if (id === 'lessons') return lessonsPage();
  if (id === 'job' || id === 'intjob') return jobsPage(id === 'intjob' ? 'foreign' : 'all');
  if (id === 'cv') { stack.pop(); return openCv(); }
  if (id === 'jobprep') return studyPage('bangla');
  if (STUDY[id]) return studyPage(id);
  if (QA[id]) return qaPage(id);
}

// ---------- প্রশ্ন-উত্তর ----------
function qaPage(id) {
  tab = 'home';
  const c = CATS.find(x => x.id === id);
  render(pageHead(c.name) + '<div class="list">' + QA[id].map((x, i) =>
    `<div class="qa"><div class="q">${bn(String(i+1).padStart(2,'0'))}. প্রশ্ন: ${esc(x[0])}</div><div class="a">উত্তর: ${esc(x[1])}</div></div>`).join('') + '</div>');
}

// ---------- চাকরি প্রস্তুতি ----------
let sSub = 'bangla', sQ = '';
function studyPage(sub) {
  tab = 'study'; if (sub) sSub = sub; sQ = '';
  const chips = Object.keys(STUDY_LABELS).map(k =>
    `<button class="chip ${k===sSub?'on':''}" onclick="studyPage('${k}')">${STUDY_LABELS[k]}</button>`).join('');
  render(pageHead('চাকরির প্রস্তুতি') + `<div class="pad"><input class="inp" id="sq" placeholder="বিষয় বা পড়া খুঁজুন..." oninput="sQ=this.value.toLowerCase();document.getElementById('sbody').innerHTML=studyBody()">
    <div class="chips">${chips}</div><div id="sbody">${studyBody()}</div></div>`);
}
function studyBody() {
  return (STUDY[sSub] || []).map((sec, si) => {
    const items = sec.items.filter(it => !sQ || (it[0] + it[1]).toLowerCase().includes(sQ));
    if (!items.length) return '';
    const body = sec.type === 'flash'
      ? '<div class="two">' + items.map(it => `<div class="flash"><b>${esc(it[0])}</b><div>${esc(it[1])}</div></div>`).join('') + '</div>'
      : items.map(it => `<div class="note"><b>প্রশ্ন/নোট: ${esc(it[0])}</b><div class="ans">উত্তর: ${esc(it[1])}</div></div>`).join('');
    return `<div class="sec"><div class="sech"><b>📌 ${esc(sec.title)}</b><button class="btn sm" onclick="readSec(${si})">🔊 শুনুন</button></div>${body}</div>`;
  }).join('') || '<div class="empty">কিছু পাওয়া যায়নি</div>';
}
function readSec(si) {
  const sec = STUDY[sSub][si];
  speak(sec.title + '। ' + sec.items.map(it => it[0] + '। ' + it[1]).join('। '));
}

// ---------- লেসন ----------
function lessonsPage() {
  tab = 'home';
  render(pageHead('ড্রাইভ লেসন') + '<div class="pad">' + LESSONS.map(l =>
    `<details class="acc"><summary>${esc(l[0])}</summary><ol>${l[1].map(p => `<li>${esc(p)}</li>`).join('')}</ol></details>`).join('') + '</div>');
}

// ---------- সাইন ----------
let sgF = 'all';
function signsPage() {
  tab = 'home';
  const f = [['all','সব সাইন'],['mandatory','অবশ্যই পালনীয়'],['warning','সতর্কতামূলক'],['info','তথ্যমূলক']];
  render(pageHead('ট্রাফিক সাইন') + `<div class="pad"><div class="chips">${f.map(x =>
    `<button class="chip ${sgF===x[0]?'on':''}" onclick="sgF='${x[0]}';signsPage()">${x[1]}</button>`).join('')}</div></div>
    <div class="signs">${SIGNS.map((s, i) => ({s, i})).filter(o => sgF === 'all' || o.s[3] === sgF).map(o =>
    `<div class="sign" onclick="showSign(${o.i})"><div class="e">${o.s[0]}</div><b>${esc(o.s[1])}</b></div>`).join('')}</div>`);
}
function showSign(i) { const s = SIGNS[i]; showModal(`<div style="text-align:center"><div style="font-size:60px">${s[0]}</div><h3>${esc(s[1])}</h3><p>${esc(s[2])}</p>
  <button class="btn sm" onclick="speak('${esc(s[1])}। ${esc(s[2])}')">🔊 শুনুন</button></div>`); }

// ---------- চাকরি ----------
let jF = 'all';
function jobsPage(f) {
  tab = 'job'; if (f) jF = f;
  const fs = [['all','সব চাকরি'],['govt','সরকারি'],['local','দেশি চাকরি'],['foreign','বিদেশি চাকরি']];
  render(pageHead('ড্রাইভিং জব', false) + `<div class="pad"><button class="btn" style="width:100%;margin-bottom:6px;background:#9333ea" onclick="push(()=>jobsPage());paperPage()">📰 সাপ্তাহিক চাকরির পত্রিকা দেখুন</button><div class="chips">${fs.map(x =>
    `<button class="chip ${jF===x[0]?'on':''}" onclick="jobsPage('${x[0]}')">${x[1]}</button>`).join('')}</div>` +
    activeJobs().map((j, i) => ({j, i})).filter(o => jF === 'all' || o.j.kind === jF).map(o =>
    `<div class="job" onclick="showJob(${o.i})"><div style="display:flex;justify-content:space-between"><b>${esc(o.j.t)}</b>${o.j.urgent?'<span class="badge">জরুরি</span>':''}</div>
     <div style="color:#666;font-size:14px">🏢 ${esc(o.j.c || '')}</div><div style="font-size:14px;margin-top:4px">💰 ${esc(o.j.s || '')}</div></div>`).join('') +
    (activeJobs().some(j => jF === 'all' || j.kind === jF) ? '' : `<div class="empty">এই বিভাগে এখন কোনো চাকরি নেই।<br><br><button class="btn sm" onclick="window.open('https://alljobs.teletalk.com.bd','_blank')">সরকারি সার্কুলার দেখুন</button></div>`) +
    `<div style="font-size:13px;color:#a33;margin-top:10px">${esc(JOB_NOTE)}</div></div>`);
}
function showJob(i) {
  const j = activeJobs()[i];
  showModal(`<span class="badge" style="background:${j.kind==='local'?'#2b9348':'#4f46e5'}">${j.kind==='local'?'দেশি চাকরি':'বিদেশি চাকরি'}</span>
    <h3>${esc(j.t)}</h3><p style="font-weight:bold;color:#555">${esc(j.c || '')}</p><hr>
    <p>💰 <b>বেতন:</b> ${esc(j.s || '—')}</p><p>📜 <b>লাইসেন্স:</b> ${esc(j.lic || '—')}</p><p>📍 <b>লোকেশন:</b> ${esc(j.loc || '—')}</p><p>📝 ${esc(j.d || '')}</p>${j.deadline ? `<p>⏰ <b>আবেদনের শেষ তারিখ:</b> ${esc(j.deadline)}</p>` : ''}
    <div class="warn">⚠️ আবেদন করার সময় কোনো প্রকার আর্থিক লেনদেন করবেন না।</div>` +
    (safeUrl(j.url) ? `<a class="btn" style="display:block;text-align:center;text-decoration:none;margin-top:10px" href="${esc(safeUrl(j.url))}" onclick="goUrl(this.getAttribute('href'));return false">🔗 আবেদন / বিস্তারিত</a>` : '') + (j.phone ? `<a class="btn" style="display:block;text-align:center;text-decoration:none;margin-top:10px" href="tel:${esc(String(j.phone).replace(/[^\\d+]/g, ''))}">📞 কল করুন</a>` : ''));
}


// ---------- সাপ্তাহিক চাকরির পত্রিকা ----------
function lastFriday() {
  const d = new Date(); d.setDate(d.getDate() - ((d.getDay() - 5 + 7) % 7)); return d;
}
function fridayBn() {
  const m = ['জানুয়ারি','ফেব্রুয়ারি','মার্চ','এপ্রিল','মে','জুন','জুলাই','আগস্ট','সেপ্টেম্বর','অক্টোবর','নভেম্বর','ডিসেম্বর'];
  const d = lastFriday(); return LANG === 'en' ? d.toLocaleDateString('en-GB', {day: 'numeric', month: 'long', year: 'numeric'}) : bn(d.getDate()) + ' ' + m[d.getMonth()] + ' ' + bn(d.getFullYear());
}
function paperList() {
  const mine = load('paperlinks', []);
  return PAPER_LINKS.map(x => ({t:x.t, d:x.d, url: x.url || ('https://www.google.com/search?q=' + encodeURIComponent(x.q.replace('{DATE}', fridayBn())))}))
    .concat(mine.map(x => ({t:x.t, d:'আমার যোগ করা লিংক', url:x.url, mine:true})));
}
function paperPage() {
  const list = paperList(); let mi = -1;
  render(pageHead('সাপ্তাহিক চাকরির পত্রিকা') + `<div class="pad">
    <div class="tip" style="margin:0 0 12px"><div><b>📅 সর্বশেষ শুক্রবার: ${fridayBn()}</b><div>সাপ্তাহিক চাকরির পত্রিকা সাধারণত শুক্রবার প্রকাশিত হয়। নিচের লিংকে চাপ দিলে ব্রাউজারে খুলবে (ইন্টারনেট লাগবে)।</div></div></div>` +
    list.map((x, i) => {
      if (x.mine) mi++;
      return `<div class="job" style="border-color:#9333ea"><b>${esc(x.t)}</b><div style="font-size:13px;color:#666;margin:2px 0 8px">${esc(x.d)}</div>
        <button class="btn sm" style="background:#9333ea" onclick="openLink(${i})">🔗 খুলুন</button>
        ${x.mine ? `<button class="btn sm" style="background:#dc2626;margin-left:6px" onclick="delPaper(${mi})">মুছুন</button>` : ''}</div>`;
    }).join('') + `
    <div class="sec"><b>➕ নিজের পত্রিকার লিংক যোগ করুন</b>
      <input class="inp" id="pl-t" placeholder="নাম (যেমন: এই সপ্তাহের পত্রিকা)">
      <input class="inp" id="pl-u" placeholder="লিংক (https://...)">
      <button class="btn sm" onclick="addPaper()">সংরক্ষণ করুন</button></div>
    <div class="warn">⚠️ শুধু বিশ্বস্ত সোর্স ব্যবহার করুন। চাকরির নামে কেউ টাকা চাইলে বিশ্বাস করবেন না।</div></div>`);
}
function openLink(i) { const x = paperList()[i]; if (x) goUrl(x.url); }
function addPaper() {
  const t = document.getElementById('pl-t').value.trim(); let u = document.getElementById('pl-u').value.trim();
  if (!t || !u) { alert('নাম ও লিংক দিন।'); return; }
  if (!/^https?:\/\//i.test(u)) u = 'https://' + u;
  if (/^https?:\/\/\s*$/i.test(u) || u.indexOf('.') < 0) { alert('সঠিক লিংক দিন।'); return; }
  const a = load('paperlinks', []); a.push({t, url:u}); localStorage.setItem('paperlinks', JSON.stringify(a)); paperPage();
}
function delPaper(i) { const a = load('paperlinks', []); a.splice(i, 1); localStorage.setItem('paperlinks', JSON.stringify(a)); paperPage(); }


// ---------- তথ্য পেজ ----------
function infoPage(id) {
  tab = 'home'; const x = INFO[id];
  render(pageHead(x.title) + '<div class="pad">' + (x.note ? `<div class="warn" style="margin:0 0 10px">${esc(x.note)}</div>` : '') +
    x.items.map((it, i) => `<div class="infoc"><div class="ie">${it[0]}</div><div style="flex:1"><b>${esc(it[1])}</b><div>${esc(it[2])}</div></div>
      <button class="btn sm" onclick="readInfo('${id}',${i})">🔊</button></div>`).join('') + '</div>');
}
function readInfo(id, i) { const it = INFO[id].items[i]; speak(it[1] + '। ' + it[2]); }

// ---------- সাইন চিনুন কুইজ ----------
let sqi = 0, sqs = 0, sqAns = false, sqOrder = [], sqOpts = [];
function startSignQuiz() { tab = 'home'; sqi = 0; sqs = 0; sqOrder = SIGNS.map((_, i) => i).sort(() => Math.random() - .5); signQ(); }
function signQ() {
  sqAns = false; const s = SIGNS[sqOrder[sqi]];
  const others = SIGNS.filter((_, i) => i !== sqOrder[sqi]).map(x => x[1]).sort(() => Math.random() - .5).slice(0, 3);
  sqOpts = [s[1]].concat(others).sort(() => Math.random() - .5);
  render(pageHead('সাইন চিনুন') + `<div class="pad quiz"><div style="color:#666">সাইন ${bn(sqi+1)} / ${bn(SIGNS.length)}</div>
    <div style="text-align:center;font-size:90px;margin:10px 0">${s[0]}</div><h3 style="text-align:center">এই সাইনের নাম কী?</h3>` +
    sqOpts.map((o, i) => `<div class="opt" id="so${i}" onclick="pickSign(${i})">${esc(o)}</div>`).join('') + '<div id="snx" style="text-align:right;margin-top:12px"></div></div>');
}
function pickSign(i) {
  if (sqAns) return; sqAns = true; const right = SIGNS[sqOrder[sqi]][1];
  if (sqOpts[i] === right) sqs++; else document.getElementById('so' + i).classList.add('no');
  document.getElementById('so' + sqOpts.indexOf(right)).classList.add('ok');
  document.getElementById('snx').innerHTML = `<button class="btn" onclick="sqi++;sqi<SIGNS.length?signQ():signResult()">${sqi+1<SIGNS.length?'পরের সাইন →':'ফলাফল দেখুন'}</button>`;
}
function signResult() {
  render(pageHead('ফলাফল') + `<div class="pad" style="text-align:center"><div style="font-size:64px">${sqs/SIGNS.length>=.7?'🏆':'📚'}</div>
    <h2>স্কোর: ${bn(sqs)} / ${bn(SIGNS.length)}</h2><button class="btn" onclick="startSignQuiz()">আবার চেষ্টা করুন</button></div>`);
}

// ---------- লিংক, শেয়ার, ডার্ক মোড, স্ট্রিক ----------
function linksPage() {
  tab = 'home';
  render(pageHead('দরকারি লিংক') + '<div class="pad">' + LINKS.map((x, i) =>
    `<div class="job" style="border-color:#475569"><b>${esc(x.t)}</b><div style="font-size:13px;color:#666;margin:2px 0 8px">${esc(x.d)}</div>
     <button class="btn sm" style="background:#475569" onclick="goUrl(LINKS[${i}].url)">🔗 খুলুন</button></div>`).join('') +
    '<div class="warn">লিংক ব্রাউজারে খুলবে, ইন্টারনেট লাগবে।</div></div>');
}
function shareApp() {
  const text = 'চালক ভাই অ্যাপ: ড্রাইভিং লাইসেন্স পরীক্ষার প্রস্তুতি, রোড সাইন, কুইজ ও চাকরির খবর এক জায়গায়।';
  if (navigator.share) navigator.share({title:'চালক ভাই', text}).catch(() => {});
  else { try { navigator.clipboard.writeText(text); alert('শেয়ারের লেখা কপি হয়েছে।'); } catch (e) { alert(text); } }
}
function toggleDark() {
  const on = document.body.classList.toggle('dark'); localStorage.setItem('dark', on ? '1' : '0');
}
function dayStr(d) { return d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate(); }
function updateStreak() {
  const s = load('streak', {last:'', n:0}), t = dayStr(new Date());
  if (s.last === t) return s;
  s.n = s.last === dayStr(new Date(Date.now() - 864e5)) ? s.n + 1 : 1; s.last = t;
  localStorage.setItem('streak', JSON.stringify(s)); return s;
}
if (localStorage.getItem('dark') === '1') document.body.classList.add('dark');


// ---------- অনলাইন চাকরির তালিকা (মেয়াদ শেষ হলে নিজে সরে যায়) ----------
let REMOTE_JOBS = load('remoteJobs', []);
function fixUrl(u) {
  u = String(u || '').trim().replace(/\s+/g, ''); if (!u) return '';
  if (/^(https?:\/\/|mailto:|tel:)/i.test(u)) return u;
  if (/^(www\.|[\w-]+(\.[\w-]+)+(\/|\?|#|$))/i.test(u)) return 'https://' + u;
  return '';
}
function safeUrl(u) { const f = fixUrl(u); return /^https?:\/\//i.test(f) ? f : ''; }
// লিংক খোলা: ফোনে ব্রাউজারে, ব্রাউজার প্লাগিন না থাকলে সাধারণ পদ্ধতিতে
function goUrl(u) {
  u = fixUrl(u); if (!u) { alert('লিংকটি ঠিক নয়'); return; }
  if (/^(mailto:|tel:)/i.test(u)) { location.href = u; return; }
  try { const B = window.Capacitor && Capacitor.registerPlugin ? Capacitor.registerPlugin('Browser') : null; if (B && B.open) { B.open({url: u}).catch(() => window.open(u, '_system')); return; } } catch (e) {}
  window.open(u, '_system');
}
function todayISO() { const d = new Date(), p = n => String(n).padStart(2, '0'); return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate()); }
function activeJobs() {
  const t = todayISO();
  return JOBS.concat(Array.isArray(REMOTE_JOBS) ? REMOTE_JOBS : [], typeof adminJobs === 'function' ? adminJobs() : []).filter(j => j && typeof j === 'object' && j.t && (!j.deadline || String(j.deadline) >= t));
}
function fetchJobs() {
  if (!JOBS_URL) return;
  fetch(JOBS_URL + (JOBS_URL.includes('?') ? '&' : '?') + 't=' + Date.now()).then(r => r.json()).then(j => {
    if (!Array.isArray(j)) return;
    REMOTE_JOBS = j; try { localStorage.setItem('remoteJobs', JSON.stringify(j)); } catch (e) {}
    if (tab === 'job' && !document.getElementById('modal')) jobsPage();
  }).catch(() => {});
}

// ---------- সরকারি চাকরির প্রশ্ন ও সমাধান ----------
function govHome() {
  tab = 'home';
  render(pageHead('সরকারি চাকরির প্রশ্ন ও সমাধান') + '<div class="pad"><div class="warn" style="margin:0 0 10px">প্রতিটি প্রশ্নে উত্তর বেছে নিলে সঠিক উত্তর ও সমাধান দেখাবে।</div>' +
    Object.keys(GOV).map(k => `<div class="card" style="margin-bottom:10px" onclick="push(()=>govHome());govList('${k}')"><div class="t"><span style="flex:1">${GOV_LABELS[k]}</span><span style="color:#999">${bn(GOV[k].length)}টি ›</span></div></div>`).join('') +
    `<div class="card" style="margin-bottom:10px;border-color:#1e40af" onclick="push(()=>govHome());open_('govguide')"><div class="t">🏛️ <span style="flex:1;color:#1e40af">প্রস্তুতি গাইড</span><span style="color:#999">›</span></div></div></div>`);
}
function govList(k) {
  render(pageHead(GOV_LABELS[k]) + '<div class="list">' + GOV[k].map((q, i) =>
    `<div class="qa" id="g${i}"><div class="q">${bn(i+1)}. ${esc(q[0])}</div>` +
    q[1].map((o, j) => `<div class="opt" style="border:2px solid #dfe6ee;border-radius:12px;padding:10px;margin:6px 0" id="g${i}o${j}" onclick="govPick('${k}',${i},${j})">${esc(o)}</div>`).join('') +
    `<div class="a" id="g${i}s" style="display:none;margin-top:8px"></div></div>`).join('') + '</div>');
}
function govPick(k, i, j) {
  const q = GOV[k][i], box = document.getElementById('g' + i + 's');
  if (box.style.display === 'block') return;
  if (j !== q[2]) document.getElementById('g' + i + 'o' + j).classList.add('no');
  document.getElementById('g' + i + 'o' + q[2]).classList.add('ok');
  box.style.display = 'block';
  box.innerHTML = (j === q[2] ? '✅ সঠিক। ' : '❌ ভুল। সঠিক উত্তর: ' + esc(q[1][q[2]]) + '। ') + '<br><b>সমাধান:</b> ' + esc(q[3]) +
    ` <button class="btn sm" onclick="speak('${esc(q[3]).replace(/'/g, '')}')">🔊</button>`;
}


// ---------- যন্ত্রাংশ ----------
function partsHome() {
  tab = 'home';
  render(pageHead('গাড়ির যন্ত্রাংশ') + '<div class="pad"><div class="warn" style="margin:0 0 10px">গাড়ি বেছে নিন, তারপর যন্ত্রাংশে চাপ দিন। নিজে মেরামতের আগে মিস্ত্রির পরামর্শ নিন।</div>' +
    Object.keys(PART_GROUPS).map(k => `<div class="card" style="margin-bottom:10px" onclick="push(()=>partsHome());partsList('${k}')"><div class="t"><span style="flex:1">${PART_GROUPS[k].name}</span><span style="color:#999">${bn(PART_GROUPS[k].parts.length)}টি ›</span></div></div>`).join('') + '</div>');
}
let pQ = '';
function partsList(k) {
  pQ = '';
  render(pageHead(PART_GROUPS[k].name) + `<div class="pad"><input class="inp" placeholder="যন্ত্রাংশ খুঁজুন..." oninput="pQ=this.value;document.getElementById('plist').innerHTML=partsBody('${k}')"><div id="plist">${partsBody(k)}</div></div>`);
}
function partsBody(k) {
  const out = PART_GROUPS[k].parts.map((p, i) => ({p, i})).filter(o => !pQ || (o.p[1] + o.p[2]).includes(pQ));
  return out.map(o => `<div class="infoc" onclick="showPart('${k}',${o.i})"><div class="ie">${/\.(png|jpe?g|webp|svg)$/i.test(o.p[0]) ? `<img src="${esc(o.p[0])}" style="width:44px;height:44px">` : o.p[0]}</div><div style="flex:1"><b>${esc(o.p[1])}</b><div>${esc(o.p[2])}</div></div></div>`).join('') || '<div class="empty">কিছু পাওয়া যায়নি</div>';
}
function showPart(k, i) {
  const p = PART_GROUPS[k].parts[i];
  showModal(`<div style="text-align:center;font-size:56px">${/\.(png|jpe?g|webp|svg)$/i.test(p[0]) ? `<img src="${esc(p[0])}" style="width:90px">` : p[0]}</div><h3 style="text-align:center">${esc(p[1])}</h3>
    <p><b>কাজ:</b> ${esc(p[2])}</p><p><b>সমস্যার লক্ষণ:</b> ${esc(p[3])}</p><p><b>করণীয়:</b> ${esc(p[4])}</p>
    <button class="btn sm" onclick="speak('${esc(p[1] + '। ' + p[2] + '। সমস্যার লক্ষণ: ' + p[3] + '। করণীয়: ' + p[4]).replace(/'/g, '')}')">🔊 শুনুন</button>`);
}

// ---------- কোর্স ও দ্রুত সমাধান ----------
function learnPage() {
  tab = 'home';
  render(pageHead('গাড়ি চালানো শিখুন') + '<div class="pad"><div class="warn" style="margin:0 0 10px">অভিজ্ঞ প্রশিক্ষকের সঙ্গে ফাঁকা জায়গায় অনুশীলন করুন। এই কোর্স সাধারণ ধারণা দেয়।</div>' +
    COURSE.map((l, i) => `<details class="acc"><summary>${esc(l[0])}</summary><p style="line-height:1.7">${esc(l[1])}</p><button class="btn sm" onclick="speak('${esc(l[1]).replace(/'/g, '')}')">🔊 শুনুন</button></details>`).join('') + '</div>');
}
function hacksPage() {
  tab = 'home';
  render(pageHead('দ্রুত সমাধান') + '<div class="pad">' + HACKS.map((h, i) =>
    `<details class="acc"><summary>${h[0]} ${esc(h[1])}</summary><p style="line-height:1.8;white-space:pre-line">${esc(h[2])}</p>
     ${safeUrl(h[3]) ? `<button class="btn sm" onclick="goUrl('${esc(safeUrl(h[3]))}')">▶️ ভিডিও দেখুন</button>` : ''}
     <button class="btn sm" onclick="speak('${esc(h[2]).replace(/\n/g, ' ').replace(/'/g, '')}')">🔊 শুনুন</button></details>`).join('') + '</div>');
}

// ---------- জরুরি নম্বর ----------
function sosPage() {
  tab = 'home'; const mine = load('sos', []);
  render(pageHead('জরুরি নম্বর') + `<div class="pad"><div class="job" style="border-color:#dc2626"><b>🆘 জাতীয় জরুরি সেবা: ৯৯৯</b><div style="font-size:13px;color:#666;margin:4px 0 8px">পুলিশ, ফায়ার সার্ভিস ও অ্যাম্বুলেন্সের জন্য</div>
    <a class="btn sm" style="background:#dc2626;text-decoration:none" href="tel:999">📞 কল করুন</a></div>` +
    mine.map((m, i) => `<div class="job" style="border-color:#475569"><b>${esc(m.n)}</b><div style="font-size:14px;margin:4px 0 8px">📞 ${esc(m.p)}</div>
      <a class="btn sm" style="background:#475569;text-decoration:none" href="tel:${esc(String(m.p).replace(/[^\d+]/g, ''))}">কল</a>
      <button class="btn sm" style="background:#dc2626;margin-left:6px" onclick="delSos(${i})">মুছুন</button></div>`).join('') +
    `<div class="sec"><b>➕ নিজের যোগাযোগ নম্বর যোগ করুন</b><div style="font-size:13px;color:#666">মেকানিক, গ্যারেজ, হাইওয়ে পুলিশ, পরিবারের সদস্য</div>
      <input class="inp" id="sn" placeholder="নাম (যেমন: করিম মিস্ত্রি)"><input class="inp" id="sp" type="tel" placeholder="ফোন নম্বর">
      <button class="btn sm" onclick="addSos()">সংরক্ষণ করুন</button></div></div>`);
}
function addSos() {
  const n = document.getElementById('sn').value.trim(), p = document.getElementById('sp').value.trim();
  if (!n || !p) { alert('নাম ও নম্বর দিন।'); return; }
  const m = load('sos', []); m.push({n, p}); localStorage.setItem('sos', JSON.stringify(m)); sosPage();
}
function delSos(i) { const m = load('sos', []); m.splice(i, 1); localStorage.setItem('sos', JSON.stringify(m)); sosPage(); }

// ---------- আয়-খরচ খাতা ----------
const taka = n => bn(Math.round(n).toLocaleString('en-US')) + ' টাকা';
const tk = n => '৳' + bn(Math.round(n).toLocaleString('en-US'));
const kf = n => n >= 1000 ? bn(Math.round(n / 100) / 10) + 'k' : bn(Math.round(n));
const L_IN = ['ট্রিপের আয়', 'বেতন', 'বখশিশ', 'ভাড়ায় আয়', 'অন্যান্য আয়'];
const L_OUT = ['জ্বালানি (তেল/গ্যাস)', 'গাড়ির মেরামত', 'গাড়ির কিস্তি', 'খাবার', 'ঘর ভাড়া', 'টোল ও পার্কিং', 'মোবাইল ও ইন্টারনেট', 'চিকিৎসা', 'পরিবার ও সন্তান', 'জরিমানা ও চাঁদা', 'অন্যান্য খরচ'];
const L_MON = ['জানুয়ারি', 'ফেব্রুয়ারি', 'মার্চ', 'এপ্রিল', 'মে', 'জুন', 'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর'];
const L_MSH = ['জানু', 'ফেব্রু', 'মার্চ', 'এপ্রি', 'মে', 'জুন', 'জুলা', 'আগ', 'সেপ্টে', 'অক্টো', 'নভে', 'ডিসে'];
const L_WD = ['রবি', 'সোম', 'মঙ্গল', 'বুধ', 'বৃহঃ', 'শুক্র', 'শনি'];
let lv = 'cal', lm = '', ld = '', ly = 0;
function ledgerData() { const l = load('ledger', {}); l.entries = l.entries || []; l.fixed = l.fixed || []; l.loans = l.loans || []; l.goals = l.goals || []; l.budget = l.budget || 0; return l; }
function saveLedger(l) { localStorage.setItem('ledger', JSON.stringify(l)); }
const lsum = (a, ty) => a.filter(e => e.type === ty).reduce((s, e) => s + e.amt, 0);
function lmstat(l, ym) {
  const es = l.entries.filter(e => e.date.slice(0, 7) === ym), inc = lsum(es, 'in'), out = lsum(es, 'out');
  const cur = todayISO().slice(0, 7), first = l.entries.reduce((m, e) => e.date.slice(0, 7) < m ? e.date.slice(0, 7) : m, cur);
  const fx = ym >= first && ym <= cur ? l.fixed.reduce((s, f) => s + f.amt, 0) : 0;
  return {es, inc, out, fx, exp: out + fx, net: inc - out - fx};
}
const lmName = ym => L_MON[+ym.slice(5, 7) - 1] + ' ' + bn(ym.slice(0, 4));
const lshift = (ym, d) => { const dt = new Date(+ym.slice(0, 4), +ym.slice(5, 7) - 1 + d, 1); return dt.getFullYear() + '-' + String(dt.getMonth() + 1).padStart(2, '0'); };
function ledgerPage() {
  tab = 'home'; const l = ledgerData(), t = todayISO();
  if (!lm) lm = t.slice(0, 7); if (!ld || ld.slice(0, 7) !== lm) ld = lm === t.slice(0, 7) ? t : lm + '-01'; if (!ly) ly = +t.slice(0, 4);
  const s = lmstat(l, lm), over = l.budget > 0 && s.exp > l.budget;
  const tabs = [['cal', '📅 ক্যালেন্ডার'], ['sum', '📊 হিসাব'], ['loan', '💳 কিস্তি'], ['save', '🏦 সঞ্চয়']];
  render(pageHead('আয়-খরচ খাতা') + `<div class="pad">
    <div class="lhero"><div class="lm"><button onclick="lgMonth(-1)">‹</button><b>${lmName(lm)}</b><button onclick="lgMonth(1)">›</button></div>
      <div class="l3"><div><small>আয়</small><b style="color:#86efac">${tk(s.inc)}</b></div><div><small>খরচ</small><b style="color:#fca5a5">${tk(s.exp)}</b></div><div><small>${s.net >= 0 ? 'বাঁচল' : 'ঘাটতি'}</small><b>${tk(Math.abs(s.net))}</b></div></div>
      ${l.budget ? `<div class="lbar"><i style="width:${Math.min(100, Math.round(s.exp / l.budget * 100))}%;background:${over ? '#ef4444' : '#22c55e'}"></i></div><small>বাজেট ${tk(l.budget)} • ${bn(Math.round(s.exp / l.budget * 100))}% খরচ</small>` : ''}</div>
    ${over ? `<div class="warn" style="background:#fee2e2;border-color:#f87171;color:#991b1b">🚨 এ মাসের খরচ বাজেট ছাড়িয়েছে।</div>` : ''}
    ${lDue(l)}
    <div class="seg lseg">${tabs.map(x => `<button class="${lv === x[0] ? 'on' : ''}" onclick="lv='${x[0]}';ledgerPage()">${x[1]}</button>`).join('')}</div>
    ${lv === 'cal' ? lCal(l) : lv === 'sum' ? lSum(l) : lv === 'loan' ? lLoan(l) : lSave(l)}</div>`);
}
function lDue(l) {
  const t = todayISO(), ym = t.slice(0, 7), d = +t.slice(8, 10); let h = '';
  l.loans.forEach(x => { if (x.paid >= x.count || x.last === ym) return; const left = x.day - d; if (left <= 3) h += `<div class="warn" style="background:#fff7ed;border-color:#fb923c">⏰ ${esc(x.n)}: ${left < 0 ? bn(-left) + ' দিন দেরি' : left === 0 ? 'আজ কিস্তির দিন' : bn(left) + ' দিন পরে কিস্তি'} (${tk(x.amt)})</div>`; });
  return h;
}
function lCal(l) {
  const y = +lm.slice(0, 4), mo = +lm.slice(5, 7), first = new Date(y, mo - 1, 1).getDay(), days = new Date(y, mo, 0).getDate(), t = todayISO();
  const by = {}; l.entries.filter(e => e.date.slice(0, 7) === lm).forEach(e => { const k = e.date.slice(8, 10); by[k] = by[k] || {i: 0, o: 0}; by[k][e.type === 'in' ? 'i' : 'o'] += e.amt; });
  let cells = L_WD.map(w => `<div class="lw">${w}</div>`).join('') + '<div></div>'.repeat(first);
  for (let d = 1; d <= days; d++) {
    const k = String(d).padStart(2, '0'), iso = lm + '-' + k, x = by[k];
    cells += `<div class="ld ${iso === ld ? 'sel' : ''} ${iso === t ? 'tod' : ''}" onclick="ld='${iso}';ledgerPage()"><b>${bn(d)}</b>${x && x.i ? `<i class="gi">${kf(x.i)}</i>` : ''}${x && x.o ? `<i class="ro">${kf(x.o)}</i>` : ''}</div>`;
  }
  const es = l.entries.filter(e => e.date === ld);
  const di = lsum(es, 'in'), dout = lsum(es, 'out');
  return `<div class="sec" style="padding:8px"><div class="lcal">${cells}</div></div>
    <div class="sec"><b>${bn(+ld.slice(8, 10))} ${L_MON[+ld.slice(5, 7) - 1]}</b> <small style="color:#6b7280">আয় ${tk(di)} • খরচ ${tk(dout)}</small>
    ${es.map(e => `<div class="note" style="display:flex;justify-content:space-between;gap:8px"><span>${e.type === 'in' ? '🟢' : '🔴'} ${esc(e.cat || '')}${e.note ? ' • ' + esc(e.note) : ''}</span><span style="white-space:nowrap">${tk(e.amt)} <a href="#" onclick="lgDel('${e.id}');return false">✕</a></span></div>`).join('') || '<div class="hint">এই দিনে কোনো হিসাব নেই।</div>'}</div>
    <div class="sec"><b>➕ হিসাব লিখুন (${bn(+ld.slice(8, 10))} ${L_MON[+ld.slice(5, 7) - 1]})</b>
      <div class="seg" style="margin:8px 0"><button id="lt_o" class="on" onclick="lgType('out')">🔴 খরচ</button><button id="lt_i" onclick="lgType('in')">🟢 আয়</button></div>
      <select class="inp" id="lc">${L_OUT.map(c => `<option>${c}</option>`).join('')}</select>
      <input class="inp" id="la" type="number" inputmode="decimal" min="0" placeholder="টাকা">
      <input class="inp" id="ln" placeholder="বিবরণ (ঐচ্ছিক)">
      <button class="btn" onclick="lgAdd()">💾 সংরক্ষণ</button></div>`;
}
let _lt = 'out';
function lgType(t) { _lt = t; document.getElementById('lc').innerHTML = (t === 'in' ? L_IN : L_OUT).map(c => `<option>${c}</option>`).join(''); document.getElementById('lt_o').className = t === 'out' ? 'on' : ''; document.getElementById('lt_i').className = t === 'in' ? 'on' : ''; }
function lgAdd() {
  const amt = parseFloat(document.getElementById('la').value); if (!(amt > 0)) { alert('সঠিক টাকার পরিমাণ দিন।'); return; }
  const l = ledgerData(); l.entries.push({id: String(Date.now()), date: ld, type: _lt, amt, cat: document.getElementById('lc').value, note: document.getElementById('ln').value.trim()}); saveLedger(l); _lt = 'out'; ledgerPage();
}
function lgDel(id) { const l = ledgerData(); l.entries = l.entries.filter(e => e.id !== id); saveLedger(l); ledgerPage(); }
function lgMonth(d) { lm = lshift(lm, d); ld = ''; ledgerPage(); }
function lSum(l) {
  const s = lmstat(l, lm), cat = {};
  s.es.filter(e => e.type === 'out').forEach(e => { const k = e.cat || 'অন্যান্য খরচ'; cat[k] = (cat[k] || 0) + e.amt; });
  if (s.fx) cat['নির্দিষ্ট মাসিক খরচ'] = s.fx;
  const rows = Object.keys(cat).sort((a, b) => cat[b] - cat[a]), mx = Math.max(1, ...rows.map(k => cat[k]));
  const inc = {}; s.es.filter(e => e.type === 'in').forEach(e => { const k = e.cat || 'অন্যান্য আয়'; inc[k] = (inc[k] || 0) + e.amt; });
  const mons = Array.from({length: 12}, (_, i) => { const ym = ly + '-' + String(i + 1).padStart(2, '0'); return Object.assign({ym}, lmstat(l, ym)); });
  const ti = mons.reduce((a, m) => a + m.inc, 0), te = mons.reduce((a, m) => a + m.exp, 0), mm = Math.max(1, ...mons.map(m => Math.max(m.inc, m.exp)));
  const act = mons.filter(m => m.inc || m.exp).length || 1;
  return `<div class="sec"><b>🧾 ${lmName(lm)} — কোথায় কত খরচ</b>
      ${rows.map(k => `<div class="crow"><span>${esc(k)}</span><div class="cb"><i style="width:${Math.round(cat[k] / mx * 100)}%"></i></div><b>${tk(cat[k])}</b></div>`).join('') || '<div class="hint">এ মাসে এখনো খরচ লেখা হয়নি।</div>'}</div>
    ${Object.keys(inc).length ? `<div class="sec"><b>💚 আয়ের উৎস</b>${Object.keys(inc).map(k => `<div class="crow"><span>${esc(k)}</span><div class="cb g"><i style="width:${Math.round(inc[k] / Math.max(1, s.inc) * 100)}%"></i></div><b>${tk(inc[k])}</b></div>`).join('')}</div>` : ''}
    <div class="sec"><div class="lm" style="color:inherit"><button onclick="ly--;ledgerPage()">‹</button><b>📆 ${bn(ly)} সালের হিসাব</b><button onclick="ly++;ledgerPage()">›</button></div>
      ${mons.map((m, i) => `<div class="yrow" onclick="lm='${m.ym}';ld='';lv='cal';ledgerPage()"><span>${L_MSH[i]}</span><div class="yb"><i class="gi2" style="width:${Math.round(m.inc / mm * 100)}%"></i><i class="ro2" style="width:${Math.round(m.exp / mm * 100)}%"></i></div><b style="color:${m.net >= 0 ? '#15803d' : '#b91c1c'}">${m.inc || m.exp ? (m.net < 0 ? '−' : '') + kf(Math.abs(m.net)) : '–'}</b></div>`).join('')}
      <div class="two" style="margin-top:10px"><div class="flash"><b>বছরের আয়</b><div>${tk(ti)}</div></div><div class="flash"><b>বছরের খরচ</b><div>${tk(te)}</div></div><div class="flash"><b>মোট সঞ্চয়</b><div>${tk(ti - te)}</div></div><div class="flash"><b>মাসে গড় সঞ্চয়</b><div>${tk((ti - te) / act)}</div></div></div></div>
    <div class="sec"><b>🎯 মাসিক খরচের বাজেট সীমা</b><input class="inp" id="lb" type="number" min="0" value="${l.budget || ''}" placeholder="যেমন: ২০০০০"><button class="btn sm" onclick="setBudget()">সেট করুন</button></div>`;
}
function setBudget() { const l = ledgerData(); l.budget = parseFloat(document.getElementById('lb').value) || 0; saveLedger(l); ledgerPage(); }
function lLoan(l) {
  return `<div class="sec"><b>💳 কিস্তি (লোন)</b><div class="hint">গাড়ি, ফোন বা ঋণের কিস্তি লিখে রাখুন। কিস্তি দিলে "দিলাম" চাপুন, নিজে খরচে যোগ হবে।</div>
    ${l.loans.map((x, i) => { const left = x.count - x.paid; return `<div class="loan"><div style="display:flex;justify-content:space-between"><b>${esc(x.n)}</b><a href="#" onclick="lgLoanDel(${i});return false">🗑️</a></div>
      <div class="lbar d"><i style="width:${Math.round(x.paid / x.count * 100)}%;background:#22c55e"></i></div>
      <small>${bn(x.paid)}/${bn(x.count)} টি দেওয়া • বাকি ${bn(left)}টি = ${tk(left * x.amt)} • প্রতি মাসে ${tk(x.amt)} • তারিখ ${bn(x.day)}</small>
      ${left > 0 ? `<button class="btn sm" ${x.last === todayISO().slice(0, 7) ? 'disabled style="opacity:.5"' : ''} onclick="lgLoanPay(${i})">${x.last === todayISO().slice(0, 7) ? '✅ এ মাসের দেওয়া হয়েছে' : '✅ এ মাসের কিস্তি দিলাম'}</button>` : '<div style="color:#15803d;font-weight:700">🎉 সব কিস্তি শোধ!</div>'}</div>`; }).join('') || ''}
    <input class="inp" id="kn" placeholder="নাম (যেমন: গাড়ির কিস্তি)"><input class="inp" id="ka" type="number" min="0" placeholder="প্রতি মাসে কত টাকা"><input class="inp" id="kc" type="number" min="1" placeholder="মোট কয়টি কিস্তি"><input class="inp" id="kp" type="number" min="0" placeholder="কয়টি ইতিমধ্যে দিয়েছেন (না থাকলে ০)"><input class="inp" id="kd" type="number" min="1" max="31" placeholder="মাসের কত তারিখে দিতে হয়">
    <button class="btn sm" onclick="lgLoanAdd()">➕ কিস্তি যোগ করুন</button></div>
    <div class="sec"><b>🏠 প্রতি মাসের নির্দিষ্ট খরচ</b><div class="hint">ঘর ভাড়া, গ্যারেজ ভাড়া ইত্যাদি। প্রতি মাসের খরচে নিজে যোগ হয়।</div>
    ${l.fixed.map((f, i) => `<div class="note" style="display:flex;justify-content:space-between"><span>${esc(f.n)}</span><span>${tk(f.amt)} <a href="#" onclick="delFixed(${i});return false">✕</a></span></div>`).join('')}
    <input class="inp" id="fn" placeholder="নাম (যেমন: ঘর ভাড়া)"><input class="inp" id="fa" type="number" min="0" placeholder="মাসে কত টাকা"><button class="btn sm" onclick="addFixed()">যোগ করুন</button></div>`;
}
function lgLoanAdd() {
  const n = gv2('kn'), a = +gv2('ka'), c = +gv2('kc'), p = +gv2('kp') || 0, d = +gv2('kd') || 1;
  if (!n || !(a > 0) || !(c > 0)) { alert('নাম, কিস্তির টাকা ও মোট কয়টি তা দিন।'); return; }
  const l = ledgerData(); l.loans.push({id: String(Date.now()), n, amt: a, count: c, paid: Math.min(p, c), day: Math.min(31, d), last: ''}); saveLedger(l); ledgerPage();
}
const gv2 = id => (document.getElementById(id).value || '').trim();
function lgLoanPay(i) {
  const l = ledgerData(), x = l.loans[i]; if (!x || x.paid >= x.count) return;
  x.paid++; x.last = todayISO().slice(0, 7); l.entries.push({id: String(Date.now()), date: todayISO(), type: 'out', amt: x.amt, cat: 'গাড়ির কিস্তি', note: x.n}); saveLedger(l); ledgerPage();
}
function lgLoanDel(i) { if (!confirm('এই কিস্তিটি মুছবেন?')) return; const l = ledgerData(); l.loans.splice(i, 1); saveLedger(l); ledgerPage(); }
function addFixed() {
  const n = gv2('fn'), amt = parseFloat(gv2('fa'));
  if (!n || !(amt > 0)) { alert('নাম ও টাকা দিন।'); return; }
  const l = ledgerData(); l.fixed.push({n, amt}); saveLedger(l); ledgerPage();
}
function delFixed(i) { const l = ledgerData(); l.fixed.splice(i, 1); saveLedger(l); ledgerPage(); }
function lSave(l) {
  const s = lmstat(l, lm), tot = l.goals.reduce((a, g) => a + g.saved, 0);
  return `<div class="two"><div class="flash"><b>এ মাসে বাঁচল</b><div>${tk(s.net)}</div></div><div class="flash"><b>সব লক্ষ্যে জমা</b><div>${tk(tot)}</div></div></div>
    <div class="sec"><b>🏦 সঞ্চয়ের লক্ষ্য</b><div class="hint">যেমন: নতুন গাড়ি, হজ্জ, মেয়ের পড়াশোনা। লক্ষ্য ঠিক করে একটু একটু করে জমান।</div>
    ${l.goals.map((g, i) => { const pc = Math.min(100, Math.round(g.saved / g.target * 100)); return `<div class="loan"><div style="display:flex;justify-content:space-between"><b>🎯 ${esc(g.n)}</b><a href="#" onclick="lgGoalDel(${i});return false">🗑️</a></div>
      <div class="lbar d"><i style="width:${pc}%;background:#3b82f6"></i></div><small>${tk(g.saved)} / ${tk(g.target)} (${bn(pc)}%) • বাকি ${tk(Math.max(0, g.target - g.saved))}</small>
      <div style="display:flex;gap:6px;margin-top:6px"><input class="inp" style="margin:0" id="gd${i}" type="number" min="0" placeholder="কত জমালেন"><button class="btn sm" style="margin:0" onclick="lgGoalAdd(${i})">+ জমা</button></div></div>`; }).join('')}
    <input class="inp" id="gn" placeholder="লক্ষ্যের নাম"><input class="inp" id="gt" type="number" min="1" placeholder="কত টাকা লাগবে"><button class="btn sm" onclick="lgGoalNew()">➕ নতুন লক্ষ্য</button></div>`;
}
function lgGoalNew() { const n = gv2('gn'), t = +gv2('gt'); if (!n || !(t > 0)) { alert('লক্ষ্যের নাম ও টাকা দিন।'); return; } const l = ledgerData(); l.goals.push({n, target: t, saved: 0}); saveLedger(l); ledgerPage(); }
function lgGoalAdd(i) { const v = +gv2('gd' + i); if (!(v > 0)) return; const l = ledgerData(); l.goals[i].saved += v; saveLedger(l); ledgerPage(); }
function lgGoalDel(i) { if (!confirm('এই লক্ষ্যটি মুছবেন?')) return; const l = ledgerData(); l.goals.splice(i, 1); saveLedger(l); ledgerPage(); }

// ---------- রিমাইন্ডার (কাগজের মেয়াদ ও সার্ভিসিং) ----------
function remData() { return load('remind', {km: 0, docs: [], svc: []}); }
function saveRem(r) { localStorage.setItem('remind', JSON.stringify(r)); }
function daysTo(iso) { return Math.ceil((new Date(iso + 'T00:00:00') - new Date(todayISO() + 'T00:00:00')) / 864e5); }
function remAlerts() {
  const r = remData(), out = [];
  r.docs.forEach(x => { const dl = daysTo(x.date); if (dl <= (x.alert || 30)) out.push({lvl: dl < 0 ? 2 : 1, t: dl < 0 ? `${x.n}: মেয়াদ ${bn(-dl)} দিন আগে শেষ হয়েছে` : `${x.n}: মেয়াদ শেষ হতে ${bn(dl)} দিন বাকি`}); });
  r.svc.forEach(x => {
    const kmLeft = x.lastKm + x.everyKm - r.km, dl = x.everyDays ? daysTo(addDays(x.lastDate, x.everyDays)) : 9999;
    if (kmLeft <= 0 || dl <= 0) out.push({lvl: 2, t: `${x.n}: বদলানোর সময় হয়ে গেছে!`});
    else if (kmLeft <= 200 || dl <= 15) out.push({lvl: 1, t: `${x.n}: শিগগিরই বদলাতে হবে (${kmLeft <= 200 ? bn(kmLeft) + ' কিমি' : bn(dl) + ' দিন'} বাকি)`});
  });
  return out.sort((a, b) => b.lvl - a.lvl);
}
function addDays(iso, n) { const d = new Date(iso + 'T00:00:00'); d.setDate(d.getDate() + n); const p = x => String(x).padStart(2, '0'); return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate()); }
function alertBanner() {
  const al = remAlerts(); if (!al.length) return '';
  return `<div class="tip" style="background:#fef2f2;border-color:#dc2626;color:#7f1d1d;cursor:pointer" onclick="push(()=>home());remindPage()"><div><b>⏰ রিমাইন্ডার</b>${al.slice(0, 3).map(x => `<div>${esc(x.t)}</div>`).join('')}${al.length > 3 ? `<div>আরও ${bn(al.length - 3)}টি...</div>` : ''}</div></div>`;
}
function remindPage() {
  tab = 'home'; const r = remData(), al = remAlerts();
  render(pageHead('রিমাইন্ডার') + `<div class="pad">
    ${al.length ? `<div class="warn" style="margin:0 0 10px;background:#fee2e2;border-color:#f87171;color:#991b1b">${al.map(x => `<div>${x.lvl === 2 ? '🚨' : '⚠️'} ${esc(x.t)}</div>`).join('')}</div>` : '<div class="warn" style="margin:0 0 10px;background:#ecfdf5;border-color:#6ee7b7;color:#065f46">✅ এখন কোনো সতর্কতা নেই।</div>'}
    <div class="sec"><b>🚗 গাড়ির বর্তমান কিলোমিটার</b><input class="inp" id="rk" type="number" min="0" value="${r.km || ''}" placeholder="মিটারে যা দেখাচ্ছে"><button class="btn sm" onclick="setKm()">আপডেট</button></div>
    <div class="sec"><b>📄 কাগজের মেয়াদ</b>${r.docs.map((x, i) => `<div class="note" style="display:flex;justify-content:space-between"><span>${esc(x.n)}<br><small>শেষ: ${esc(x.date)}</small></span><a href="#" onclick="delRem('docs',${i});return false">✕</a></div>`).join('')}
      <select class="inp" id="dn"><option>ড্রাইভিং লাইসেন্স</option><option>ফিটনেস সার্টিফিকেট</option><option>ট্যাক্স টোকেন</option><option>ইনসিওরেন্স</option><option>রুট পারমিট</option></select>
      <label style="font-size:13px">মেয়াদ শেষের তারিখ</label><input class="inp" id="dd" type="date">
      <label style="font-size:13px">কত দিন আগে সতর্ক করবে</label><select class="inp" id="da"><option value="30">৩০ দিন আগে</option><option value="15">১৫ দিন আগে</option></select>
      <button class="btn sm" onclick="addDoc()">যোগ করুন</button></div>
    <div class="sec"><b>🔧 সার্ভিসিং / যন্ত্রাংশ বদলের হিসাব</b>${r.svc.map((x, i) => `<div class="note" style="display:flex;justify-content:space-between"><span>${esc(x.n)}<br><small>শেষ বদল: ${bn(x.lastKm)} কিমি, ${esc(x.lastDate)} · প্রতি ${bn(x.everyKm)} কিমি${x.everyDays ? ' / ' + bn(x.everyDays) + ' দিন' : ''}</small></span><a href="#" onclick="delRem('svc',${i});return false">✕</a></div>`).join('')}
      <select class="inp" id="sn2"><option>ইঞ্জিন অয়েল (মোবিল)</option><option>ব্রেক প্যাড</option><option>টায়ার</option><option>এয়ার ফিল্টার</option><option>ব্যাটারি</option><option>স্পার্ক প্লাগ</option></select>
      <input class="inp" id="sk" type="number" min="0" placeholder="যে কিলোমিটারে বদলেছেন">
      <label style="font-size:13px">বদলের তারিখ</label><input class="inp" id="sd" type="date" value="${todayISO()}">
      <input class="inp" id="se" type="number" min="1" placeholder="কত কিমি পর পর বদলাবেন (যেমন: ৫০০০)">
      <input class="inp" id="sy" type="number" min="1" placeholder="অথবা কত দিন পর (ঐচ্ছিক)">
      <button class="btn sm" onclick="addSvc()">যোগ করুন</button></div>
    <div class="warn">অ্যাপ খুললেই সতর্কতা হোমে দেখাবে। ফোনের নোটিফিকেশন ভবিষ্যতে যোগ করা যাবে।</div></div>`);
}
function setKm() { const r = remData(); r.km = parseFloat(document.getElementById('rk').value) || 0; saveRem(r); remindPage(); }
function addDoc() {
  const date = document.getElementById('dd').value; if (!date) { alert('তারিখ দিন।'); return; }
  const r = remData(); r.docs.push({n: document.getElementById('dn').value, date, alert: parseInt(document.getElementById('da').value)}); saveRem(r); remindPage();
}
function addSvc() {
  const lastKm = parseFloat(document.getElementById('sk').value), everyKm = parseFloat(document.getElementById('se').value), ed = parseInt(document.getElementById('sy').value) || 0;
  if (!(lastKm >= 0) || !(everyKm > 0) || document.getElementById('sk').value === '') { alert('কিলোমিটার ও কত কিমি পর পর বদলাবেন তা দিন।'); return; }
  const r = remData(); r.svc.push({n: document.getElementById('sn2').value, lastKm, lastDate: document.getElementById('sd').value || todayISO(), everyKm, everyDays: ed}); saveRem(r); remindPage();
}
function delRem(k, i) { const r = remData(); r[k].splice(i, 1); saveRem(r); remindPage(); }

// ---------- মডেল টেস্ট ----------
let qi = 0, score = 0, answered = false, order = [];
function startQuiz() {
  tab = 'quiz'; qi = 0; score = 0; order = QUIZ.map((_, i) => i).sort(() => Math.random() - .5); quizQ();
}
function quizQ() {
  answered = false;
  const q = QUIZ[order[qi]];
  render(pageHead('মডেল টেস্ট', false) + `<div class="pad quiz">
    <div style="display:flex;justify-content:space-between;color:#666"><span>প্রশ্ন ${bn(qi+1)} / ${bn(QUIZ.length)}</span>
      <button class="btn sm" onclick="readQuiz()">🔊 প্রশ্ন শুনুন</button></div>
    <h3 style="color:var(--pink)">${esc(q[0])}</h3>` +
    q[1].map((o, i) => `<div class="opt" id="o${i}" onclick="pick(${i})">${esc(o)}</div>`).join('') +
    '<div id="nx" style="text-align:right;margin-top:12px"></div></div>');
}
function readQuiz() { const q = QUIZ[order[qi]]; speak(q[0] + '। ' + q[1].join('। ')); }
function pick(i) {
  if (answered) return; answered = true;
  const q = QUIZ[order[qi]];
  if (i === q[2]) score++; else document.getElementById('o' + i).classList.add('no');
  document.getElementById('o' + q[2]).classList.add('ok');
  document.getElementById('nx').innerHTML = (q[3] ? `<div class="warn" style="text-align:left;margin:10px 0">💡 ${esc(q[3])}</div>` : '') + `<button class="btn" onclick="nextQ()">${qi+1<QUIZ.length?'পরের প্রশ্ন →':'ফলাফল দেখুন'}</button>`;
}
function nextQ() { qi++; qi < QUIZ.length ? quizQ() : result(); }
function result() {
  const pass = score / QUIZ.length >= .7;
  if (score > load('best', 0)) localStorage.setItem('best', JSON.stringify(score));
  render(pageHead('ফলাফল', false) + `<div class="pad" style="text-align:center">
    <div style="font-size:64px">${pass?'🏆':'📚'}</div>
    <h2>আপনার স্কোর: ${bn(score)} / ${bn(QUIZ.length)}</h2>
    <p>${pass?'অভিনন্দন! আপনি পাস করেছেন।':'আরও অনুশীলন করুন, আবার চেষ্টা করুন।'}</p>
    <button class="btn" onclick="startQuiz()">আবার চেষ্টা করুন</button></div>`);
}

// ---------- ডিজিটাল সিভি ও প্রোফাইল ----------
function profile() {
  tab = 'profile'; stack = [];
  const p = load('cv', null);
  render(pageHead('প্রোফাইল', false) + `<div class="profile"><div class="avatar">👤</div><h3>${esc(p ? p.name : 'আপনার নাম')}</h3></div>` +
    (p ? `<div class="cvcard"><b>${esc(p.name)}</b><div>📞 ${esc(p.phone)}</div><div>🪪 লাইসেন্স: ${esc(p.lic)} (${esc(p.exp || '০')} বছর অভিজ্ঞতা)</div><div>📍 এলাকা: ${esc(p.city || '—')}</div></div>`
       : '<div class="empty">এখনো সিভি বানানো হয়নি</div>') +
    `<div style="text-align:center"><button class="btn" onclick="openCv()">${p ? 'তথ্য আপডেট করুন' : 'ডিজিটাল সিভি বানান'}</button></div>` +
    `<div class="box" style="text-align:center"><b>☁️ ${cloudInfo() ? 'লগইন করা: ' + esc(cloudInfo().name || cloudInfo().id) : 'লগইন ও ব্যাকআপ'}</b><div style="font-size:13px;color:#666;margin:4px 0 8px">ফোন হারালে বা অ্যাপ মুছে গেলে তথ্য ফিরে পেতে</div><button class="btn sm" onclick="push(()=>profile());accountPage()">${cloudInfo() ? 'অ্যাকাউন্ট দেখুন' : 'লগইন করুন'}</button>${cloudInfo() && typeof adminPage === 'function' ? ' <button class="btn sm" style="background:#b45309" onclick="push(()=>profile());adminPage()">🛡️ অ্যাডমিন প্যানেল</button>' : ''}</div>` +
    (typeof ucolorBox === 'function' ? ucolorBox() : '') + fileBackupBox() +
    `<div class="box" style="text-align:center"><b>🌐 ভাষা</b><div style="margin-top:8px"><button class="btn sm" style="${LANG === 'bn' ? '' : 'background:#64748b'}" onclick="LANG!=='bn'&&toggleLang()">বাংলা</button> <button class="btn sm" style="${LANG === 'en' ? '' : 'background:#64748b'}" onclick="LANG!=='en'&&toggleLang()">English</button></div></div>`);
}
function openCv() {
  const p = load('cv', {name:'', phone:'', lic:'হালকা (Light)', exp:'', city:''});
  const lics = ['হালকা (Light)','মধ্যম (Medium)','ভারী (Heavy)','মোটরসাইকেল'];
  showModal(`<h3>🪪 চালক ডিজিটাল সিভি</h3>
    <label>পূর্ণ নাম</label><input class="inp" id="cv-name" value="${esc(p.name)}" placeholder="যেমন: মো. রফিকুল ইসলাম">
    <label>মোবাইল নম্বর</label><input class="inp" id="cv-phone" type="tel" value="${esc(p.phone)}" placeholder="০১৭XXXXXXXX">
    <label>লাইসেন্স টাইপ</label><select class="inp" id="cv-lic">${lics.map(l => `<option ${l===p.lic?'selected':''}>${l}</option>`).join('')}</select>
    <label>অভিজ্ঞতা (বছর)</label><input class="inp" id="cv-exp" type="number" value="${esc(p.exp)}">
    <label>বর্তমান এলাকা / শহর</label><input class="inp" id="cv-city" value="${esc(p.city)}" placeholder="যেমন: মিরপুর, ঢাকা">
    <button class="btn" style="width:100%;margin-top:12px" onclick="saveCv()">সংরক্ষণ করুন</button>`);
}
function saveCv() {
  const v = id => document.getElementById(id).value.trim();
  if (!v('cv-name') || !v('cv-phone')) { alert('নাম ও মোবাইল নম্বর দিন।'); return; }
  localStorage.setItem('cv', JSON.stringify({name:v('cv-name'), phone:v('cv-phone'), lic:v('cv-lic'), exp:v('cv-exp'), city:v('cv-city')}));
  closeModal(); if (tab === 'profile') profile(); else alert('সিভি সংরক্ষিত হয়েছে। প্রোফাইল ট্যাবে দেখুন।');
}

// ---------- মোডাল ----------
function showModal(html) {
  closeModal();
  const m = document.createElement('div'); m.id = 'modal'; m.className = 'modal';
  m.innerHTML = `<div class="mbox"><button class="mx" onclick="closeModal()">✕</button>${html}</div>`;
  m.addEventListener('click', e => { if (e.target === m) closeModal(); });
  document.body.appendChild(m);
}
function closeModal() { const m = document.getElementById('modal'); if (m) m.remove(); }

// ---------- নেভিগেশন ----------
function go(t) {
  closeModal(); speechSynthesis && speechSynthesis.cancel && speechSynthesis.cancel();
  if (t === 'home') return home();
  stack = [];
  if (t === 'study') return studyPage();
  if (t === 'quiz') return startQuiz();
  if (t === 'job') return jobsPage();
  if (t === 'profile') return profile();
}

document.addEventListener('backbutton', () => { if (document.getElementById('modal')) closeModal(); else if (stack.length) back(); });
home();
fetchJobs();
(function () {
  const s = document.createElement('div'); s.id = 'splash';
  s.innerHTML = `<div class="sp-logo">${appLogoHtml()}</div><div class="sp-t">${esc(appName())}</div>${bismOn() ? '<div class="bism">بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ<small>পরম করুণাময় অসীম দয়ালু আল্লাহর নামে শুরু করছি</small></div>' : ''}`;
  document.body.appendChild(s);
  setTimeout(() => { s.classList.add('out'); setTimeout(() => s.remove(), 500); }, bismOn() ? 2000 : 900);
})();
setTimeout(() => { try { loginNudge(); } catch (e) {} }, 1600);


// ---------- ফোনের ব্যাক বাটন (অ্যাপ থেকে সরাসরি বেরিয়ে যাওয়া আটকায়) ----------
(function () {
  let lastBack = 0;
  function onBack() {
    const m = document.getElementById('modal'); if (m) return closeModal();
    const d = document.getElementById('drw'); if (d && d.classList.contains('open')) return toggleDrawer();
    if (stack.length) return back();
    if (tab !== 'home') return home();
    const now = Date.now();
    if (now - lastBack < 2000) { try { exitApp(); } catch (e) {} return; }
    lastBack = now; toast_('বেরিয়ে যেতে আবার ব্যাক চাপুন');
  }
  function toast_(t) {
    const e = document.createElement('div'); e.textContent = t;
    e.style.cssText = 'position:fixed;left:50%;bottom:90px;transform:translateX(-50%);background:#1F2329;color:#fff;padding:10px 16px;border-radius:20px;font-size:14px;z-index:99999;max-width:80%;text-align:center';
    document.body.appendChild(e); setTimeout(() => e.remove(), 1800);
  }
  let APP = null; const exitApp = () => APP && APP.exitApp && APP.exitApp();
  try {
    if (window.Capacitor && Capacitor.registerPlugin) {
      APP = Capacitor.registerPlugin('App');
      APP.addListener('backButton', onBack);
    }
  } catch (e) {}
  // ব্রাউজার/অন্য পরিবেশে: history ব্যবহার করা হয় না, তাই কিছু করার নেই
  window.__onBack = onBack; window.__exit = exitApp;
})();

// অ্যাডমিনের বানানো ভিতরের পাতা, বিজ্ঞাপন ও খবরের লাইন সব পাতায় জোড়া
(function () {
  const r0 = render, o0 = open_;
  render = function (h) { r0(h); if (typeof renderBars === 'function') renderBars(); };
  open_ = function (id) { o0(id); if (typeof injectKids === 'function' && id.indexOf('sec_') !== 0) injectKids(id); };
  if (typeof renderBars === 'function') renderBars();
})();

// ---------- ফাইলে ব্যাকআপ ও ফিরিয়ে আনা ----------
function fileBackupBox() {
  return `<div class="box" style="text-align:center"><b>💾 ফাইলে ব্যাকআপ</b><div style="font-size:13px;color:#666;margin:4px 0 8px">আপনার খাতা, সিভি, রিমাইন্ডার ইত্যাদি একটি ফাইলে রাখুন। চাইলে Google Drive বা WhatsApp এ পাঠিয়ে রাখতে পারবেন।</div>
    <button class="btn sm" onclick="fileBackup()">⬇️ ব্যাকআপ ফাইল নিন</button> <button class="btn sm" style="background:#475569" onclick="document.getElementById('bkfile').click()">⬆️ ফাইল থেকে ফিরিয়ে আনুন</button>
    <input type="file" id="bkfile" accept=".json,application/json" style="display:none" onchange="fileRestore(this)"></div>`;
}
async function fileBackup() {
  const keys = typeof SYNC_KEYS !== 'undefined' ? SYNC_KEYS : ['cv', 'ledger', 'remind', 'sos'], data = {};
  keys.forEach(k => { const v = localStorage.getItem(k); if (v !== null) data[k] = v; });
  const json = JSON.stringify({app: 'chalokbhai', v: 1, at: new Date().toISOString(), data}), name = 'chalok-bhai-backup-' + todayISO() + '.json';
  try {
    const C = window.Capacitor;
    if (C && C.isNativePlatform && C.isNativePlatform()) {
      const FS = C.registerPlugin('Filesystem'), SH = C.registerPlugin('Share');
      const r = await FS.writeFile({path: name, data: json, directory: 'CACHE', encoding: 'utf8'});
      await SH.share({title: 'চালক ভাই ব্যাকআপ', url: r.uri, dialogTitle: 'ব্যাকআপ ফাইল কোথায় রাখবেন?'}); return;
    }
  } catch (e) { if (e && /cancel/i.test(String(e.message || e))) return; }
  const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([json], {type: 'application/json'})); a.download = name; document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 500);
}
function fileRestore(inp) {
  const f = inp.files && inp.files[0]; if (!f) return; const r = new FileReader();
  r.onload = () => {
    try {
      const o = JSON.parse(r.result); if (!o || o.app !== 'chalokbhai' || !o.data) throw 0;
      const keys = typeof SYNC_KEYS !== 'undefined' ? SYNC_KEYS : Object.keys(o.data); const ks = Object.keys(o.data).filter(k => keys.includes(k) && typeof o.data[k] === 'string');
      if (!ks.length) throw 0; if (!confirm('এই ফাইলের তথ্য ফোনের এখনকার তথ্যের জায়গায় বসবে। ঠিক আছে?')) return;
      ks.forEach(k => localStorage.setItem(k, o.data[k])); alert('✅ তথ্য ফিরে এসেছে।'); location.reload();
    } catch (e) { alert('এটি চালক ভাইয়ের ব্যাকআপ ফাইল নয়।'); }
  };
  r.readAsText(f); inp.value = '';
}

// এক চাপে অ্যাপ থেকে সরাসরি বের হওয়া
function exitNow() {
  try { if (window.__exit) window.__exit(); } catch (e) {}
  setTimeout(() => { try { window.close(); } catch (e) {} }, 200);
}
// ওয়েবে ঠিকানার শেষে #admin থাকলে সরাসরি অ্যাডমিন লগইন
if (location.hash === '#admin') setTimeout(() => open_('admin'), 2300);
