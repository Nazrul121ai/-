// কমিউনিটি, চাকরিপ্রার্থী আইডি, নোটিশ বোর্ড ও অ্যাডমিন প্যানেল।
// সবই Firebase (Firestore) এ চলে, তাই firebase-config.js ভরা না থাকলে এগুলো দেখা যায় না।
// নিরাপত্তা আসে Firestore Rules থেকে (SETUP.md)। অ্যাডমিন বাটন দেখা গেলেও অধিকার ছাড়া কিছু লেখা যায় না।
if (typeof CLOUD_ON === 'function' && CLOUD_ON()) {
  [['board', 'নোটিশ বোর্ড', '📢', '#b45309', 'নোটিশ, ভিডিও, অডিও, লেখা'],
   ['community', 'কমিউনিটি', '💬', '#0369a1', 'প্রশ্ন, আলোচনা, মন্তব্য'],
   ['seeker', 'চাকরিপ্রার্থী আইডি', '🪪', '#6d28d9', 'নিজের আইডি বানান']].forEach(a => {
    if (!CATS.some(c => c.id === a[0])) CATS.push({id: a[0], name: a[1], ic: a[2], color: a[3], sub: a[4]});
  });
}

if (!CATS.some(c => c.id === 'contact')) CATS.push({id: 'contact', name: 'যোগাযোগ', ic: '📞', color: '#0f766e', sub: 'ডেভেলপার ও অ্যাডমিন'});

// ---------- সাধারণ সহায়ক ----------
let _acache = {content: [], posts: [], reports: [], seekers: [], admins: []};
const sdate = ts => { try { const d = ts && ts.toDate ? ts.toDate() : new Date(ts); return isNaN(d) ? '' : d.toLocaleDateString('bn-BD'); } catch (e) { return ''; } };
const sbody = h => { const e = document.getElementById('sbody'); if (e) e.innerHTML = h; };
const initial = n => (Array.from(String(n || 'ব'))[0] || 'ব');
async function sme() {
  if (!CLOUD_ON() || !cloudInfo()) return null;
  const f = await fb(); const u = f.auth.currentUser; return u ? {f, u} : null;
}
const sEmpty = (ic, t) => `<div class="empty"><span class="e1">${ic}</span>${esc(t)}</div>`;
function sNeedSetup() { return `<div class="warn">এই অংশ চালু করতে অ্যাপের নির্মাতাকে Firebase সেটআপ করতে হবে।</div>`; }
function sNeedLogin() { return `<div class="cx"><b>🔒 লগইন দরকার</b><div class="hint">এই অংশ ব্যবহারে আগে লগইন করতে হবে। লগইন করলে আপনার সব তথ্য ফোন বদলালেও ফেরত পাবেন।</div><button class="btn" onclick="open_('account')">👤 লগইন / নতুন অ্যাকাউন্ট</button></div>`; }
function sShell(title, tabKey, ic, sub) { tab = tabKey || 'home'; render(pageHead(title) + (ic ? hero(ic, title, sub) : '') + '<div class="pad" id="sbody"><div class="empty"><span class="e1">⏳</span>লোড হচ্ছে...</div></div>'); }
function sErr(e) { return `<div class="warn">⚠️ ${esc((e && e.code === 'permission-denied') ? 'অনুমতি নেই। লগইন করে আবার চেষ্টা করুন।' : 'লোড করা যায়নি। ইন্টারনেট সংযোগ দেখুন।')}</div>`; }
async function sList(f, path, ...cons) {
  const q = f.F.query(f.F.collection(f.db, ...path), ...cons);
  const s = await f.F.getDocs(q); const r = []; s.forEach(d => r.push(Object.assign({id: d.id}, d.data()))); return r;
}

// ---------- ইউজার প্রোফাইল (অ্যাডমিন যোগ করার সময় খোঁজার জন্য) ও লগআউটে ক্লিনআপ ----------
async function upsertProfile(first) {
  const m = await sme(); if (!m) return; const ci = cloudInfo() || {};
  await m.f.F.setDoc(m.f.F.doc(m.f.db, 'profiles', m.u.uid), Object.assign({name: ci.name || '', idKey: loginEmail(ci.id || ''), at: Date.now()}, first ? {first: Date.now()} : {}), {merge: true});
}
(function () {
  const L = cloudLogin, S = cloudSignup, O = cloudLogout;
  cloudLogin = async (...a) => { const r = await L(...a); upsertProfile().catch(() => {}); adminProbe(); return r; };
  cloudSignup = async (...a) => { const r = await S(...a); upsertProfile(true).catch(() => {}); return r; };
  cloudLogout = async (...a) => { const r = await O(...a); try { localStorage.removeItem('isAdmin'); } catch (e) {} return r; };
})();

// ---------- অ্যাডমিন চেনা ----------
async function adminRole() {
  const m = await sme(); if (!m) return null;
  const d = await m.f.F.getDoc(m.f.F.doc(m.f.db, 'admins', m.u.uid));
  if (d.exists()) return (d.data() || {}).role || 'admin';
  // Rules এ নাম থাকা মালিকদের জন্য: শুধু অ্যাডমিন এই ডকুমেন্ট পড়তে পারে
  try { await m.f.F.getDoc(m.f.F.doc(m.f.db, 'meta', 'adm')); return 'owner'; } catch (e) { if (e && e.code === 'permission-denied') return null; throw e; }
}
async function adminProbe() {
  try { const r = await adminRole(); try { r ? localStorage.setItem('isAdmin', r) : localStorage.removeItem('isAdmin'); } catch (e) {} } catch (e) {}
}
const isAdminFlag = () => { try { return !!localStorage.getItem('isAdmin'); } catch (e) { return false; } };

// ---------- অ্যাডমিনের প্রকাশ করা কনটেন্ট (লগইন ছাড়াই সবাই দেখে, অফলাইনে শেষ কপি থাকে) ----------
let ADMIN_CONTENT = []; try { ADMIN_CONTENT = JSON.parse(localStorage.getItem('adminContent') || '[]'); } catch (e) {}
const TYPE_LBL = {notice: '📢 নোটিশ', section: '🧩 নতুন সেকশন', tip: '💡 টিপস', article: '📝 লেখা', video: '🎬 ভিডিও', audio: '🎧 অডিও', image: '🖼️ ছবি', job: '💼 চাকরি', quiz: '❓ কুইজ প্রশ্ন', contact: '📞 যোগাযোগ', node: '🧱 পাতা / অধ্যায়', ad: '📣 বিজ্ঞাপন', ticker: '📰 খবর'};
const TYPE_SEL = Object.keys(TYPE_LBL).filter(k => !['contact', 'config', 'ad', 'ticker'].includes(k));
const TYPE_BG = {notice: '#fef3c7', section: '#dbeafe', tip: '#fef9c3', article: '#dcfce7', video: '#fee2e2', audio: '#ede9fe', image: '#fce7f3', job: '#e0f2fe', quiz: '#ffedd5'};
const TILE_COL = ['#0369a1', '#b45309', '#6d28d9', '#15803d', '#be123c', '#0f766e'];
const mapRow = r => ({id: r.id, type: r.type, title: r.title, body: r.body, url: r.url, sub: r.sub, ic: r.ic, mt: r.mt, pin: !!r.pin, pub: r.pub !== false, at: r.createdAt && r.createdAt.toMillis ? r.createdAt.toMillis() : (+r.createdAt || 0), job: r.job || null, contact: r.contact || null, cfg: r.cfg || null, quiz: r.quiz || null, img: r.img || '', parent: r.parent || '', titleEn: r.titleEn || '', bodyEn: r.bodyEn || '', lang: r.lang || 'auto', color: r.color || '', ord: +r.ord || 0, slot: r.slot || '', label: r.label || '', pd: r.pd || '', exp: r.exp || '', credit: r.credit || ''});

function hidSafe() { try { const h = APPCFG().hidden || {}; return {d: h.d || [], q: h.q || [], t: h.t || []}; } catch (e) { return {d: [], q: [], t: []}; } }
let _tipBase = null;
function applyTips() {
  if (typeof TIPS === 'undefined') return;
  if (!_tipBase) _tipBase = TIPS.slice();
  const extra = ADMIN_CONTENT.filter(c => c.type === 'tip' && c.body).map(c => c.body);
  const hd = hidSafe().t; TIPS.length = 0; _tipBase.filter(t => !hd.includes(t)).concat(extra).forEach(t => TIPS.push(t)); if (!TIPS.length) TIPS.push('নিরাপদে গাড়ি চালান।');
}
applyTips();

let _quizBase = null;
function applyQuiz() {
  if (typeof QUIZ === 'undefined') return;
  if (!_quizBase) _quizBase = QUIZ.slice();
  const extra = ADMIN_CONTENT.filter(c => c.type === 'quiz' && c.quiz && Array.isArray(c.quiz.o) && c.title).map(c => { const right = c.quiz.o[+c.quiz.a || 0], o = c.quiz.o.filter(Boolean); return [c.title, o, Math.max(0, o.indexOf(right)), c.quiz.e || '']; }).filter(q => q[1].length >= 2);
  const hq = hidSafe().q; QUIZ.length = 0; _quizBase.filter(q => !hq.includes(q[0])).concat(extra).forEach(q => QUIZ.push(q)); if (!QUIZ.length) _quizBase.slice(0, 1).forEach(q => QUIZ.push(q));
}
applyQuiz();

async function refreshContent() {
  if (!CLOUD_ON() || !navigator.onLine) return;
  try {
    const f = await fb();
    const rows = await sList(f, ['content'], f.F.orderBy('createdAt', 'desc'), f.F.limit(500));
    const next = rows.map(mapRow).filter(r => r.pub);
    const changed = JSON.stringify(next) !== JSON.stringify(ADMIN_CONTENT);
    ADMIN_CONTENT = next; applyTips(); applyQuiz(); applyTheme(); renderBars();
    try { localStorage.setItem('adminContent', JSON.stringify(ADMIN_CONTENT)); } catch (e) {
      try { localStorage.setItem('adminContent', JSON.stringify(ADMIN_CONTENT.map(c => Object.assign({}, c, {img: ['config', 'ad'].includes(c.type) ? c.img : ''})))); } catch (e2) {}
    }
    // হোমে থাকলে ও কিছু বদলালে নতুন আইকন/নোটিশ দেখাতে হোম আবার আঁকা
    const q = document.getElementById('q');
    if (changed && tab === 'home' && !stack.length && q && !q.value && !document.getElementById('modal')) home();
  } catch (e) {}
}
setTimeout(() => { if (CLOUD_ON()) { if (cloudInfo()) adminProbe(); refreshContent(); } }, 2500);

// চাকরির তালিকায় মেশানোর জন্য (app.js এর activeJobs ডাকে)
function adminJobs() {
  return ADMIN_CONTENT.filter(c => c.type === 'job' && c.job).map(c => Object.assign({kind: 'local', t: c.title, d: c.body || ''}, c.job));
}
// হোমের নতুন আইকন (অ্যাডমিনের বানানো সেকশন)
function adminTiles() {
  return ADMIN_CONTENT.filter(c => c.type === 'section' && c.title).map((c, i) => ({id: 'sec_' + c.id, name: c.title, ic: c.ic || '📌', color: TILE_COL[i % TILE_COL.length], sub: c.sub || ''}));
}
// হোমে পিন করা নোটিশ
function homeNotice() {
  const n = ADMIN_CONTENT.find(c => c.type === 'notice' && c.pin && !isExp(c)); if (!n) return '';
  let d = []; try { d = JSON.parse(localStorage.getItem('noticeX') || '[]'); } catch (e) {}
  if (d.includes(n.id)) return '';
  return `<div class="pin" onclick="boardItem('${esc(n.id)}')"><button class="x" onclick="event.stopPropagation();noticeX('${esc(n.id)}')">✕</button><b>📢 ${esc(n.title || '')}</b>${esc((n.body || '').slice(0, 110))}</div>`;
}
function noticeX(id) { let d = []; try { d = JSON.parse(localStorage.getItem('noticeX') || '[]'); } catch (e) {} d.push(id); try { localStorage.setItem('noticeX', JSON.stringify(d.slice(-30))); } catch (e) {} home(); }

function mediaHtml(c) {
  const pic = okImg(c.img) ? `<img loading="lazy" src="${c.img}" style="max-width:100%;border-radius:14px;display:block;margin-bottom:8px">` : '';
  const u = safeUrl(c.url); if (!u) return pic;
  const t = c.mt && c.mt !== 'none' ? c.mt : c.type;
  const yt = u.match(/(?:youtu\.be\/|[?&]v=|embed\/|shorts\/)([\w-]{11})/);
  if (yt && t !== 'audio' && t !== 'image') return pic + `<iframe style="width:100%;aspect-ratio:16/9;border:0;border-radius:14px" src="https://www.youtube.com/embed/${yt[1]}" allowfullscreen></iframe>`;
  if (t === 'video') return pic + `<video controls playsinline preload="none" src="${esc(u)}" style="width:100%;border-radius:14px"></video>`;
  if (t === 'audio') return pic + `<audio controls preload="none" src="${esc(u)}" style="width:100%"></audio>`;
  if (t === 'image') return pic + `<img loading="lazy" src="${esc(u)}" style="max-width:100%;border-radius:14px">`;
  if (t === 'pdf' || (t !== 'none' && isPdfUrl(u))) return pic + pdfInline(u);
  return pic;
}
const isPdfUrl = u => /\.pdf($|[?#])|drive\.google\.com\/file|docs\.google\.com\/(document|presentation)/i.test(u || '');
const isYtUrl = u => /(?:youtu\.be\/|youtube\.com\/)/i.test(u || '');
const linkBtn = u => safeUrl(u) ? `<a class="btn" style="display:block;text-align:center;text-decoration:none;margin-top:12px" href="${esc(safeUrl(u))}" target="_blank" rel="noopener" onclick="goUrl(this.getAttribute('href'));return false">${isPdfUrl(u) ? '📄 PDF খুলুন' : isYtUrl(u) ? '▶️ YouTube এ দেখুন' : '🔗 খুলুন'}</a>` : '';
const speakBtn = t => `<button class="btn sm" style="margin-top:10px" onclick="speak(${JSON.stringify(String(t || '')).replace(/"/g, '&quot;')})">🔊 শুনুন</button>`;

function boardPage(flt = '') {
  tab = 'home';
  const list = ADMIN_CONTENT.filter(c => ['notice', 'article', 'video', 'audio', 'image'].includes(c.type) && (!flt || c.type === flt));
  const chips = `<div class="seg">${['', 'notice', 'article', 'video', 'audio', 'image'].map(t => `<button class="${flt === t ? 'on' : ''}" onclick="boardPage('${t}')">${t ? TYPE_LBL[t] : 'সব'}</button>`).join('')}</div>`;
  render(pageHead('নোটিশ বোর্ড') + hero('📢', 'নোটিশ বোর্ড', 'নতুন নিয়ম, ভিডিও, অডিও ও দরকারি লেখা') + '<div class="pad">' + chips +
    (list.length ? list.map(c => `<div class="bi" onclick="boardItem('${esc(c.id)}')"><div class="bic" style="background:${TYPE_BG[c.type] || '#eee'}">${(TYPE_LBL[c.type] || '').split(' ')[0]}</div><div><b>${esc(c.title || '')}</b><small>${(TYPE_LBL[c.type] || '').split(' ').slice(1).join(' ')} • ${sdate(c.at)}</small></div></div>`).join('') : sEmpty('📭', 'এখনো কিছু নেই। ইন্টারনেট থাকলে নতুন কনটেন্ট নিজে থেকে আসবে।')) +
    `<button class="btn sm" style="background:#475569" onclick="refreshContent().then(()=>boardPage('${flt}'))">🔄 নতুন আছে কি দেখুন</button></div>`);
  if (CLOUD_ON() && !ADMIN_CONTENT.length) refreshContent().then(() => { if (ADMIN_CONTENT.length) boardPage(flt); });
}
function boardItem(id) {
  const c = ADMIN_CONTENT.find(x => x.id === id); if (!c) return;
  showModal(`<span class="tag" style="background:#b45309">${TYPE_LBL[c.type] || ''}</span><h3 style="margin:8px 0">${esc(c.title || '')}</h3>${mediaHtml(c)}<div class="rich" style="margin-top:8px">${rich(c.body)}</div>${linkBtn(c.url)}${speakBtn(c.body || c.title)}`);
}
function sectionPage(id) {
  const c = ADMIN_CONTENT.find(x => x.id === id); tab = 'home';
  if (!c) return render(pageHead('পাতা') + '<div class="pad">' + sEmpty('🔍', 'এই পাতাটি আর নেই।') + '</div>');
  render(pageHead(c.title || '') + hero(c.ic || '📌', c.title || '', c.sub || '') + `<div class="pad"><div class="cx">${mediaHtml(c)}<div class="rich" style="margin-top:${mediaHtml(c) ? 10 : 0}px">${rich(c.body)}</div>${linkBtn(c.url)}${speakBtn(c.body || c.title)}</div></div>`);
  injectKids('sec_' + id);
}

// ---------- কমিউনিটি ----------
let _lastPost = 0;
async function communityPage() {
  sShell('কমিউনিটি', 'home', '💬', 'প্রশ্ন করুন, অভিজ্ঞতা শেয়ার করুন, একে অপরকে সাহায্য করুন');
  if (!CLOUD_ON()) return sbody(sNeedSetup());
  const m = await sme(); if (!m) return sbody(sNeedLogin());
  try {
    const rows = await sList(m.f, ['posts'], m.f.F.orderBy('createdAt', 'desc'), m.f.F.limit(40)); _acache.posts = rows;
    const adm = isAdminFlag();
    sbody(`<div class="cx"><b>✍️ নতুন পোস্ট</b>
      <textarea class="inp" id="ptext" rows="3" maxlength="500" placeholder="প্রশ্ন বা অভিজ্ঞতা লিখুন (সর্বোচ্চ ৫০০ অক্ষর)"></textarea>
      <button class="btn sm" onclick="postNew()">পোস্ট করুন</button>
      <div class="hint" style="margin-top:8px">নিয়ম: গালি, বিজ্ঞাপন, প্রতারণা, ধর্ম বা রাজনীতি নিয়ে উস্কানি ও অন্যের ব্যক্তিগত তথ্য দেওয়া নিষেধ। নিয়ম ভাঙলে পোস্ট মুছে অ্যাকাউন্ট বন্ধ করা হতে পারে।</div></div>` +
      (rows.length ? rows.map((p, i) => `<div class="post"><div class="ph"><div class="av">${esc(initial(p.name))}</div><div><div class="pn">${esc(p.name || 'ব্যবহারকারী')}</div><div class="pd">${sdate(p.createdAt)}</div></div></div>
        <div class="pt">${esc(p.text || '')}</div>
        <div class="pa"><button onclick="openThread(${i})">💬 মন্তব্য</button><button onclick="reportPost(${i})">🚩 রিপোর্ট</button>${(p.uid === m.u.uid || adm) ? `<button class="del" onclick="delPost(${i})">🗑️ মুছুন</button>` : ''}</div></div>`).join('') : sEmpty('💭', 'এখনো কোনো পোস্ট নেই। প্রথম পোস্টটি আপনিই করুন।')));
  } catch (e) { sbody(sErr(e)); }
}
async function postNew() {
  const t = (document.getElementById('ptext').value || '').trim(); if (!t) return;
  if (Date.now() - _lastPost < 30000) return alert('একটু অপেক্ষা করে আবার পোস্ট করুন।');
  const m = await sme(); if (!m) return;
  try { await m.f.F.addDoc(m.f.F.collection(m.f.db, 'posts'), {uid: m.u.uid, name: (cloudInfo() || {}).name || 'ব্যবহারকারী', text: t.slice(0, 500), createdAt: m.f.F.serverTimestamp()}); _lastPost = Date.now(); communityPage(); }
  catch (e) { alert('পোস্ট করা যায়নি। ' + (e.code === 'permission-denied' ? 'আপনার অ্যাকাউন্টে পোস্টের অনুমতি নেই।' : 'ইন্টারনেট দেখুন।')); }
}
async function delPost(i) {
  const p = _acache.posts[i]; if (!p || !confirm('পোস্টটি মুছবেন?')) return;
  const m = await sme(); try { await m.f.F.deleteDoc(m.f.F.doc(m.f.db, 'posts', p.id)); communityPage(); } catch (e) { alert('মোছা যায়নি।'); }
}
async function reportPost(i) {
  const p = _acache.posts[i]; if (!p) return; const why = prompt('রিপোর্টের কারণ লিখুন (যেমন: গালি, বিজ্ঞাপন, প্রতারণা)'); if (why === null) return;
  const m = await sme();
  try { await m.f.F.addDoc(m.f.F.collection(m.f.db, 'reports'), {postId: p.id, postText: String(p.text || '').slice(0, 300), postUid: p.uid, why: String(why).slice(0, 200), by: m.u.uid, createdAt: m.f.F.serverTimestamp()}); alert('রিপোর্ট জমা হয়েছে। ধন্যবাদ।'); }
  catch (e) { alert('রিপোর্ট পাঠানো যায়নি।'); }
}
async function openThread(i) {
  const p = _acache.posts[i]; if (!p) return; window._thr = p.id;
  showModal(`<div class="ph" style="display:flex;gap:10px;align-items:center"><div class="av">${esc(initial(p.name))}</div><b>${esc(p.name || '')}</b></div><div style="white-space:pre-line;margin:8px 0;line-height:1.6">${esc(p.text || '')}</div><hr><div id="thr"><div class="empty">⏳</div></div>
    <input class="inp" id="ctext" maxlength="300" placeholder="আপনার মন্তব্য লিখুন"><button class="btn sm" onclick="addComment()">পাঠান</button>`);
  loadThread();
}
async function loadThread() {
  const m = await sme(); const el = document.getElementById('thr'); if (!m || !el) return;
  try {
    const rows = await sList(m.f, ['posts', window._thr, 'comments'], m.f.F.orderBy('createdAt', 'asc'), m.f.F.limit(100)); window._cm = rows; const adm = isAdminFlag();
    el.innerHTML = rows.length ? rows.map((c, j) => `<div style="margin:8px 0;font-size:14px;background:#f3f5f1;border-radius:12px;padding:8px 10px"><b>${esc(c.name || '')}</b> <span style="font-size:11px;color:#777">${sdate(c.createdAt)}</span>${(c.uid === m.u.uid || adm) ? ` <a href="#" style="color:#dc2626;font-size:12px" onclick="delComment(${j});return false">মুছুন</a>` : ''}<div style="white-space:pre-line">${esc(c.text || '')}</div></div>`).join('') : '<div style="color:#777;font-size:13px">এখনো কোনো মন্তব্য নেই।</div>';
  } catch (e) { el.innerHTML = sErr(e); }
}
async function addComment() {
  const t = (document.getElementById('ctext').value || '').trim(); if (!t) return; const m = await sme(); if (!m) return;
  try { await m.f.F.addDoc(m.f.F.collection(m.f.db, 'posts', window._thr, 'comments'), {uid: m.u.uid, name: (cloudInfo() || {}).name || 'ব্যবহারকারী', text: t.slice(0, 300), createdAt: m.f.F.serverTimestamp()}); document.getElementById('ctext').value = ''; loadThread(); }
  catch (e) { alert('মন্তব্য পাঠানো যায়নি।'); }
}
async function delComment(j) {
  const c = (window._cm || [])[j]; if (!c) return; const m = await sme();
  try { await m.f.F.deleteDoc(m.f.F.doc(m.f.db, 'posts', window._thr, 'comments', c.id)); loadThread(); } catch (e) { alert('মোছা যায়নি।'); }
}

// ---------- চাকরিপ্রার্থী (বেকার) আইডি ----------
const seekerId = uid => 'CB-' + String(uid).slice(0, 6).toUpperCase();
const LIC_OPTS = ['লার্নার / এখনো লাইসেন্স নেই', 'মোটরসাইকেল', 'হালকা (Light)', 'মধ্যম (Medium)', 'ভারী (Heavy)', 'ভারী + পিএসভি'];
async function seekerPage(dist = '') {
  sShell('চাকরিপ্রার্থী আইডি', 'home', '🪪', 'আপনার পরিচয় তৈরি করুন, চাকরিদাতারা আপনাকে খুঁজে পাবেন');
  if (!CLOUD_ON()) return sbody(sNeedSetup());
  const m = await sme(); if (!m) return sbody(sNeedLogin());
  try {
    const mine = await m.f.F.getDoc(m.f.F.doc(m.f.db, 'seekers', m.u.uid));
    const rows = await sList(m.f, ['seekers'], m.f.F.orderBy('createdAt', 'desc'), m.f.F.limit(60)); _acache.seekers = rows;
    const me_ = mine.exists() ? mine.data() : null; const adm = isAdminFlag();
    const shown = rows.filter(r => !dist || String(r.district || '').includes(dist));
    sbody(`<div class="cx"><b>${me_ ? '✅ আপনার আইডি: <span class="sid">' + seekerId(m.u.uid) + '</span>' : '🪪 নিজের চাকরিপ্রার্থী আইডি বানান'}</b>
      <div class="hint">চাকরিদাতা বা মালিকরা এখানে দেখে ড্রাইভার খুঁজতে পারেন। শুধু লগইন করা ব্যবহারকারীরা দেখতে পারে।</div>
      <input class="inp" id="sk_n" placeholder="নাম" value="${esc((me_ && me_.name) || (cloudInfo() || {}).name || '')}">
      <input class="inp" id="sk_d" placeholder="জেলা / এলাকা" value="${esc((me_ && me_.district) || '')}">
      <select class="inp" id="sk_l">${LIC_OPTS.map(o => `<option ${me_ && me_.lic === o ? 'selected' : ''}>${o}</option>`).join('')}</select>
      <input class="inp" id="sk_e" type="number" min="0" max="50" placeholder="অভিজ্ঞতা (বছর)" value="${me_ ? esc(me_.exp || '') : ''}">
      <textarea class="inp" id="sk_a" rows="2" maxlength="200" placeholder="নিজের সম্পর্কে সংক্ষেপে">${esc((me_ && me_.about) || '')}</textarea>
      <input class="inp" id="sk_p" placeholder="ফোন নম্বর (ঐচ্ছিক)" value="${esc((me_ && me_.phone) || '')}">
      <label style="display:block;font-size:14px;margin:6px 0"><input type="checkbox" id="sk_s" ${me_ && me_.showPhone ? 'checked' : ''}>ফোন নম্বর অন্যদের দেখান</label>
      <label style="display:block;font-size:14px;margin:6px 0;line-height:1.5"><input type="checkbox" id="sk_c" ${me_ ? 'checked' : ''}>আমি সম্মতি দিচ্ছি, আমার এই তথ্য লগইন করা অন্য ব্যবহারকারীরা দেখতে পারবে।</label>
      <button class="btn sm" onclick="seekerSave()">💾 সেভ করুন</button>${me_ ? '<button class="btn sm" style="background:#dc2626" onclick="seekerDel()">আইডি মুছুন</button>' : ''}</div>
      <div class="sec-h" style="margin:18px 2px 6px">চাকরিপ্রার্থীদের তালিকা</div>
      <input class="inp" id="sk_f" placeholder="🔍 জেলা দিয়ে খুঁজুন" value="${esc(dist)}" onchange="seekerPage(this.value)">` +
      (shown.length ? shown.map((r, i) => `<div class="cx sk"><div class="top"><span class="sid">${esc(seekerId(r.uid))}</span><b style="display:inline">${esc(r.name || '')}</b></div>
        <span class="pill">📍 ${esc(r.district || '—')}</span><span class="pill">📜 ${esc(r.lic || '—')}</span><span class="pill">⏱️ ${esc(r.exp || 0)} বছর</span>
        ${r.about ? `<div class="hint" style="margin-top:8px">${esc(r.about)}</div>` : ''}${r.showPhone && r.phone ? `<div><a class="btn sm" style="text-decoration:none;display:inline-block;margin-top:8px" href="tel:${esc(String(r.phone).replace(/[^\d+]/g, ''))}">📞 ${esc(r.phone)}</a></div>` : ''}
        ${adm ? `<button class="btn sm" style="background:#dc2626" onclick="seekerAdminDel(${i})">🗑️ মুছুন</button>` : ''}</div>`).join('') : sEmpty('🧑‍✈️', 'কেউ নেই।')));
  } catch (e) { sbody(sErr(e)); }
}
async function seekerSave() {
  const v = id => (document.getElementById(id).value || '').trim();
  if (!document.getElementById('sk_c').checked) return alert('সম্মতির ঘরে টিক দিন।');
  if (!v('sk_n') || !v('sk_d')) return alert('নাম ও জেলা দিন।');
  const m = await sme(); if (!m) return;
  try {
    await m.f.F.setDoc(m.f.F.doc(m.f.db, 'seekers', m.u.uid), {uid: m.u.uid, name: v('sk_n').slice(0, 60), district: v('sk_d').slice(0, 60), lic: v('sk_l'), exp: Math.max(0, Math.min(50, +v('sk_e') || 0)), about: v('sk_a').slice(0, 200), phone: v('sk_p').slice(0, 20), showPhone: document.getElementById('sk_s').checked, createdAt: m.f.F.serverTimestamp()});
    seekerPage();
  } catch (e) { alert('সেভ করা যায়নি।'); }
}
async function seekerDel() { if (!confirm('আপনার আইডি মুছে ফেলবেন?')) return; const m = await sme(); try { await m.f.F.deleteDoc(m.f.F.doc(m.f.db, 'seekers', m.u.uid)); seekerPage(); } catch (e) { alert('মোছা যায়নি।'); } }
async function seekerAdminDel(i) { const r = _acache.seekers[i]; if (!r || !confirm('মুছবেন?')) return; const m = await sme(); try { await m.f.F.deleteDoc(m.f.F.doc(m.f.db, 'seekers', r.uid)); seekerPage(); } catch (e) { alert('মোছা যায়নি।'); } }

// ---------- অ্যাডমিন প্যানেল ----------
let _picked = '', _logoPicked = null, _presetType = '', _presetParent = '';
const gv = id => { const e = document.getElementById(id); return e ? (e.value || '').trim() : ''; };
const chk = id => { const e = document.getElementById(id); return !!(e && e.checked); };
// কোন ধরনে কোন ঘর দেখাবে
const AD_VIS = {
  notice: ['title', 'body', 'url', 'img', 'pin', 'exp'], section: ['title', 'sub', 'ic', 'body', 'img', 'url', 'mt'], tip: ['body'], article: ['title', 'body', 'url', 'img'],
  video: ['title', 'body', 'url', 'img'], audio: ['title', 'body', 'url', 'img'], image: ['title', 'body', 'url', 'img'], job: ['title', 'body', 'job'], quiz: ['title', 'quiz'],
  node: ['parent', 'title', 'titleEn', 'ic', 'color', 'body', 'qb', 'bodyEn', 'lang', 'img', 'url', 'mt', 'ord', 'pd', 'credit', 'h1', 'h2', 'h3', 'h4']
};
const AD_HELP = {
  notice: 'সবাই নোটিশ বোর্ডে দেখবে। "হোমে পিন" দিলে অ্যাপ খুললেই হোমে ভেসে থাকবে।',
  section: 'হোম পাতায় একটি নতুন আইকন যোগ হবে। চাপলে আপনার লেখা, ভিডিও, অডিও বা ছবি খুলবে।',
  tip: '"আজকের টিপস" এর তালিকায় যোগ হবে। শুধু টিপসের লেখাটি দিন।',
  node: 'যেকোনো আইকন বা পাতার ভিতরে নতুন অধ্যায় বা উপ-অধ্যায়। "কোথায় বসবে" ঘরে বেছে নিন। বাংলা ও ইংরেজি দুটোই লিখতে পারেন।',
  quiz: 'মডেল টেস্ট ও আজকের প্রশ্নে যোগ হবে। প্রশ্ন, চারটি উত্তর ও সঠিক উত্তরটি বেছে দিন।', article: 'নোটিশ বোর্ডে লেখা হিসেবে দেখাবে। বড় লেখা দিতে পারবেন।', video: 'YouTube লিংক বা সরাসরি ভিডিও ফাইলের লিংক দিন।',
  audio: 'অডিও ফাইলের (mp3 ইত্যাদি) লিংক দিন।', image: 'ছবির লিংক দিন।', job: 'অ্যাপের চাকরির তালিকায় মিশে যাবে, মেয়াদ শেষে নিজে সরে যাবে।'
};
function adToggle() {
  const t = gv('ad_t'), vis = AD_VIS[t] || [];
  ['parent', 'titleEn', 'bodyEn', 'lang', 'color', 'ord', 'title', 'sub', 'ic', 'body', 'url', 'img', 'mt', 'pin', 'job', 'quiz', 'qb', 'pd', 'credit', 'exp', 'h1', 'h2', 'h3', 'h4'].forEach(k => { const e = document.getElementById('adg_' + k); if (e) e.style.display = vis.includes(k) ? 'block' : 'none'; });
  const h = document.getElementById('ad_help'); if (h) h.textContent = AD_HELP[t] || '';
}
async function adminPage(sec = 'pub', editId = '') {
  sShell('অ্যাডমিন প্যানেল', 'profile', '🛡️', 'অ্যাপের সব কনটেন্ট এখান থেকে বদলান');
  if (!CLOUD_ON()) return sbody(sNeedSetup());
  const m = await sme(); if (!m) return sbody(adminLoginView());
  let role = null; try { role = await adminRole(); } catch (e) { return sbody(sErr(e)); }
  try { role ? localStorage.setItem('isAdmin', role) : localStorage.removeItem('isAdmin'); } catch (e) {}
  if (!role) return sbody(`<div class="cx"><b>আপনি এখনো অ্যাডমিন নন</b><div class="hint">লগইন করা আইডি: <b>${esc((m.u && m.u.email) || '')}</b><br>এটি অ্যাডমিন তালিকার নম্বর বা Gmail না হলে অন্য আইডিতে লগইন করুন। তালিকার আইডি হলে Firebase এ Rules "Publish" হয়েছে কিনা দেখুন।</div><div class="hint">আপনার UID (চেপে ধরে কপি করুন):</div><div style="word-break:break-all;user-select:all;font-family:monospace;background:#f3f5f1;border-radius:10px;padding:8px">${esc(m.u.uid)}</div></div>
    <div class="cx"><b>আপনি অ্যাপের মালিক হলে (একবারের কাজ)</b><ol style="padding-left:20px;font-size:14px;line-height:1.7;margin:6px 0">
    <li>Firebase Console এ Firestore Database → Data খুলুন।</li><li><b>Start collection</b> চাপুন, Collection ID লিখুন: <b>admins</b></li>
    <li>Document ID তে উপরের UID বসান।</li><li>ফিল্ড নাম <b>role</b>, ধরন string, মান <b>owner</b> দিয়ে Save করুন।</li>
    <li>অ্যাপে ফিরে এই পাতা আবার খুলুন।</li></ol></div>
    <button class="btn" onclick="adminPage()">🔄 আবার দেখুন</button>
    <div class="warn">অন্য কেউ অ্যাডমিন হতে চাইলে তার UID মালিককে পাঠাবেন, অথবা মালিক "অ্যাডমিন" ট্যাব থেকে তার মোবাইল নম্বর দিয়ে যোগ করবেন।</div>`);
  const tabs = [['pub', '✍️ নতুন'], ['list', '📚 সব কনটেন্ট'], ['set', '🎨 রং ও পরিচয়'], ['lay', '🧩 সাজানো'], ['qg', '🤖 প্রশ্ন বানান'], ['hid', '🙈 লুকানো'], ['ads', '📣 বিজ্ঞাপন ও খবর'], ['contact', '📞 যোগাযোগ'], ['rep', '🚩 রিপোর্ট'], ['stat', '📊 পরিসংখ্যান'], ['ord', '📨 অর্ডার ও PDF'], ['adm', '👥 অ্যাডমিন']];
  const bar = `<div class="seg">${tabs.map(t => `<button class="${sec === t[0] ? 'on' : ''}" onclick="adminPage('${t[0]}')">${t[1]}</button>`).join('')}</div>`;
  try {
    let h = '';
    if (sec === 'pub') {
      _picked = '';
      let e = null;
      if (editId) { const all = await sList(m.f, ['content'], m.f.F.orderBy('createdAt', 'desc'), m.f.F.limit(200)); _acache.content = all.map(mapRow); e = _acache.content.find(x => x.id === editId) || null; }
      const j = (e && e.job) || {}; const ty = (e && e.type) || _presetType || 'notice'; const pre = (e && e.parent) || _presetParent || ''; _presetType = ''; _presetParent = ''; window._grpFor = _presetGrp || ''; _presetGrp = '';
      h = `<div class="cx"><b>${e ? '✏️ সম্পাদনা' : '✍️ নতুন কনটেন্ট'}</b>
        <select class="inp" id="ad_t" onchange="adToggle()" ${e ? 'disabled' : ''}>${TYPE_SEL.map(k => `<option value="${k}" ${ty === k ? 'selected' : ''}>${TYPE_LBL[k]}</option>`).join('')}</select>
        <div class="hint" id="ad_help"></div>
        <div class="fsh" id="adg_h1">① কোথায় বসবে</div><div id="adg_parent"><div class="hint" style="margin:0 0 4px">কোথায় বসবে (কোন আইকন বা পাতার ভিতরে)</div><select class="inp" id="ad_parent">${parentOpts(pre, e && e.id)}</select>
          <div class="hint" style="margin:6px 0 4px">অথবা <b>নিজে নাম লিখুন</b> (তালিকায় না থাকলে — ওই নামে নতুন আইকন নিজে থেকে তৈরি হবে, যেমন: মেঘনা পরিবহন নিয়োগ)</div><input class="inp" id="ad_newparent" maxlength="60" placeholder="নতুন জায়গার নাম (ঐচ্ছিক)"></div>
        <div class="fsh" id="adg_h2">② শিরোনাম ও লেখা</div><div id="adg_title"><input class="inp" id="ad_title" placeholder="শিরোনাম" value="${esc((e && e.title) || '')}"></div>
        <div id="adg_titleEn"><input class="inp" id="ad_titleEn" placeholder="ইংরেজি শিরোনাম (ঐচ্ছিক)" value="${esc((e && e.titleEn) || '')}"></div>
        <div id="adg_sub"><input class="inp" id="ad_sub" placeholder="ছোট বর্ণনা (আইকনের নিচে বা পাতার উপরে দেখাবে)" value="${esc((e && e.sub) || '')}"></div>
        <div id="adg_body">${bodyTools()}<textarea class="inp" id="ad_body" rows="10" placeholder="লেখা / বিবরণ (বড় লেখাও দিতে পারেন)">${esc((e && e.body) || '')}</textarea><div class="hint">সাজানোর নিয়ম: <b># বড় শিরোনাম</b> • <b>## মাঝারি শিরোনাম</b> • <b>- তালিকার লেখা</b> • <b>**মোটা লেখা**</b></div></div>
        <div id="adg_qb">${qbBox()}</div>
        <div id="adg_exp"><div class="hint" style="margin:0 0 4px">⏳ মেয়াদ শেষের তারিখ (এরপর নিজে সরে যাবে, ঐচ্ছিক)</div><input class="inp" type="date" id="ad_exp" value="${esc((e && e.exp) || '')}"></div>
        <div id="adg_bodyEn"><textarea class="inp" id="ad_bodyEn" rows="6" placeholder="ইংরেজি লেখা (ঐচ্ছিক)">${esc((e && e.bodyEn) || '')}</textarea></div>
        <div id="adg_lang"><select class="inp" id="ad_lang">${[['auto', 'অ্যাপের ভাষা অনুযায়ী দেখাবে'], ['bn', 'শুধু বাংলা'], ['en', 'শুধু ইংরেজি'], ['both', 'বাংলা ও ইংরেজি দুটোই একসাথে']].map(x => `<option value="${x[0]}" ${((e && e.lang) || 'auto') === x[0] ? 'selected' : ''}>${x[1]}</option>`).join('')}</select></div>
        <div class="fsh" id="adg_h3">③ রং, আইকন ও সাজ</div>
        <div id="adg_color"><div class="hint" style="margin:0 0 4px">পাতার রং</div><div class="rowline"><input type="color" id="ad_color" value="${esc((e && e.color) || '#0369a1')}" style="width:56px;height:40px;border:0;background:none;padding:0"><label><input type="checkbox" id="ad_nocolor" ${e && !e.color ? 'checked' : ''}>রং ছাড়া (সাধারণ)</label></div></div>
        <div id="adg_ic"><input class="inp" id="ad_ic" maxlength="4" placeholder="আইকন (একটি ইমোজি, যেমন 🚕)" value="${esc((e && e.ic) || '')}"></div>
        <div id="adg_ord"><input class="inp" id="ad_ord" type="number" placeholder="ক্রম নম্বর (ছোট নম্বর আগে, যেমন ১, ২, ৩)" value="${e && e.ord ? e.ord : ''}"></div>
        <div id="adg_pd"><div class="hint" style="margin:0 0 4px">📅 তারিখ (পুরনো পত্রিকা তারিখ দিয়ে খোঁজার জন্য, ঐচ্ছিক)</div><input class="inp" type="date" id="ad_pd" value="${esc((e && e.pd) || '')}"></div>
        <div id="adg_credit"><input class="inp" id="ad_credit" maxlength="80" placeholder="✍️ নাম / ক্রেডিট (ফাঁকা রাখলে পাতায় দেখাবে না)" value="${esc((e && e.credit) || '')}"></div>
        <div class="fsh" id="adg_h4">④ ছবি, ভিডিও ও ফাইল</div>
        <div id="adg_img"><div class="hint" style="margin:0 0 4px">ছবি (গ্যালারি থেকে বাছুন, নিজে ছোট হয়ে যাবে)</div>${e && okImg(e.img) ? `<img id="ad_imgprev" src="${e.img}" style="max-width:100%;border-radius:12px;margin-bottom:6px"><label style="display:block;margin:4px 0"><input type="checkbox" id="ad_imgdel">ছবিটি সরান</label>` : '<img id="ad_imgprev" style="display:none;max-width:100%;border-radius:12px;margin-bottom:6px">'}<input type="file" id="ad_img" accept="image/*" onchange="adPick(this)"></div>
        <div id="adg_quiz"><input class="inp" id="ad_q1" placeholder="উত্তর ১" value="${esc(((e && e.quiz && e.quiz.o) || [])[0] || '')}"><input class="inp" id="ad_q2" placeholder="উত্তর ২" value="${esc(((e && e.quiz && e.quiz.o) || [])[1] || '')}"><input class="inp" id="ad_q3" placeholder="উত্তর ৩" value="${esc(((e && e.quiz && e.quiz.o) || [])[2] || '')}"><input class="inp" id="ad_q4" placeholder="উত্তর ৪" value="${esc(((e && e.quiz && e.quiz.o) || [])[3] || '')}"><select class="inp" id="ad_qa">${[0, 1, 2, 3].map(i => `<option value="${i}" ${e && e.quiz && +e.quiz.a === i ? 'selected' : ''}>সঠিক উত্তর: ${i + 1} নম্বর</option>`).join('')}</select><input class="inp" id="ad_qe" placeholder="ব্যাখ্যা (ঐচ্ছিক, উত্তর দেওয়ার পর দেখাবে)" value="${esc((e && e.quiz && e.quiz.e) || '')}">
          ${e ? '' : `<div class="hint" style="margin-top:10px"><b>একসাথে অনেক প্রশ্ন দিতে</b> নিচের ঘরে প্রতি লাইনে একটি প্রশ্ন লিখুন (উপরের ঘরগুলো ফাঁকা রাখুন):<br>প্রশ্ন | উত্তর১ | উত্তর২ | উত্তর৩ | উত্তর৪ | সঠিক নম্বর | ব্যাখ্যা<br><span style="color:#6b7280">উদাহরণ: লাল বাতিতে কী করবেন? | থামবেন | যাবেন | হর্ন দেবেন | ধীরে যাবেন | ১ | লাল মানে থামা</span></div><textarea class="inp" id="ad_bulk" rows="6" placeholder="প্রশ্ন | উত্তর১ | উত্তর২ | উত্তর৩ | উত্তর৪ | সঠিক নম্বর | ব্যাখ্যা"></textarea><button type="button" class="btn sm" style="background:#475569" onclick="bulkCheck('ad_bulk')">👁️ আগে যাচাই করুন</button>`}</div>
        <div id="adg_url"><input class="inp" id="ad_url" placeholder="লিংক (YouTube, ভিডিও, অডিও, ছবি বা ওয়েবসাইট)" value="${esc((e && e.url) || '')}"></div>
        <div id="adg_mt"><select class="inp" id="ad_mt"><option value="none">লিংকটি বাটন হিসেবে দেখান</option>${['video', 'audio', 'image', 'pdf'].map(k => `<option value="${k}" ${e && e.mt === k ? 'selected' : ''}>লিংকটি ${{video: 'ভিডিও', audio: 'অডিও', image: 'ছবি', pdf: 'PDF (বাটন)'}[k]} হিসেবে চালান</option>`).join('')}</select></div>
        <div id="adg_pin"><label style="display:block;margin:6px 0"><input type="checkbox" id="ad_pin" ${e && e.pin ? 'checked' : ''}>হোম পাতায় পিন করুন</label></div>
        <div id="adg_job"><input class="inp" id="ad_c" placeholder="কোম্পানি" value="${esc(j.c || '')}"><input class="inp" id="ad_s" placeholder="বেতন" value="${esc(j.s || '')}"><input class="inp" id="ad_lic" placeholder="লাইসেন্স" value="${esc(j.lic || '')}"><input class="inp" id="ad_loc" placeholder="লোকেশন" value="${esc(j.loc || '')}"><input class="inp" id="ad_dl" type="date" value="${esc(j.deadline || '')}"><input class="inp" id="ad_ph" placeholder="ফোন" value="${esc(j.phone || '')}"><select class="inp" id="ad_kind"><option value="local" ${j.kind !== 'foreign' ? 'selected' : ''}>দেশি চাকরি</option><option value="foreign" ${j.kind === 'foreign' ? 'selected' : ''}>বিদেশি চাকরি</option></select></div>
        <label style="display:block;margin:8px 0"><input type="checkbox" id="ad_pub" ${!e || e.pub ? 'checked' : ''}>প্রকাশিত (টিক না থাকলে অ্যাপে লুকানো থাকবে)</label>
        <div id="ad_msg" class="warn" style="display:none"></div>
        <button class="btn" onclick="adSave('${esc(editId)}')">${e ? '💾 আপডেট করুন' : '🚀 প্রকাশ করুন'}</button></div>`;
    } else if (sec === 'list') {
      const all = await sList(m.f, ['content'], m.f.F.orderBy('createdAt', 'desc'), m.f.F.limit(200)); _acache.content = all.map(mapRow);
      h = _acache.content.filter(c => !['contact', 'config', 'ad', 'ticker'].includes(c.type)).length ? _acache.content.map((c, i) => ['contact', 'config', 'ad', 'ticker'].includes(c.type) ? '' : `<div class="cx"><div class="rowline"><span class="tag" style="background:#b45309">${TYPE_LBL[c.type] || c.type}</span>${c.pub ? '' : '<span class="tag">লুকানো</span>'}${c.pin ? '<span class="tag" style="background:#0369a1">📌 পিন</span>' : ''}</div>
        <b style="margin-top:6px">${esc(c.title || (c.body || '').slice(0, 50))}</b><div class="hint">${sdate(c.at)}</div>
        <button class="btn sm" onclick="adminPage('pub','${esc(c.id)}')">✏️ সম্পাদনা</button><button class="btn sm" style="background:#475569" onclick="adHide(${i})">${c.pub ? '🙈 লুকান' : '👁️ দেখান'}</button><button class="btn sm" style="background:#dc2626" onclick="adDel('${esc(c.id)}')">🗑️ মুছুন</button></div>`).join('') : sEmpty('📭', 'কিছু প্রকাশ করা হয়নি। "নতুন" ট্যাব থেকে শুরু করুন।');
    } else if (sec === 'ads') {
      const all = await sList(m.f, ['content'], m.f.F.orderBy('createdAt', 'desc'), m.f.F.limit(500)); _acache.content = all.map(mapRow); h = adsForm();
    } else if (sec === 'hid') {
      h = hidForm();
    } else if (sec === 'qg') {
      const all = await sList(m.f, ['content'], m.f.F.orderBy('createdAt', 'desc'), m.f.F.limit(500)); _acache.content = all.map(mapRow); h = qgForm();
    } else if (sec === 'lay') {
      layInit(); h = layForm();
    } else if (sec === 'set') {
      h = settingsForm();
    } else if (sec === 'contact') {
      const k = contactData();
      h = `<div class="cx"><b>📞 যোগাযোগ পাতার তথ্য</b><div class="hint">ব্যবহারকারীরা "যোগাযোগ" আইকনে চাপলে এগুলো দেখবে। লিংক বা নম্বর পেস্ট করুন, খালি রাখলে ওই বাটন দেখাবে না।</div>
        <input class="inp" id="ct_name" placeholder="নাম" value="${esc(k.name)}">
        <input class="inp" id="ct_role" placeholder="পদ ও প্রতিষ্ঠান" value="${esc(k.role)}">
        <textarea class="inp" id="ct_about" rows="2" placeholder="ছোট পরিচয় বা বার্তা (ঐচ্ছিক)">${esc(k.about)}</textarea>
        <input class="inp" id="ct_fb" placeholder="ফেসবুক লিংক (যেমন https://facebook.com/...)" value="${esc(k.fb)}">
        <input class="inp" id="ct_wa" placeholder="হোয়াটসঅ্যাপ নম্বর (যেমন 017XXXXXXXX) বা wa.me লিংক" value="${esc(k.wa)}">
        <input class="inp" id="ct_mail" placeholder="জিমেইল (যেমন name@gmail.com)" value="${esc(k.mail)}">
        <input class="inp" id="ct_phone" placeholder="ফোন নম্বর (ঐচ্ছিক)" value="${esc(k.phone)}">
        <input class="inp" id="ct_x1n" placeholder="অতিরিক্ত লিংকের নাম (যেমন ইউটিউব, ওয়েবসাইট)" value="${esc(k.x1n)}">
        <input class="inp" id="ct_x1" placeholder="অতিরিক্ত লিংক (https://...)" value="${esc(k.x1)}">
        <div id="ad_msg" class="warn" style="display:none"></div>
        <button class="btn" onclick="adContactSave()">💾 সেভ করুন</button> <button class="btn sm" style="background:#475569" onclick="open_('contact')">👁️ দেখে নিন</button></div>`;
    } else if (sec === 'rep') {
      const rows = await sList(m.f, ['reports'], m.f.F.orderBy('createdAt', 'desc'), m.f.F.limit(50)); _acache.reports = rows;
      h = rows.length ? rows.map((r, i) => `<div class="cx"><div style="white-space:pre-line">${esc(r.postText || '')}</div><div class="hint" style="color:#b45309">কারণ: ${esc(r.why || '')}</div>
        <button class="btn sm" style="background:#dc2626" onclick="repAct(${i},'post')">🗑️ পোস্ট মুছুন</button><button class="btn sm" style="background:#7f1d1d" onclick="repAct(${i},'ban')">🚫 ব্যবহারকারী বন্ধ</button><button class="btn sm" style="background:#64748b" onclick="repAct(${i},'dismiss')">বাতিল</button></div>`).join('') : sEmpty('✅', 'কোনো রিপোর্ট নেই।');
    } else if (sec === 'stat') {
      h = await statView(m);
    } else if (sec === 'ord') {
      h = await orderAdminView(m);
    } else if (sec === 'adm') {
      const rows = await sList(m.f, ['admins']); _acache.admins = rows;
      h = rows.map((a, i) => `<div class="cx"><div class="rowline"><div class="av">${esc(initial(a.name || a.id))}</div><div><b style="display:inline">${esc(a.name || a.id)}</b><br><span class="tag" style="background:${a.role === 'owner' ? '#b45309' : '#0369a1'}">${a.role === 'owner' ? 'মালিক' : 'অ্যাডমিন'}</span></div></div>${(role === 'owner' && a.id !== m.u.uid) ? `<button class="btn sm" style="background:#dc2626;margin-top:8px" onclick="admRemove(${i})">সরান</button>` : ''}</div>`).join('') +
        (role === 'owner' ? `<div class="cx"><b>➕ নতুন অ্যাডমিন যোগ</b><div class="hint">যাকে যোগ করবেন, তাকে আগে অ্যাপে অ্যাকাউন্ট খুলে লগইন করতে হবে। তার মোবাইল নম্বর বা ইমেইল দিন।</div>
          <input class="inp" id="adm_id" placeholder="মোবাইল নম্বর বা ইমেইল"><div id="ad_msg" class="warn" style="display:none"></div><button class="btn sm" onclick="admAdd()">যোগ করুন</button></div>` : '<div class="warn">নতুন অ্যাডমিন যোগ বা সরাতে পারেন শুধু মালিক।</div>');
    }
    sbody(bar + h); if (sec === 'pub') adToggle();
  } catch (e) { sbody(bar + sErr(e)); }
}
function adMsg(t) { const b = document.getElementById('ad_msg'); if (b) { b.style.display = 'block'; b.textContent = t; } }
async function adUpload(m) {
  const fi = document.getElementById('ad_file'); const file = fi && fi.files && fi.files[0]; if (!file) return '';
  if (file.size > 50 * 1024 * 1024) throw {message: 'ফাইল ৫০ মেগাবাইটের বেশি।'};
  const base = `https://www.gstatic.com/firebasejs/${FB_VERSION}/`;
  const S = window.__ST_MOCK || await import(base + 'firebase-storage.js');
  const st = S.getStorage(m.f.app); const safe = file.name.replace(/[^\w.\-]/g, '_');
  const ref = S.ref(st, 'content/' + Date.now() + '_' + safe); adMsg('⏳ আপলোড হচ্ছে...');
  await S.uploadBytes(ref, file); return await S.getDownloadURL(ref);
}
async function adSave(editId) {
  const m = await sme(); if (!m) return; const type = editId ? ((_acache.content.find(x => x.id === editId) || {}).type || gv('ad_t')) : gv('ad_t'); const vis = AD_VIS[type] || [];
  if (vis.includes('title') && !gv('ad_title') && !gv('ad_titleEn') && !(type === 'quiz' && gv('ad_bulk'))) return adMsg('শিরোনাম দিন।');
  if (type === 'tip' && !gv('ad_body')) return adMsg('টিপসের লেখা দিন।');
  try {
    adMsg('⏳ সেভ হচ্ছে...'); let url = vis.includes('url') ? gv('ad_url') : ''; const up = await adUpload(m); if (up) url = up;
    if (url && !safeUrl(url)) return adMsg('লিংকটি ঠিক নয়। যেমন: https://example.com বা www.example.com');
    const d = {type, title: vis.includes('title') ? gv('ad_title').slice(0, 150) : '', body: gv('ad_body').slice(0, 20000), url, pub: chk('ad_pub'), by: m.u.uid};
    if (vis.includes('img')) { const old = editId ? ((_acache.content.find(x => x.id === editId) || {}).img || '') : ''; d.img = _picked || (chk('ad_imgdel') ? '' : old); }
    if (type === 'quiz') {
      const bulk = gv('ad_bulk');
      if (!editId && bulk) {
        const rows = parseQuizBulk(bulk); if (!rows.length) return adMsg('কোনো প্রশ্ন বোঝা যায়নি। প্রতি লাইনে: প্রশ্ন | উত্তর১ | উত্তর২ | ... | সঠিক নম্বর');
        if (rows.length > 100) return adMsg('একবারে সর্বোচ্চ ১০০টি প্রশ্ন দিন।');
        for (const r of rows) await m.f.F.addDoc(m.f.F.collection(m.f.db, 'content'), {type: 'quiz', title: r.q, body: '', url: '', pub: chk('ad_pub'), by: m.u.uid, quiz: {o: r.o, a: r.a, e: r.e}, createdAt: m.f.F.serverTimestamp()});
        await refreshContent(); return adminPage('list');
      }
      const o = [1, 2, 3, 4].map(n => gv('ad_q' + n)).filter(Boolean); const a = +gv('ad_qa') || 0; if (o.length < 2) return adMsg('কমপক্ষে দুটি উত্তর দিন।'); if (!gv('ad_q' + (a + 1))) return adMsg('সঠিক উত্তরের ঘরটি ফাঁকা।'); d.quiz = {o: [1, 2, 3, 4].map(n => gv('ad_q' + n)), a, e: gv('ad_qe').slice(0, 400)};
    }
    if (type === 'section') { d.sub = gv('ad_sub').slice(0, 120); d.ic = Array.from(gv('ad_ic') || '📌').slice(0, 2).join(''); d.mt = gv('ad_mt') || 'none'; }
    if (type === 'notice') { d.pin = chk('ad_pin'); d.exp = gv('ad_exp'); }
    if (type === 'node') {
      d.parent = gv('ad_parent'); const np = gv('ad_newparent');
      if (np && !editId) { const ex = (_acache.content || []).find(c => c.type === 'section' && (c.title || '').trim() === np); if (ex) d.parent = 'sec_' + ex.id; else { const rf = await m.f.F.addDoc(m.f.F.collection(m.f.db, 'content'), {type: 'section', title: np, sub: '', body: '', ic: '📌', mt: 'none', url: '', pub: true, by: m.u.uid, createdAt: m.f.F.serverTimestamp()}); d.parent = 'sec_' + rf.id; } }
      else if (np && editId) { const rf = await m.f.F.addDoc(m.f.F.collection(m.f.db, 'content'), {type: 'section', title: np, sub: '', body: '', ic: '📌', mt: 'none', url: '', pub: true, by: m.u.uid, createdAt: m.f.F.serverTimestamp()}); d.parent = 'sec_' + rf.id; }
      if (!d.parent) return adMsg('কোথায় বসবে তা বেছে নিন বা নাম লিখুন।');
      d.titleEn = gv('ad_titleEn').slice(0, 150); d.bodyEn = gv('ad_bodyEn').slice(0, 20000); d.lang = gv('ad_lang') || 'auto';
      d.pd = gv('ad_pd'); d.credit = gv('ad_credit').slice(0, 80); d.color = chk('ad_nocolor') ? '' : gv('ad_color'); d.ord = +gv('ad_ord') || 0; d.ic = Array.from(gv('ad_ic') || '').slice(0, 2).join(''); d.mt = gv('ad_mt') || 'none';
    }
    if (type === 'job') d.job = {c: gv('ad_c'), s: gv('ad_s'), lic: gv('ad_lic'), loc: gv('ad_loc'), deadline: gv('ad_dl'), phone: gv('ad_ph'), kind: gv('ad_kind') || 'local', url};
    if (editId) await m.f.F.setDoc(m.f.F.doc(m.f.db, 'content', editId), d, {merge: true});
    else { d.createdAt = m.f.F.serverTimestamp(); const ref = await m.f.F.addDoc(m.f.F.collection(m.f.db, 'content'), d); if (type === 'section' && window._grpFor && ref && ref.id) { await grpPlace(ref.id, window._grpFor); } window._grpFor = ''; }
    await refreshContent();
    if (type === 'node' && d.parent) { rebuildStack(d.parent); return reopenKey(d.parent); }
    adminPage('list');
  } catch (e) { adMsg('⚠️ ' + ((e && e.code === 'permission-denied') ? 'অনুমতি নেই।' : (e && e.message) || 'সেভ হয়নি।')); }
}
async function adHide(i) {
  const c = _acache.content[i]; if (!c) return; const m = await sme();
  try { await m.f.F.setDoc(m.f.F.doc(m.f.db, 'content', c.id), {pub: !c.pub}, {merge: true}); await refreshContent(); adminPage('list'); } catch (e) { alert('বদলানো যায়নি।'); }
}
async function adDel(id) { if (!confirm('মুছে ফেলবেন?')) return; const m = await sme(); try { await m.f.F.deleteDoc(m.f.F.doc(m.f.db, 'content', id)); await refreshContent(); adminPage('list'); } catch (e) { alert('মোছা যায়নি।'); } }
async function repAct(i, act) {
  const r = _acache.reports[i]; if (!r) return; const m = await sme(); const D = m.f.F;
  try {
    if (act === 'post') await D.deleteDoc(D.doc(m.f.db, 'posts', r.postId));
    if (act === 'ban') { if (!confirm('এই ব্যবহারকারী আর পোস্ট বা মন্তব্য করতে পারবে না। নিশ্চিত?')) return; await D.setDoc(D.doc(m.f.db, 'banned', r.postUid), {at: Date.now(), by: m.u.uid}); }
    await D.deleteDoc(D.doc(m.f.db, 'reports', r.id)); adminPage('rep');
  } catch (e) { alert('কাজটি করা যায়নি।'); }
}
async function admAdd() {
  const key = loginEmail(gv('adm_id')); if (!key) return adMsg('সঠিক মোবাইল নম্বর বা ইমেইল দিন।');
  const m = await sme();
  try {
    const rows = await sList(m.f, ['profiles'], m.f.F.where('idKey', '==', key));
    if (!rows.length) return adMsg('এই আইডির কাউকে পাওয়া যায়নি। তাকে আগে অ্যাপে অ্যাকাউন্ট খুলে লগইন করতে বলুন।');
    await m.f.F.setDoc(m.f.F.doc(m.f.db, 'admins', rows[0].id), {role: 'admin', name: rows[0].name || '', by: m.u.uid, at: Date.now()}); adminPage('adm');
  } catch (e) { adMsg('⚠️ যোগ করা যায়নি।'); }
}
async function admRemove(i) {
  const a = _acache.admins[i]; if (!a || !confirm('এই অ্যাডমিনকে সরাবেন?')) return; const m = await sme();
  try { await m.f.F.deleteDoc(m.f.F.doc(m.f.db, 'admins', a.id)); adminPage('adm'); } catch (e) { alert('সরানো যায়নি।'); }
}


// ---------- যোগাযোগ পাতা ----------
const CONTACT_DEF = {name: 'নজরুল ইসলাম', role: 'জিএসসি অপারেটর, বিমান বাংলাদেশ এয়ারলাইন্স', about: 'এই অ্যাপের নির্মাতা। কোনো প্রশ্ন, পরামর্শ বা সমস্যা থাকলে জানাতে পারেন।', fb: '', wa: '', mail: '', phone: '', x1n: '', x1: ''};
function contactData() {
  const c = ADMIN_CONTENT.find(x => x.type === 'contact'); const k = (c && c.contact) || {};
  const o = Object.assign({}, CONTACT_DEF);
  Object.keys(CONTACT_DEF).forEach(f => { if (k[f] !== undefined && k[f] !== null) o[f] = k[f]; });
  if (c && c.title) o.name = c.title; if (c && c.body) o.role = c.body;
  return o;
}
function ctDigits(v) { let d = String(v || '').replace(/[০-৯]/g, ch => '০১২৩৪৫৬৭৮৯'.indexOf(ch)).replace(/\D/g, ''); if (d.startsWith('00')) d = d.slice(2); if (d.startsWith('0')) d = '88' + d; return d; }
const ctFb = v => { v = String(v || '').trim(); if (!v) return ''; if (/^https?:\/\//i.test(v)) return v; if (/^(www\.)?(facebook|fb)\.com/i.test(v)) return 'https://' + v; return /^[\w.\-]+$/.test(v.replace(/^@/, '')) ? 'https://facebook.com/' + v.replace(/^@/, '') : ''; };
const ctWa = v => { v = String(v || '').trim(); if (!v) return ''; if (/^https?:\/\//i.test(v)) return v; const d = ctDigits(v); return d.length >= 10 ? 'https://wa.me/' + d : ''; };
const ctMail = v => { v = String(v || '').trim().replace(/^mailto:/i, ''); return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v) ? 'mailto:' + v : ''; };
const ctTel = v => { const d = String(v || '').replace(/[০-৯]/g, ch => '০১২৩৪৫৬৭৮৯'.indexOf(ch)).replace(/[^\d+]/g, ''); return d.length >= 6 ? 'tel:' + d : ''; };
function contactPage() {
  tab = 'profile'; const k = contactData();
  const btn = (href, ic, label, col) => href ? `<a class="btn" style="display:flex;align-items:center;gap:10px;background:${col};text-decoration:none;margin:10px 0;padding:13px 18px" href="${esc(href)}" target="_blank" rel="noopener" onclick="goUrl(this.getAttribute('href'));return false"><span style="font-size:22px">${ic}</span>${esc(label)}</a>` : '';
  const links = btn(ctFb(k.fb), '📘', 'ফেসবুকে মেসেজ / প্রোফাইল', '#1877f2') + btn(ctWa(k.wa), '💬', 'হোয়াটসঅ্যাপে মেসেজ', '#128c4a') + btn(ctMail(k.mail), '✉️', 'জিমেইলে লিখুন', '#d93025') + btn(ctTel(k.phone), '📞', 'ফোনে কল করুন', '#0b6e4f') + btn(safeUrl(k.x1), '🔗', k.x1n || 'আরও লিংক', '#475569');
  render(pageHead('যোগাযোগ') + hero('📞', 'যোগাযোগ', 'প্রশ্ন, পরামর্শ বা সমস্যা জানান') + `<div class="pad"><div class="cx" style="text-align:center;border-left:0;border-top:5px solid #ffc20e">
    <div class="av" style="width:72px;height:72px;font-size:32px;margin:4px auto 10px">${esc(initial(k.name))}</div>
    <div style="font-size:12.5px;color:#6b726c">অ্যাপ নির্মাতা</div><div style="font-size:20px;font-weight:800;margin:2px 0">${esc(k.name)}</div>
    <div style="font-size:14.5px;font-weight:600;color:#006a4e;line-height:1.5">${esc(k.role)}</div>
    ${k.about ? `<div class="hint" style="margin-top:10px">${esc(k.about)}</div>` : ''}</div>` +
    (links ? `<div class="cx" style="border-left-color:#ffc20e">${links}</div>` : '<div class="warn">যোগাযোগের লিংক শীঘ্রই যোগ করা হবে।</div>') +
    (isAdminFlag() ? `<button class="btn sm" style="background:#b45309" onclick="push(()=>contactPage());adminPage('contact')">✏️ লিংক বদলান (অ্যাডমিন)</button>` : '') + '</div>');
}
async function adContactSave() {
  const m = await sme(); if (!m) return;
  const o = {}; ['name', 'role', 'about', 'fb', 'wa', 'mail', 'phone', 'x1n', 'x1'].forEach(f => { o[f] = gv('ct_' + f).slice(0, 300); });
  if (o.fb && !ctFb(o.fb)) return adMsg('ফেসবুক লিংকটি ঠিক নয়।');
  if (o.wa && !ctWa(o.wa)) return adMsg('হোয়াটসঅ্যাপ নম্বর ঠিক নয়।');
  if (o.mail && !ctMail(o.mail)) return adMsg('জিমেইল ঠিকানা ঠিক নয়।');
  if (o.x1 && !safeUrl(o.x1)) return adMsg('অতিরিক্ত লিংকটি ঠিক নয়।');
  try {
    adMsg('⏳ সেভ হচ্ছে...');
    await m.f.F.setDoc(m.f.F.doc(m.f.db, 'content', 'contact'), {type: 'contact', title: o.name, body: o.role, pub: true, by: m.u.uid, createdAt: m.f.F.serverTimestamp(), contact: o});
    await refreshContent(); adMsg('✅ সেভ হয়েছে।');
  } catch (e) { adMsg('⚠️ ' + ((e && e.code === 'permission-denied') ? 'অনুমতি নেই।' : 'সেভ হয়নি। ইন্টারনেট দেখুন।')); }
}

// ---------- ছবি ছোট করে ডেটাতে রাখা (Storage ছাড়াই, বিনামূল্যের প্ল্যানে চলে) ----------
const okImg = u => typeof u === 'string' && /^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+\/=]+$/.test(u) && u.length < 1000000;
function imgToData(file, maxPx, png) {
  return new Promise((res, rej) => {
    const fr = new FileReader();
    fr.onerror = () => rej(new Error('ছবি পড়া যায়নি'));
    fr.onload = () => {
      const im = new Image();
      im.onerror = () => rej(new Error('এটি ছবি নয়'));
      im.onload = () => {
        let px = maxPx, q = png ? 0.9 : 0.78, out = '';
        for (let i = 0; i < 5; i++) {
          const k = Math.min(1, px / Math.max(im.width, im.height)), c = document.createElement('canvas');
          c.width = Math.max(1, Math.round(im.width * k)); c.height = Math.max(1, Math.round(im.height * k));
          const g = c.getContext('2d'); if (!png) { g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height); }
          g.drawImage(im, 0, 0, c.width, c.height);
          out = c.toDataURL(png ? 'image/png' : 'image/jpeg', q);
          if (out.length < (png ? 150000 : 650000)) return res(out);
          px = Math.round(px * 0.75); q = Math.max(0.5, q - 0.08);
        }
        rej(new Error('ছবিটি অনেক বড়। ছোট ছবি বাছুন।'));
      };
      im.src = fr.result;
    };
    fr.readAsDataURL(file);
  });
}
async function adPick(inp) {
  const f = inp.files && inp.files[0]; if (!f) return; adMsg('⏳ ছবি ছোট করা হচ্ছে...');
  try {
    _picked = await imgToData(f, 1000, false);
    const p = document.getElementById('ad_imgprev'); if (p) { p.src = _picked; p.style.display = 'block'; }
    adMsg('✅ ছবি তৈরি। এবার নিচের বাটন চাপুন।');
  } catch (e) { _picked = ''; adMsg('⚠️ ' + (e.message || 'ছবি নেওয়া যায়নি')); }
}

// ---------- বড় লেখা সাজানো: # শিরোনাম, ## উপশিরোনাম, - তালিকা, **মোটা** ----------
function rich(t) {
  const COLS = {red: '#dc2626', green: '#15803d', blue: '#1d4ed8', orange: '#c2410c', purple: '#7e22ce', grey: '#6b7280'};
  const inl = x => esc(x).replace(/\*\*(.+?)\*\*/g, '<b>$1</b>').replace(/\{(red|green|blue|orange|purple|grey):(.+?)\}/g, (m, c, t) => `<span style="color:${COLS[c]};font-weight:700">${t}</span>`).replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g, (m, t, u) => `<a href="${u}" target="_blank" rel="noopener" onclick="goUrl(this.getAttribute('href'));return false" style="color:var(--p2);font-weight:700;text-decoration:underline">${t}</a>`);
  let out = '', ul = false;
  String(t || '').split('\n').forEach(raw => {
    const l = raw.replace(/\s+$/, '');
    if (/^\s*[-•]\s+/.test(l)) { if (!ul) { out += '<ul style="margin:6px 0;padding-left:22px">'; ul = true; } out += '<li style="margin:3px 0">' + inl(l.replace(/^\s*[-•]\s+/, '')) + '</li>'; return; }
    if (ul) { out += '</ul>'; ul = false; }
    if (/^##\s+/.test(l)) out += '<h4 style="margin:12px 0 4px;font-size:16.5px;color:var(--p2)">' + inl(l.replace(/^##\s+/, '')) + '</h4>';
    else if (/^#\s+/.test(l)) out += '<h3 style="margin:14px 0 6px;font-size:19px">' + inl(l.replace(/^#\s+/, '')) + '</h3>';
    else if (!l.trim()) out += '<div style="height:9px"></div>';
    else out += '<div style="line-height:1.7">' + inl(l) + '</div>';
  });
  return out + (ul ? '</ul>' : '');
}

// ---------- অ্যাপের নাম, লোগো, রং ও আইকন (অ্যাডমিন বদলাতে পারে) ----------
const CFG_DEF = {name: 'চালক ভাই', sub: 'শেখা • কাগজপত্র • চাকরি', ic: '🛞', logo: '', c1: '#006a4e', pg: '#f4f5f1', cd: '#ffffff', tx: '#1a1a1a', bism: true, tiles: {}, layout: null, hidden: null, edits: null, pdfDef: true, pdfOff: null, pdfOn: null, daily: null, ntc: null};
function APPCFG() {
  const c = ADMIN_CONTENT.find(x => x.type === 'config'); const k = (c && c.cfg) || {};
  const o = Object.assign({}, CFG_DEF); Object.keys(CFG_DEF).forEach(f => { if (k[f] !== undefined && k[f] !== null && k[f] !== '') o[f] = k[f]; });
  if (c && okImg(c.img)) o.logo = c.img;
  return o;
}
const appName = () => APPCFG().name;
const appSub = () => APPCFG().sub;
function appLogoHtml() { const c = APPCFG(); return `<span class="logo">${okImg(c.logo) ? `<img src="${c.logo}" alt="">` : esc(c.ic)}</span>`; }
const tileOv = id => { const t = APPCFG().tiles; return (t && t[id]) || {}; };
function hexMix(h, to, t) {
  const p = x => [1, 3, 5].map(i => parseInt(x.slice(i, i + 2), 16)); const a = p(h), b = p(to);
  return '#' + a.map((v, i) => Math.round(v + (b[i] - v) * t).toString(16).padStart(2, '0')).join('');
}
function applyTheme() {
  try {
    const c = APPCFG(); const r = document.documentElement.style; let c1 = /^#[0-9a-fA-F]{6}$/.test(c.c1) ? c.c1 : CFG_DEF.c1; try { const uc = localStorage.getItem('ucolor'); if (uc && /^#[0-9a-fA-F]{6}$/.test(uc)) c1 = uc; } catch (e) {}
    const hx = (v, d) => /^#[0-9a-fA-F]{6}$/.test(v) ? v : d; r.setProperty('--pg', hx(c.pg, '#f4f5f1')); r.setProperty('--cd', hx(c.cd, '#ffffff')); r.setProperty('--tx', hx(c.tx, '#1a1a1a')); r.setProperty('--p2', c1); r.setProperty('--p1', hexMix(c1, '#000000', 0.22)); r.setProperty('--tint', hexMix(c1, '#ffffff', 0.88)); r.setProperty('--g2', c1); r.setProperty('--g1', hexMix(c1, '#000000', 0.22));
    document.title = c.name; const tm = document.querySelector('meta[name=theme-color]'); if (tm) tm.setAttribute('content', hexMix(c1, '#000000', 0.22));
  } catch (e) {}
}
applyTheme();

const THEMES = [['সবুজ', '#006a4e', '#f4f5f1', '#ffffff', '#fff', '#1a1a1a'], ['নীল', '#0b5ed7', '#eef3fb', '#ffffff', '#fff', '#16202e'], ['বেগুনি', '#6d28d9', '#f5f1fb', '#ffffff', '#fff', '#241a33'], ['লাল', '#b91c1c', '#fbf1f1', '#ffffff', '#fff', '#2b1a1a'], ['কমলা', '#c2410c', '#fbf3ec', '#ffffff', '#fff', '#2d1f14'], ['টিল', '#0f766e', '#eef7f6', '#ffffff', '#fff', '#13292a'], ['গোলাপি', '#be185d', '#fcf0f5', '#ffffff', '#fff', '#2e1823'], ['কালচে', '#1f2937', '#e5e7eb', '#f9fafb', '#fff', '#111827'], ['সোনালি', '#92400e', '#faf5e8', '#fffdf6', '#fff', '#2b2216'], ['আকাশি', '#0284c7', '#edf7fc', '#ffffff', '#fff', '#12283a']];
function cfPreset(i) { const t = THEMES[i]; [['cf_c1', t[1]], ['cf_pg', t[2]], ['cf_cd', t[3]], ['cf_tx', t[5]]].forEach(x => { const e = document.getElementById(x[0]); if (e) e.value = x[1]; }); cfLive(); }
function cfLive() { const g = id => (document.getElementById(id) || {}).value; const r = document.documentElement.style, c1 = g('cf_c1'); if (!c1) return; r.setProperty('--p2', c1); r.setProperty('--p1', hexMix(c1, '#000000', 0.22)); r.setProperty('--tint', hexMix(c1, '#ffffff', 0.88)); r.setProperty('--pg', g('cf_pg')); r.setProperty('--cd', g('cf_cd')); r.setProperty('--tx', g('cf_tx')); }
function settingsForm() {
  const c = APPCFG(); const tiles = typeof homeGroups === 'function' ? homeGroups(true).flatMap(g => g[1]).filter(t => String(t.id).indexOf('sec_') !== 0) : [];
  const quick = typeof QUICK !== 'undefined' ? QUICK.filter(q => !tiles.some(t => t.id === q[0])).map(q => ({id: q[0], name: q[2], ic: q[1]})) : [];
  const all = quick.concat(tiles); const seen = new Set();
  return `<div class="cx"><b>🎨 অ্যাপের পরিচয়</b><div class="hint">নাম, লোগো ও রং বদলালে হোম, মেনু ও শুরুর পর্দা সব জায়গায় বদলে যায়।</div>
    <input class="inp" id="cf_name" placeholder="অ্যাপের নাম" value="${esc(c.name)}">
    <input class="inp" id="cf_sub" placeholder="নামের নিচের ছোট লেখা" value="${esc(c.sub)}">
    <input class="inp" id="cf_ic" maxlength="4" placeholder="লোগো (একটি ইমোজি)" value="${esc(c.ic)}">
    <div class="hint" style="margin:0 0 4px">অথবা নিজের লোগো ছবি (ছবি থাকলে ইমোজির বদলে ওটা দেখাবে)</div>
    ${okImg(c.logo) ? `<img id="cf_prev" src="${c.logo}" style="width:64px;height:64px;border-radius:16px;object-fit:cover;display:block;margin:4px 0"><label style="display:block;margin:4px 0"><input type="checkbox" id="cf_logodel">লোগো ছবিটি সরান</label>` : '<img id="cf_prev" style="display:none;width:64px;height:64px;border-radius:16px;object-fit:cover;margin:4px 0">'}
    <input type="file" id="cf_logo" accept="image/*" onchange="cfPickLogo(this)">
    <div class="hint" style="margin-top:12px">তৈরি রঙের সাজ (একটা চাপলেই পুরো অ্যাপ বদলে যাবে, তারপর সেভ করুন)</div>
    <div class="presets">${THEMES.map((t, i) => `<button onclick="cfPreset(${i})" style="background:linear-gradient(135deg,${t[1]} 50%,${t[3]} 50%)"><span style="color:${t[4]}">${t[0]}</span></button>`).join('')}</div>
    <div class="hint" style="margin-top:12px">নিজের পছন্দের রং</div>
    ${[['cf_c1', 'হেডার, বাটন ও মূল রং', c.c1], ['cf_pg', 'পাতার পেছনের রং', c.pg], ['cf_cd', 'কার্ড ও বাক্সের রং', c.cd], ['cf_tx', 'লেখার রং', c.tx]].map(x => `<div class="rowline" style="margin:6px 0"><input type="color" id="${x[0]}" value="${esc(x[2])}" oninput="cfLive()" style="width:54px;height:40px;border:0;background:none;padding:0"><span>${x[1]}</span></div>`).join('')}
    <label style="display:block;margin:10px 0"><input type="checkbox" id="cf_bism" ${c.bism !== false ? 'checked' : ''}>অ্যাপ খোলার সময় "বিসমিল্লাহির রাহমানির রাহিম" দেখান</label></div></div>
    <div class="cx"><b>🔲 হোমের আইকন</b><div class="hint">যেকোনো আইকনের নাম ও ইমোজি বদলান, বা লুকিয়ে দিন। ফাঁকা রাখলে আগের নামই থাকবে।</div>
    ${all.filter(t => !seen.has(t.id) && seen.add(t.id)).map(t => { const o = (c.tiles || {})[t.id] || {}; return `<div style="display:flex;gap:6px;align-items:center;margin:6px 0" data-tid="${esc(t.id)}"><input class="inp tc_ic" style="width:58px;margin:0;text-align:center" maxlength="4" value="${esc(o.ic || '')}" placeholder="${esc(t.ic)}"><input class="inp tc_nm" style="margin:0;flex:1" value="${esc(o.name || '')}" placeholder="${esc(t.name)}"><label style="font-size:12px;white-space:nowrap"><input type="checkbox" class="tc_hd" ${o.hide ? 'checked' : ''}>লুকান</label></div>`; }).join('')}</div>
    <div id="ad_msg" class="warn" style="display:none"></div>
    <button class="btn" onclick="cfSave()">💾 সেভ করুন</button> <button class="btn sm" style="background:#475569" onclick="cfReset()">↩️ আগের অবস্থায় ফেরান</button>`;
}
async function cfPickLogo(inp) {
  const f = inp.files && inp.files[0]; if (!f) return; adMsg('⏳ লোগো ছোট করা হচ্ছে...');
  try { _logoPicked = await imgToData(f, 200, true); const p = document.getElementById('cf_prev'); if (p) { p.src = _logoPicked; p.style.display = 'block'; } adMsg('✅ লোগো তৈরি। এবার সেভ করুন।'); }
  catch (e) { _logoPicked = null; adMsg('⚠️ ' + (e.message || 'লোগো নেওয়া যায়নি')); }
}
async function cfSave() {
  const m = await sme(); if (!m) return;
  const tiles = {}; document.querySelectorAll('[data-tid]').forEach(r => {
    const o = {}; const ic = r.querySelector('.tc_ic').value.trim(), nm = r.querySelector('.tc_nm').value.trim(), hd = r.querySelector('.tc_hd').checked;
    if (ic) o.ic = Array.from(ic).slice(0, 2).join(''); if (nm) o.name = nm.slice(0, 40); if (hd) o.hide = true;
    if (Object.keys(o).length) tiles[r.getAttribute('data-tid')] = o;
  });
  const prev = ADMIN_CONTENT.find(x => x.type === 'config'); const old = prev && okImg(prev.img) ? prev.img : '';
  const img = _logoPicked || (chk('cf_logodel') ? '' : old);
  const cfg = {name: gv('cf_name').slice(0, 40) || CFG_DEF.name, sub: gv('cf_sub').slice(0, 60), ic: Array.from(gv('cf_ic') || CFG_DEF.ic).slice(0, 2).join(''), c1: gv('cf_c1') || CFG_DEF.c1, pg: gv('cf_pg') || CFG_DEF.pg, cd: gv('cf_cd') || CFG_DEF.cd, tx: gv('cf_tx') || CFG_DEF.tx, bism: chk('cf_bism'), tiles, layout: (prev && prev.cfg && prev.cfg.layout) || null, hidden: (prev && prev.cfg && prev.cfg.hidden) || null, edits: (prev && prev.cfg && prev.cfg.edits) || null, pdfDef: !(prev && prev.cfg && prev.cfg.pdfDef === false), pdfOff: (prev && prev.cfg && prev.cfg.pdfOff) || [], pdfOn: (prev && prev.cfg && prev.cfg.pdfOn) || [], daily: (prev && prev.cfg && prev.cfg.daily) || null, ntc: (prev && prev.cfg && prev.cfg.ntc) || null};
  try {
    adMsg('⏳ সেভ হচ্ছে...');
    await m.f.F.setDoc(m.f.F.doc(m.f.db, 'content', 'appconfig'), {type: 'config', title: 'config', pub: true, by: m.u.uid, createdAt: m.f.F.serverTimestamp(), cfg, img});
    _logoPicked = null; await refreshContent(); applyTheme(); adMsg('✅ সেভ হয়েছে। হোমে গিয়ে দেখুন।');
  } catch (e) { adMsg('⚠️ ' + ((e && e.code === 'permission-denied') ? 'অনুমতি নেই।' : 'সেভ হয়নি। ইন্টারনেট দেখুন।')); }
}
async function cfReset() {
  if (!confirm('অ্যাপের নাম, লোগো, রং ও আইকনের সব বদল আগের অবস্থায় ফিরবে। নিশ্চিত?')) return; const m = await sme(); if (!m) return;
  try { await m.f.F.deleteDoc(m.f.F.doc(m.f.db, 'content', 'appconfig')); _logoPicked = null; await refreshContent(); applyTheme(); adminPage('set'); } catch (e) { adMsg('⚠️ হয়নি।'); }
}

// =====================================================================
//  অ্যাডমিন বিল্ডার: যেকোনো আইকন/পাতার ভিতরে অধ্যায়, উপ-অধ্যায়, লিংক, রং, বাংলা-ইংরেজি
// =====================================================================
function pk(bn, en, mode) {
  bn = bn || ''; en = en || '';
  if (mode === 'both') return bn && en ? bn + '\n\n' + en : (bn || en);
  if (mode === 'en') return en || bn;
  if (mode === 'bn') return bn || en;
  return (typeof LANG !== 'undefined' && LANG === 'en' && en) ? en : (bn || en);
}
const nTitle = c => { if (c.lang === 'both' && c.title && c.titleEn) return c.title + ' / ' + c.titleEn; return pk(c.title, c.titleEn, c.lang); };
const nBody = c => pk(c.body, c.bodyEn, c.lang);
const nodeKids = key => ADMIN_CONTENT.filter(c => c.type === 'node' && c.parent === key).sort((a, b) => (a.ord || 0) - (b.ord || 0) || (a.at || 0) - (b.at || 0));
const colOk = c => /^#[0-9a-fA-F]{6}$/.test(c || '') ? c : '';
function keyName(k) {
  if (k.indexOf('n_') === 0) { const n = ADMIN_CONTENT.find(c => c.id === k.slice(2)) || _acache.content.find(c => c.id === k.slice(2)); return n ? nTitle(n) : k; }
  if (k.indexOf('sec_') === 0) { const n = ADMIN_CONTENT.find(c => c.id === k.slice(4)) || _acache.content.find(c => c.id === k.slice(4)); return n ? (n.title || k) : k; }
  const t = (typeof homeGroups === 'function' ? homeGroups(true).flatMap(g => g[1]) : []).find(c => c.id === k);
  return t ? ((tileOv(k).name) || (typeof SHORT !== 'undefined' && SHORT[k]) || t.name) : k;
}
function parentOpts(sel, selfId) {
  const rows = _acache.content.length ? _acache.content : ADMIN_CONTENT; const seen = new Set(); let h = '<optgroup label="অ্যাপের আইকন">';
  (typeof homeGroups === 'function' ? homeGroups(true).flatMap(g => g[1]) : []).forEach(t => { if (String(t.id).indexOf('sec_') === 0 || seen.has(t.id)) return; seen.add(t.id); h += `<option value="${esc(t.id)}" ${sel === t.id ? 'selected' : ''}>${esc(keyName(t.id))}</option>`; });
  h += '</optgroup><optgroup label="আপনার বানানো সেকশন">';
  rows.filter(c => c.type === 'section').forEach(c => { h += `<option value="sec_${esc(c.id)}" ${sel === 'sec_' + c.id ? 'selected' : ''}>${esc(c.title || '')}</option>`; });
  h += '</optgroup><optgroup label="আপনার বানানো পাতা (ভিতরে ঢুকবে)">';
  rows.filter(c => c.type === 'node' && c.id !== selfId).forEach(c => { h += `<option value="n_${esc(c.id)}" ${sel === 'n_' + c.id ? 'selected' : ''}>↳ ${esc(nTitle(c))}</option>`; });
  return h + '</optgroup>';
}
function reopenKey(k) {
  if (k.indexOf('n_') === 0) return nodePage(k.slice(2));
  if (k.indexOf('sec_') === 0) return sectionPage(k.slice(4));
  stack.pop(); open_(k);
}
function rebuildStack(key) {
  const anc = []; let k = key;
  while (k.indexOf('n_') === 0) { const n = ADMIN_CONTENT.find(c => c.id === k.slice(2)); if (!n) break; k = n.parent; anc.unshift(k); }
  stack = [() => home()].concat(anc.map(a => () => reopenKey(a)));
}
function nodeGo(id, from) { push(() => reopenKey(from)); nodePage(id); }
function adAddHere(key) { _presetType = 'node'; _presetParent = key; stack.push(() => reopenKey(key)); adminPage('pub'); }
function adEditNode(id) { stack.push(() => nodePage(id)); adminPage('pub', id); }
async function adDelNode(id, key) {
  if (!confirm('এই পাতা মুছবেন? এর ভিতরের পাতাগুলোও আর দেখা যাবে না।')) return; const m = await sme(); if (!m) return;
  try { await m.f.F.deleteDoc(m.f.F.doc(m.f.db, 'content', id)); await refreshContent(); rebuildStack(key); reopenKey(key); } catch (e) { alert('মোছা যায়নি।'); }
}
function nodeCard(c, from) {
  const col = colOk(c.color) || '#0369a1', n = nodeKids('n_' + c.id).length;
  return `<div class="nk" style="border-left-color:${col}" onclick="nodeGo('${esc(c.id)}','${esc(from)}')"><span class="nki" style="background:${col}22;color:${col}">${esc(c.ic || (c.url && !c.body && !c.bodyEn ? '🔗' : '📄'))}</span><div class="nkt"><b>${esc(nTitle(c))}</b>${n ? `<small>${bn(n)}টি বিষয়</small>` : (c.pd ? `<small>📅 ${bnDate(c.pd)}</small>` : '')}</div><span class="nka">›</span></div>` + ((typeof isAdminFlag === 'function' && isAdminFlag()) ? `<div style="margin:-4px 0 8px;text-align:right"><button class="nbtn" style="background:#1d4ed8" onclick="adEditNode('${esc(c.id)}')">✏️ বদলান</button> <button class="nbtn" style="background:#b91c1c" onclick="adDelNode('${esc(c.id)}','${esc(c.parent)}')">🗑️ মুছুন</button></div>` : '');
}
function adminBar(key, c) {
  if (!(typeof isAdminFlag === 'function' && isAdminFlag())) return '';
  return `<div class="adbar"><span>🛡️ অ্যাডমিন</span><button onclick="adAddHere('${esc(key)}')">➕ এখানে নতুন যোগ</button>${c ? `<button onclick="adEditNode('${esc(c.id)}')">✏️ বদলান</button><button style="background:#b91c1c" onclick="adDelNode('${esc(c.id)}','${esc(c.parent)}')">🗑️</button>` : ''}</div>`;
}
function injectKids(key) {
  try {
    if (['quiz', 'roadtest', 'signquiz', 'qorder', 'account', 'lang', 'share', 'cv', 'admin', 'contact', 'board', 'community', 'seeker', 'courses'].includes(key)) return;
    const old = document.getElementById('kids'); if (old) old.remove();
    const k = nodeKids(key), adm = adminBar(key, key.indexOf('n_') === 0 ? ADMIN_CONTENT.find(c => c.id === key.slice(2)) : null);
    if (!k.length && !adm) return;
    const host = document.querySelector('#app .page-h') || document.querySelector('#app .hero'); if (!host) return;
    let anchor = host; const hero = host.nextElementSibling; if (hero && hero.classList.contains('hero')) anchor = hero;
    anchor.insertAdjacentHTML('afterend', `<div class="pad" id="kids">${adm}${k.map(c => nodeCard(c, key)).join('')}</div>`);
  } catch (e) {}
}
function nodePage(id) {
  tab = 'home'; const c = ADMIN_CONTENT.find(x => x.id === id);
  if (!c) return render(pageHead('পাতা') + '<div class="pad">' + sEmpty('🔍', 'এই পাতাটি আর নেই।') + '</div>');
  const col = colOk(c.color), key = 'n_' + id, body = nBody(c);
  render(pageHead(nTitle(c)) + `<div class="pad"><div class="cx" ${col ? `style="border-top:5px solid ${col}"` : ''}>${c.ic ? `<div style="font-size:34px">${esc(c.ic)}</div>` : ''}<h3 style="margin:4px 0 8px;${col ? 'color:' + col : ''}">${esc(nTitle(c))}</h3>${mediaHtml(c)}${body ? `<div class="rich" style="margin-top:8px">${rich(body)}</div>` : ''}${linkBtn(c.url)}${body ? speakBtn(body) : ''}</div></div>`);
  injectKids(key);
}
// ক্রমে সাজানো যায় এমন ছোট কার্ড CSS
(function () { const st = document.createElement('style'); st.textContent = `
.nk{display:flex;align-items:center;gap:12px;background:#fff;border:1px solid #e5e7eb;border-left:6px solid #0369a1;border-radius:14px;padding:12px;margin:9px 0;box-shadow:0 2px 8px rgba(0,0,0,.05)}
.nk:active{transform:scale(.99)}.nki{width:44px;height:44px;border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:22px;flex:none}
.nkt{flex:1}.nkt b{display:block;font-size:16px}.nkt small{color:#6b7280}.nka{font-size:22px;color:#9ca3af}
.adbar{display:flex;flex-wrap:wrap;gap:6px;align-items:center;background:#fff7ed;border:1.5px dashed #fb923c;border-radius:12px;padding:8px;margin:8px 0;font-size:13px;font-weight:700;color:#9a3412}
.adbar button{border:0;background:#c2410c;color:#fff;border-radius:10px;padding:8px 10px;font:inherit;font-size:13px}
.adtop{margin:10px 12px 0;border-radius:16px;overflow:hidden;position:relative;background:#fff;border:1px solid #e5e7eb;box-shadow:0 4px 14px rgba(0,0,0,.1)}
.adtop img{width:100%;display:block;max-height:240px;object-fit:cover}.adtop .at{padding:12px 14px;font-weight:700;font-size:16px}
.adlbl{position:absolute;top:6px;left:6px;background:rgba(0,0,0,.55);color:#fff;border-radius:8px;font-size:10px;padding:2px 7px}
#bars{position:fixed;bottom:0;left:50%;transform:translateX(-50%);width:100%;max-width:480px;z-index:70}
.adbot{display:flex;align-items:center;gap:8px;background:#fff;border-top:1px solid #e5e7eb;padding:6px 8px;box-shadow:0 -3px 12px rgba(0,0,0,.08)}
.adbot img{height:42px;width:68px;object-fit:cover;border-radius:8px;flex:none}.adbot span{flex:1;font-size:13px;font-weight:600;line-height:1.3}
.adbot i{font-style:normal;color:#9ca3af;padding:4px 8px;font-size:16px}
.tkr{display:flex;align-items:stretch;background:#111827;color:#fff;overflow:hidden;height:34px}
.tkr b{background:#dc2626;padding:0 12px;display:flex;align-items:center;font-size:13px;flex:none;z-index:2}
.tkr div{flex:1;overflow:hidden;white-space:nowrap;display:flex;align-items:center}
.tkr span{display:inline-block;padding-left:100%;animation:tkm 30s linear infinite;font-size:14px}
@keyframes tkm{to{transform:translateX(-100%)}}
body.dark .nk,body.dark .adbot,body.dark .adtop{background:#1f2937;border-color:#374151}
`; document.head.appendChild(st); })();

// =====================================================================
//  বিজ্ঞাপন (উপরে বড়, নিচে ছোট) ও টিভির মতো খবরের লাইন
// =====================================================================
const adDoc = id => ADMIN_CONTENT.find(c => c.id === id);
let _adBotX = false;
function topAd() {
  const a = adDoc('ad_top'); if (!a || !(okImg(a.img) || a.body)) return '';
  const u = safeUrl(a.url);
  return `<${u ? 'a href="' + esc(u) + '" target="_blank" rel="noopener" onclick="goUrl(this.href);return false"' : 'div'} class="adtop" style="display:block;color:inherit;text-decoration:none"><span class="adlbl" ${okImg(a.img) ? '' : 'style="position:static;display:inline-block;margin:8px 0 0 12px;background:#6b7280"'}>বিজ্ঞাপন</span>${okImg(a.img) ? `<img src="${a.img}" alt="">` : ''}${a.body ? `<div class="at">${esc(a.body)}</div>` : ''}</${u ? 'a' : 'div'}>`;
}
function renderBars() {
  let b = document.getElementById('bars'); if (!b) { b = document.createElement('div'); b.id = 'bars'; document.body.appendChild(b); }
  const a = adDoc('ad_bot'), t = adDoc('ticker'); let h = '';
  if (a && !_adBotX && (okImg(a.img) || a.body)) { const u = safeUrl(a.url); h += `<div class="adbot" ${u ? `onclick="goUrl('${esc(u)}')"` : ''}>${okImg(a.img) ? `<img src="${a.img}" alt="">` : ''}<span>${esc(a.body || '')}<small style="display:block;color:#9ca3af;font-size:10px">বিজ্ঞাপন</small></span><i onclick="event.stopPropagation();_adBotX=true;renderBars()">✕</i></div>`; }
  const lines = t && t.body ? t.body.split('\n').map(x => x.trim()).filter(Boolean) : [];
  if (lines.length) { const txt = lines.join('   ●   '); h += `<div class="tkr"><b>${esc(t.label || 'খবর')}</b><div><span style="animation-duration:${Math.max(14, Math.round(txt.length * 0.32))}s">${esc(txt)}</span></div></div>`; }
  b.innerHTML = h; const ap = document.getElementById('app'); if (ap) ap.style.paddingBottom = (h ? b.offsetHeight + 14 : 16) + 'px';
}
function adsForm() {
  const g = id => _acache.content.find(c => c.id === id) || {};
  const t = g('ad_top'), bt = g('ad_bot'), tk = g('ticker');
  const blk = (k, title, hint, o) => `<div class="cx"><b>${title}</b><div class="hint">${hint}</div>
    <label style="display:block;margin:6px 0"><input type="checkbox" id="${k}_on" ${o.pub ? 'checked' : ''}>চালু আছে</label>
    <textarea class="inp" id="${k}_tx" rows="2" placeholder="বিজ্ঞাপনের লেখা">${esc(o.body || '')}</textarea>
    <input class="inp" id="${k}_url" placeholder="লিংক (ঐচ্ছিক, https://...)" value="${esc(o.url || '')}">
    ${okImg(o.img) ? `<img id="${k}_prev" src="${o.img}" style="max-width:100%;max-height:120px;border-radius:10px;display:block;margin:6px 0"><label style="display:block"><input type="checkbox" id="${k}_del">ছবি সরান</label>` : `<img id="${k}_prev" style="display:none;max-width:100%;max-height:120px;border-radius:10px;margin:6px 0">`}
    <input type="file" accept="image/*" onchange="adAdPick(this,'${k}')"><button class="btn sm" style="margin-top:8px" onclick="adAdSave('${k}')">💾 সেভ করুন</button></div>`;
  return blk('ad_top', '🖼️ উপরের বড় বিজ্ঞাপন', 'অ্যাপের হোম পাতার একদম উপরে বড় করে দেখাবে। ছবি, লেখা বা দুটোই দিতে পারেন।', t) +
    blk('ad_bot', '📌 নিচের ছোট বিজ্ঞাপন', 'সব পাতার নিচে ছোট্ট একটি লাইনে দেখাবে। ব্যবহারকারী ✕ চাপলে ওই বার বন্ধ হবে।', bt) +
    `<div class="cx"><b>📰 খবরের লাইন (টিভির মতো চলবে)</b><div class="hint">প্রতি লাইনে একটি করে খবর লিখুন। সব খবর নিচে একটানা চলতে থাকবে। যা মন চায় লিখতে পারেন।</div>
    <label style="display:block;margin:6px 0"><input type="checkbox" id="tk_on" ${tk.pub ? 'checked' : ''}>চালু আছে</label>
    <input class="inp" id="tk_label" placeholder="বাঁ পাশের লেবেল (যেমন: খবর, নোটিশ)" value="${esc(tk.label || 'খবর')}">
    <textarea class="inp" id="tk_tx" rows="6" placeholder="একটি লাইনে একটি খবর">${esc(tk.body || '')}</textarea>
    <button class="btn sm" onclick="adTickSave()">💾 সেভ করুন</button></div><div id="ad_msg" class="warn" style="display:none"></div>`;
}
const _adImgs = {};
async function adAdPick(inp, k) {
  const f = inp.files && inp.files[0]; if (!f) return; adMsg('⏳ ছবি ছোট করা হচ্ছে...');
  try { _adImgs[k] = await imgToData(f, 900, false); const p = document.getElementById(k + '_prev'); if (p) { p.src = _adImgs[k]; p.style.display = 'block'; } adMsg('✅ ছবি তৈরি। এবার সেভ করুন।'); } catch (e) { adMsg('⚠️ ' + (e.message || 'ছবি নেওয়া যায়নি')); }
}
async function adAdSave(k) {
  const m = await sme(); if (!m) return; const old = (_acache.content.find(c => c.id === k) || {}).img || '';
  const url = gv(k + '_url'); if (url && !safeUrl(url)) return adMsg('লিংকটি ঠিক নয়। যেমন: https://example.com বা www.example.com');
  const img = _adImgs[k] || (chk(k + '_del') ? '' : old);
  try { adMsg('⏳ সেভ হচ্ছে...'); await m.f.F.setDoc(m.f.F.doc(m.f.db, 'content', k), {type: 'ad', slot: k === 'ad_top' ? 'top' : 'bot', title: 'ad', body: gv(k + '_tx').slice(0, 300), url, img, pub: chk(k + '_on'), by: m.u.uid, createdAt: m.f.F.serverTimestamp()}); delete _adImgs[k]; await refreshContent(); renderBars(); adMsg('✅ সেভ হয়েছে।'); } catch (e) { adMsg('⚠️ সেভ হয়নি।'); }
}
async function adTickSave() {
  const m = await sme(); if (!m) return;
  try { adMsg('⏳ সেভ হচ্ছে...'); await m.f.F.setDoc(m.f.F.doc(m.f.db, 'content', 'ticker'), {type: 'ticker', title: 'ticker', body: gv('tk_tx').slice(0, 3000), label: gv('tk_label').slice(0, 12) || 'খবর', pub: chk('tk_on'), by: m.u.uid, createdAt: m.f.F.serverTimestamp()}); await refreshContent(); renderBars(); adMsg('✅ সেভ হয়েছে।'); } catch (e) { adMsg('⚠️ সেভ হয়নি।'); }
}

// =====================================================================
//  হোমের আইকন নিজের মতো সাজানো: ক্রম বদল, অন্য গ্রুপে নেওয়া, গ্রুপের নাম বদল
// =====================================================================
const layoutOv = () => { const l = APPCFG().layout; return Array.isArray(l) && l.length ? l : null; };
function applyLayout(groups) {
  const lay = layoutOv(); if (!lay) return groups;
  const all = {}; groups.forEach(g => g[1].forEach(t => { all[t.id] = t; })); const used = new Set();
  const out = lay.map(g => [String(g.name || ''), (g.ids || []).map(id => { used.add(id); return all[id]; }).filter(Boolean)]);
  const rest = Object.keys(all).filter(id => !used.has(id)).map(id => all[id]);
  if (rest.length) { const k = out.findIndex(g => g[0] === 'নতুন আইকন'); if (k >= 0) out[k][1] = out[k][1].concat(rest); else out.push(['নতুন আইকন', rest]); }
  return out;
}
let _lay = [];
function layInit() { const g = homeGroups(true); _lay = g.map(x => ({name: x[0], ids: x[1].map(t => t.id)})); }
function layCommit() { document.querySelectorAll('[data-gi]').forEach(e => { const i = +e.getAttribute('data-gi'); if (_lay[i]) _lay[i].name = e.value.trim().slice(0, 40); }); }
function layForm() {
  const tiles = {}; homeGroups(true).forEach(g => g[1].forEach(t => { tiles[t.id] = t; }));
  return `<div class="cx"><b>🧩 হোমের আইকন সাজান</b><div class="hint">⬆⬇ চাপলে আইকন ওঠানামা করে (গ্রুপের শেষে গেলে পরের গ্রুপে চলে যায়)। "কোথায়" থেকে সরাসরি অন্য গ্রুপে পাঠানো যায়। গ্রুপের নামও বদলানো যায়। শেষে সেভ করুন।</div></div><div id="layBox">${layHtml(tiles)}</div>
  <div id="ad_msg" class="warn" style="display:none"></div>
  <button class="btn" onclick="laySave()">💾 সেভ করুন</button> <button class="btn sm" onclick="layNewG()">➕ নতুন গ্রুপ</button> <button class="btn sm" style="background:#475569" onclick="layReset()">↩️ আগের সাজ</button>`;
}
function layHtml(tiles) {
  if (!tiles) { tiles = {}; homeGroups(true).forEach(g => g[1].forEach(t => { tiles[t.id] = t; })); }
  return _lay.map((g, gi) => `<div class="cx"><div class="rowline"><input class="inp" style="margin:0;font-weight:800" data-gi="${gi}" value="${esc(g.name)}"><button class="btn sm" style="margin:0" onclick="layMoveG(${gi},-1)">⬆</button><button class="btn sm" style="margin:0" onclick="layMoveG(${gi},1)">⬇</button><button class="btn sm" style="margin:0;background:#dc2626" onclick="layDelG(${gi})">🗑️</button></div>
    ${g.ids.map((id, ti) => { const t = tiles[id] || {}; return `<div class="layrow"><span class="lai">${esc(tileOv(id).ic || t.ic || '•')}</span><span class="lan">${esc(keyName(id))}</span><button onclick="layHide('${esc(id)}')" style="background:${tileOv(id).hide ? '#dc2626' : '#64748b'}">${tileOv(id).hide ? '🙈' : '👁️'}</button><button onclick="layMoveT(${gi},${ti},-1)">⬆</button><button onclick="layMoveT(${gi},${ti},1)">⬇</button><select onchange="layTo(${gi},${ti},this.value)"><option value="">কোথায়</option>${_lay.map((x, k) => k === gi ? '' : `<option value="${k}">${esc(x.name || 'গ্রুপ ' + (k + 1))}</option>`).join('')}</select></div>`; }).join('') || '<div class="hint">এই গ্রুপে এখন কিছু নেই।</div>'}</div>`).join('');
}
function layRefresh() { const b = document.getElementById('layBox'); if (b) b.innerHTML = layHtml(); }
function layMoveG(i, d) { layCommit(); const j = i + d; if (j < 0 || j >= _lay.length) return; [_lay[i], _lay[j]] = [_lay[j], _lay[i]]; layRefresh(); }
function layMoveT(gi, ti, d) {
  layCommit(); const g = _lay[gi], id = g.ids[ti], nt = ti + d;
  if (nt >= 0 && nt < g.ids.length) { g.ids.splice(ti, 1); g.ids.splice(nt, 0, id); }
  else if (d < 0 && gi > 0) { g.ids.splice(ti, 1); _lay[gi - 1].ids.push(id); }
  else if (d > 0 && gi < _lay.length - 1) { g.ids.splice(ti, 1); _lay[gi + 1].ids.unshift(id); }
  layRefresh();
}
function layTo(gi, ti, v) { if (v === '') return; layCommit(); const id = _lay[gi].ids.splice(ti, 1)[0]; _lay[+v].ids.push(id); layRefresh(); }
function layNewG() { layCommit(); _lay.push({name: 'নতুন গ্রুপ', ids: []}); layRefresh(); }
function layDelG(i) {
  layCommit(); const g = _lay[i]; if (g.ids.length) { if (!confirm('এই গ্রুপের আইকনগুলো আগের গ্রুপে চলে যাবে। ঠিক আছে?')) return; const to = i > 0 ? i - 1 : 1; if (_lay[to]) _lay[to].ids = _lay[to].ids.concat(g.ids); else return alert('অন্তত একটি গ্রুপ থাকতে হবে।'); }
  _lay.splice(i, 1); layRefresh();
}
async function laySave() {
  layCommit(); const m = await sme(); if (!m) return;
  const layout = _lay.filter(g => g.name || g.ids.length).map(g => ({name: g.name || 'গ্রুপ', ids: g.ids}));
  try { adMsg('⏳ সেভ হচ্ছে...'); await m.f.F.setDoc(m.f.F.doc(m.f.db, 'content', 'appconfig'), {type: 'config', title: 'config', pub: true, by: m.u.uid, cfg: {layout}, createdAt: m.f.F.serverTimestamp()}, {merge: true}); await refreshContent(); adMsg('✅ সেভ হয়েছে। হোমে গিয়ে দেখুন।'); } catch (e) { adMsg('⚠️ সেভ হয়নি।'); }
}
async function layReset() {
  if (!confirm('হোমের সাজ আগের অবস্থায় ফিরবে। নিশ্চিত?')) return; const m = await sme(); if (!m) return;
  try { await m.f.F.setDoc(m.f.F.doc(m.f.db, 'content', 'appconfig'), {type: 'config', title: 'config', pub: true, cfg: {layout: null}, createdAt: m.f.F.serverTimestamp()}, {merge: true}); await refreshContent(); layInit(); layRefresh(); adMsg('✅ আগের সাজে ফিরেছে।'); } catch (e) { adMsg('⚠️ হয়নি।'); }
}
(function () { const st = document.createElement('style'); st.textContent = `.layrow{display:flex;align-items:center;gap:6px;margin:6px 0;padding:6px;border-radius:10px;background:var(--tint)}.lai{font-size:20px;width:28px;text-align:center}.lan{flex:1;font-size:14px;font-weight:600}.layrow button{border:0;background:var(--p2);color:#fff;border-radius:8px;width:34px;height:32px}.layrow select{max-width:84px;font:inherit;font-size:12px;border-radius:8px;border:1px solid #cbd5e1;height:32px}`; document.head.appendChild(st); })();

const _bd = v => String(v).replace(/[০-৯]/g, ch => '০১২৩৪৫৬৭৮৯'.indexOf(ch));
function parseQuizBulk(t) {
  const out = [];
  String(t).split('\n').forEach(line => {
    const p = line.split(/[|｜]/).map(x => x.trim()); if (p.length < 4 || !p[0]) return;
    let opts, ans, ex = '';
    const numIdx = p.findIndex((x, i) => i >= 3 && /^[১-৪1-4]$/.test(x));
    if (numIdx > 0) { opts = p.slice(1, numIdx); ans = +_bd(p[numIdx]) - 1; ex = p.slice(numIdx + 1).join(' | '); } else { opts = p.slice(1, 5); ans = 0; }
    opts = opts.filter(Boolean); if (opts.length < 2 || !(ans >= 0 && ans < opts.length)) return;
    out.push({q: p[0].slice(0, 200), o: opts.slice(0, 4), a: ans, e: ex.slice(0, 400)});
  });
  return out;
}

// =====================================================================
//  ইউজারের নিজের পছন্দের রং (৭টি)
// =====================================================================
const UCOLORS = [['সবুজ', '#006a4e'], ['নীল', '#0b5ed7'], ['বেগুনি', '#6d28d9'], ['লাল', '#b91c1c'], ['কমলা', '#c2410c'], ['গোলাপি', '#be185d'], ['টিল', '#0f766e']];
function ucolorBox() {
  let cur = ''; try { cur = localStorage.getItem('ucolor') || ''; } catch (e) {}
  return `<div class="box" style="text-align:center"><b>🎨 আমার পছন্দের রং</b><div style="font-size:13px;color:#666;margin:4px 0 8px">অ্যাপের রং আপনার মতো বদলে নিন</div><div style="display:flex;justify-content:center;gap:9px;flex-wrap:wrap">${UCOLORS.map(c => `<button aria-label="${c[0]}" onclick="setUColor('${c[1]}')" style="width:40px;height:40px;border-radius:50%;border:${cur === c[1] ? '4px solid #111' : '2px solid #fff'};box-shadow:0 1px 5px rgba(0,0,0,.35);background:${c[1]}"></button>`).join('')}</div>${cur ? '<button class="btn sm" style="background:#64748b;margin-top:10px" onclick="setUColor(\'\')">↩️ অ্যাপের আসল রং</button>' : ''}</div>`;
}
function setUColor(c) { try { c ? localStorage.setItem('ucolor', c) : localStorage.removeItem('ucolor'); } catch (e) {} applyTheme(); if (document.getElementById('vs')) viewsetPage(); else profile(); }

// =====================================================================
//  🤖 প্রশ্ন বানান: AI (Claude/ChatGPT) দিয়ে বানিয়ে সরাসরি অ্যাপে বসানো
// =====================================================================
const QG_TOPICS = ['ট্রাফিক সাইন', 'রাস্তার নিয়ম ও ট্রাফিক আইন', 'ড্রাইভিং লাইসেন্স ও BRTA', 'গাড়ির যন্ত্রাংশ ও যত্ন', 'নিরাপদ ড্রাইভিং ও প্রাথমিক চিকিৎসা', 'বাংলা ভাষা ও সাহিত্য', 'ইংরেজি', 'গণিত', 'সাধারণ জ্ঞান', 'বাংলাদেশ বিষয়াবলি', 'সরকারি চাকরির প্রস্তুতি'];
function qgForm() {
  const secs = _acache.content.filter(c => c.type === 'section');
  return `<div class="cx"><b>১️⃣ AI এর জন্য নির্দেশ বানান</b><div class="hint">বিষয় ও সংখ্যা বেছে "কপি করুন" চাপুন। তারপর Claude বা ChatGPT-তে পেস্ট করুন। ওরা ঠিক অ্যাপের ধরনে প্রশ্ন বানিয়ে দেবে।</div>
    <select class="inp" id="qg_topic">${QG_TOPICS.map(t => `<option>${t}</option>`).join('')}</select>
    <input class="inp" id="qg_own" placeholder="অথবা নিজের বিষয় লিখুন (ঐচ্ছিক)">
    <div class="two"><select class="inp" id="qg_kind"><option value="mcq">MCQ (৪টি উত্তর)</option><option value="w">লিখিত প্রশ্ন-উত্তর</option></select><input class="inp" id="qg_n" type="number" min="1" max="50" value="20" placeholder="কয়টি"></div>
    <select class="inp" id="qg_lv"><option>সহজ</option><option selected>মাঝারি</option><option>কঠিন</option></select>
    <button class="btn" onclick="qgCopy()">📋 নির্দেশ কপি করুন</button><textarea class="inp" id="qg_prompt" rows="4" readonly style="display:none;font-size:12px"></textarea></div>
  <div class="cx"><b>২️⃣ MCQ বসান</b><div class="hint">AI যা বানিয়েছে তা এখানে পেস্ট করুন। প্রতি লাইনে একটি প্রশ্ন:<br>প্রশ্ন | উত্তর১ | উত্তর২ | উত্তর৩ | উত্তর৪ | সঠিক নম্বর | ব্যাখ্যা</div>
    <textarea class="inp" id="qg_mcq" rows="7" placeholder="এখানে পেস্ট করুন (একসাথে ১০০টাও চলবে)"></textarea><button class="btn sm" style="background:#475569" onclick="bulkCheck('qg_mcq')">👁️ আগে যাচাই করুন</button> <button class="btn" onclick="qgMcq()">✅ কুইজে যোগ করুন</button></div>
  <div class="cx"><b>৩️⃣ লিখিত প্রশ্ন-উত্তর বসান</b><div class="hint">প্রতি লাইনে: প্রশ্ন | উত্তর। এগুলো একটি সুন্দর পাতা হয়ে আপনার বেছে নেওয়া জায়গায় বসবে।</div>
    <input class="inp" id="qg_title" placeholder="পাতার নাম (যেমন: ট্রাফিক আইনের লিখিত প্রশ্ন)">
    <select class="inp" id="qg_parent">${parentOpts('')}</select>
    <textarea class="inp" id="qg_w" rows="7" placeholder="প্রশ্ন | উত্তর"></textarea><button class="btn" onclick="qgWritten()">✅ পাতা বানান</button></div>
  <div id="ad_msg" class="warn" style="display:none"></div>`;
}
function qgCopy() {
  const t = gv('qg_own') || gv('qg_topic'), n = Math.max(1, Math.min(50, +gv('qg_n') || 20)), lv = gv('qg_lv'), mcq = gv('qg_kind') === 'mcq';
  const p = mcq
    ? `বাংলাদেশের ড্রাইভার ও চাকরিপ্রার্থীদের জন্য "${t}" বিষয়ে ${n}টি ${lv} মানের MCQ প্রশ্ন বানাও। ভাষা সহজ বাংলা।\nনিয়ম: প্রতিটি প্রশ্ন আলাদা লাইনে, ঠিক এই ছকে, আর কিছু লিখবে না (কোনো নম্বর, তারা বা বাড়তি কথা নয়):\nপ্রশ্ন | উত্তর১ | উত্তর২ | উত্তর৩ | উত্তর৪ | সঠিক উত্তরের নম্বর (১ থেকে ৪) | এক লাইনে ব্যাখ্যা\nতথ্য অবশ্যই নির্ভুল ও বাংলাদেশের আইন অনুযায়ী হতে হবে। নিশ্চিত না হলে সেই প্রশ্ন বাদ দাও।`
    : `বাংলাদেশের ড্রাইভার ও চাকরিপ্রার্থীদের জন্য "${t}" বিষয়ে ${n}টি ${lv} মানের লিখিত প্রশ্ন ও সংক্ষিপ্ত উত্তর বানাও। ভাষা সহজ বাংলা।\nনিয়ম: প্রতিটি প্রশ্ন আলাদা লাইনে, ঠিক এই ছকে, আর কিছু লিখবে না:\nপ্রশ্ন | উত্তর\nতথ্য অবশ্যই নির্ভুল ও বাংলাদেশের আইন অনুযায়ী হতে হবে। নিশ্চিত না হলে সেই প্রশ্ন বাদ দাও।`;
  const ta = document.getElementById('qg_prompt'); ta.value = p; ta.style.display = 'block'; ta.select();
  let ok = false; try { if (navigator.clipboard && navigator.clipboard.writeText) { navigator.clipboard.writeText(p); ok = true; } else ok = document.execCommand('copy'); } catch (e) { try { ok = document.execCommand('copy'); } catch (e2) {} }
  adMsg(ok ? '✅ কপি হয়েছে। এবার Claude বা ChatGPT-তে পেস্ট করুন।' : 'উপরের লেখাটি চেপে ধরে কপি করুন।');
}
async function qgMcq() {
  const m = await sme(); if (!m) return; const rows = parseQuizBulk(gv('qg_mcq'));
  if (!rows.length) return adMsg('কোনো প্রশ্ন বোঝা যায়নি। প্রতি লাইনে: প্রশ্ন | উত্তর১ | উত্তর২ | উত্তর৩ | উত্তর৪ | সঠিক নম্বর');
  if (rows.length > 100) return adMsg('একবারে সর্বোচ্চ ১০০টি।');
  try { adMsg('⏳ যোগ হচ্ছে...'); for (const r of rows) await m.f.F.addDoc(m.f.F.collection(m.f.db, 'content'), {type: 'quiz', title: r.q, body: '', url: '', pub: true, by: m.u.uid, quiz: {o: r.o, a: r.a, e: r.e}, createdAt: m.f.F.serverTimestamp()}); await refreshContent(); document.getElementById('qg_mcq').value = ''; adMsg('✅ ' + rows.length + 'টি প্রশ্ন কুইজে যোগ হয়েছে। মডেল টেস্টে দেখুন।'); } catch (e) { adMsg('⚠️ যোগ হয়নি।'); }
}
async function qgWritten() {
  const m = await sme(); if (!m) return; const title = gv('qg_title'), parent = gv('qg_parent');
  if (!title) return adMsg('পাতার নাম দিন।');
  const rows = gv('qg_w').split('\n').map(l => l.split(/[|｜]/).map(x => x.trim())).filter(p => p.length >= 2 && p[0] && p[1]);
  if (!rows.length) return adMsg('কোনো প্রশ্ন বোঝা যায়নি। প্রতি লাইনে: প্রশ্ন | উত্তর');
  const body = rows.map((p, i) => `**${i + 1}. ${p[0]}**\n${p.slice(1).join(' | ')}\n`).join('\n');
  if (body.length > 19000) return adMsg('অনেক বড় হয়ে গেছে। দুই ভাগে দিন।');
  try { adMsg('⏳ বানানো হচ্ছে...'); await m.f.F.addDoc(m.f.F.collection(m.f.db, 'content'), {type: 'node', parent, title: title.slice(0, 150), titleEn: '', body, bodyEn: '', lang: 'auto', color: '#0369a1', ic: '📝', ord: 0, mt: 'none', url: '', pub: true, by: m.u.uid, createdAt: m.f.F.serverTimestamp()}); await refreshContent(); document.getElementById('qg_w').value = ''; adMsg('✅ ' + rows.length + 'টি প্রশ্নের পাতা তৈরি। "' + keyName(parent) + '" এর ভিতরে দেখুন।'); } catch (e) { adMsg('⚠️ হয়নি।'); }
}

// =====================================================================
//  অ্যাডমিন লগইন (সাইড মেনুর 🛡️ অ্যাডমিন থেকে, বা ওয়েবে ঠিকানার শেষে #admin)
// =====================================================================
function adminLoginView() {
  const web = !(window.Capacitor && Capacitor.isNativePlatform && Capacitor.isNativePlatform());
  return `<div class="cx"><b>🛡️ অ্যাডমিন লগইন</b><div class="hint">শুধু অ্যাডমিনের আইডি দিয়ে ঢোকা যায়। মোবাইল নম্বর ও পাসওয়ার্ড দিন।</div>
    <input class="inp" id="al_id" placeholder="মোবাইল নম্বর (01XXXXXXXXX) বা ইমেইল" autocomplete="username"><input class="inp" id="al_pw" type="password" placeholder="পাসওয়ার্ড" autocomplete="current-password">
    <div id="ad_msg" class="warn" style="display:none"></div>
    <button class="btn" onclick="adLogin()">🔐 লগইন</button>
    ${web ? '<button class="btn" style="background:#4285f4;margin-top:8px" onclick="adGoogle()">🔵 Gmail (Google) দিয়ে লগইন</button>' : ''}</div>
    <div class="cx"><b>প্রথমবার?</b><div class="hint">আগে "লগইন ও ব্যাকআপ" পাতা থেকে অ্যাডমিনের মোবাইল নম্বর দিয়ে নতুন অ্যাকাউন্ট খুলুন। তারপর এখানে এসে লগইন করুন। নম্বরটি অ্যাডমিন তালিকায় থাকলে প্যানেল নিজে খুলে যাবে।</div>
    <button class="btn sm" onclick="open_('account')">নতুন অ্যাকাউন্ট খুলুন</button></div>`;
}
async function adLogin() {
  const id = gv('al_id'), pw = document.getElementById('al_pw').value; if (!id || !pw) return adMsg('আইডি ও পাসওয়ার্ড দিন।');
  try { adMsg('⏳ অপেক্ষা করুন...'); await cloudLogin(id, pw); try { await upsertProfile(); } catch (e) {} adminPage(); } catch (e) { adMsg('⚠️ ' + (typeof cloudErr === 'function' ? cloudErr(e) : 'লগইন হয়নি।')); }
}
async function adGoogle() {
  try {
    adMsg('⏳ Google খুলছে...'); const f = await fb(); const r = await f.A.signInWithPopup(f.auth, new f.A.GoogleAuthProvider()); const u = r.user;
    setCloudInfo({id: u.email || u.uid, name: u.displayName || '', uid: u.uid, last: 0}); try { await upsertProfile(); } catch (e) {} adminPage();
  } catch (e) {
    const c = e && e.code; adMsg('⚠️ ' + (c === 'auth/popup-closed-by-user' ? 'লগইন বাতিল হয়েছে।' : c === 'auth/unauthorized-domain' ? 'এই ওয়েবসাইটের ঠিকানা Firebase এর Authorized domains এ যোগ করা হয়নি।' : c === 'auth/operation-not-allowed' ? 'Firebase এ Google লগইন চালু করা হয়নি।' : 'Google লগইন হয়নি। আবার চেষ্টা করুন।'));
  }
}

// =====================================================================
//  যেকোনো কিছু লুকানো বা সরানো: অ্যাপের নিজের লেখা, কার্ড, কুইজের প্রশ্ন, টিপস
// =====================================================================
const hhash = t => { let h = 5381; for (let i = 0; i < t.length; i++) h = ((h << 5) + h + t.charCodeAt(i)) | 0; return (h >>> 0).toString(36); };
const hkey = el => { const t = document.querySelector('#app .page-h h2'); return (t ? t.textContent.trim() : '') + '|' + hhash((el.textContent || '').replace(/\s+/g, ' ').trim().slice(0, 140)); };
const _hmap = {};
const editsSafe = () => { try { return APPCFG().edits || {}; } catch (e) { return {}; } };
function elText(el) {
  const c = el.cloneNode(true); c.querySelectorAll('.hbtn').forEach(b => b.remove());
  c.querySelectorAll('br').forEach(n => n.replaceWith('\n')); c.querySelectorAll('div,p,li,summary,h3,h4,b').forEach(n => n.insertAdjacentText('afterend', '\n'));
  return c.textContent.split('\n').map(x => x.replace(/\s+/g, ' ').trim()).filter(Boolean).join('\n');
}
function applyEdit(el, text) {
  const L = String(text).split('\n'), first = L[0] || '', rest = L.slice(1).join('\n');
  el.innerHTML = el.tagName === 'DETAILS' ? `<summary style="font-weight:700">${esc(first)}</summary><div class="rich" style="padding-top:6px">${rich(rest)}</div>` : `<div style="font-weight:800;margin-bottom:4px">${esc(first)}</div><div class="rich">${rich(rest)}</div>`;
  el.dataset.edd = '1';
}
function hideScan() {
  try { pdfBar(); } catch (e) {}
  try {
    if (document.querySelector('#app .hrow') || document.getElementById('sbody') || document.querySelector('#app .lhero, #app .profile')) return;
    const adm = isAdminFlag(), h = hidSafe().d, ed = editsSafe();
    document.querySelectorAll('#app .hbtn').forEach(b => b.remove());
    document.querySelectorAll('#app .qa, #app .infoc, #app .acc, #app .card').forEach(el => {
      if (el.closest('#kids') || el.classList.contains('tile')) return;
      const k = el.dataset.hk || (el.dataset.hk = hkey(el)), hid = h.includes(k);
      if (hid && !adm) { el.remove(); return; }
      if (!_hmap[k] || !el.dataset.edd) _hmap[k] = {orig: elText(el), html: el.innerHTML};
      if (ed[k] && !el.dataset.edd) applyEdit(el, ed[k]);
      el.classList.toggle('xh', hid && adm);
      if (adm) {
        const host = el.tagName === 'DETAILS' ? (el.querySelector('summary') || el) : el; host.style.position = 'relative';
        const mk = (cls, label, fn) => { const b = document.createElement('button'); b.className = 'hbtn ' + cls; b.textContent = label; b.onclick = e => { e.stopPropagation(); e.preventDefault(); fn(); }; host.appendChild(b); return b; };
        mk(hid ? 'on' : '', hid ? '♻️' : '🗑️', () => hideToggle(k)).title = hid ? 'ফিরিয়ে আনুন' : 'মুছুন'; mk('ed', '✏️', () => hideEdit(k)).title = 'বদলান'; host.classList.add('hadm');
      }
    });
  } catch (e) {}
}
let _heK = '';
function hideEdit(k) {
  const o = _hmap[k]; if (!o) return; _heK = k; const cur = editsSafe()[k] || o.orig;
  showModal(`<h3 style="margin:0 0 8px">✏️ লেখা বদলান</h3><div class="hint">প্রথম লাইন শিরোনাম হবে। নিচের লাইনগুলো বিবরণ। <b>**মোটা**</b>, <b>{red:লাল}</b> ও <b>- তালিকা</b> দেওয়া যায়।</div><textarea class="inp" id="he_t" rows="10">${esc(cur)}</textarea><div id="he_m" class="warn" style="display:none"></div>
    <button class="btn" onclick="hideEditSave()">💾 সেভ করুন</button> <button class="btn sm" style="background:#475569" onclick="hideEditReset()">↩️ আসল লেখা ফেরান</button>`);
}
async function hideEditSave() {
  const k = _heK;
  const t = (document.getElementById('he_t').value || '').trim().slice(0, 3000); if (!t) { const m = document.getElementById('he_m'); m.style.display = 'block'; m.textContent = 'লেখা ফাঁকা রাখা যাবে না।'; return; }
  const m = await sme(); if (!m) return;
  try {
    await m.f.F.setDoc(m.f.F.doc(m.f.db, 'content', 'appconfig'), {type: 'config', title: 'config', pub: true, by: m.u.uid, cfg: {edits: {[k]: t}}, createdAt: m.f.F.serverTimestamp()}, {merge: true});
    await refreshContent(); closeModal(); const el = [...document.querySelectorAll('#app [data-hk]')].find(e => e.dataset.hk === k); if (el) { if (!el.dataset.edd) _hmap[k] = {orig: _hmap[k].orig, html: el.innerHTML}; applyEdit(el, t); hideScan(); }
  } catch (e) { alert('সেভ হয়নি। ইন্টারনেট ও অ্যাডমিন লগইন দেখুন।'); }
}
async function hideEditReset() {
  const k = _heK;
  const m = await sme(); if (!m) return;
  try {
    await m.f.F.setDoc(m.f.F.doc(m.f.db, 'content', 'appconfig'), {type: 'config', title: 'config', pub: true, by: m.u.uid, cfg: {edits: {[k]: ''}}, createdAt: m.f.F.serverTimestamp()}, {merge: true});
    await refreshContent(); closeModal(); const el = [...document.querySelectorAll('#app [data-hk]')].find(e => e.dataset.hk === k); if (el && _hmap[k]) { el.innerHTML = _hmap[k].html; delete el.dataset.edd; hideScan(); }
  } catch (e) { alert('হয়নি।'); }
}
async function hideSave(patch) {
  const m = await sme(); if (!m) return false;
  try { await m.f.F.setDoc(m.f.F.doc(m.f.db, 'content', 'appconfig'), {type: 'config', title: 'config', pub: true, by: m.u.uid, cfg: {hidden: patch}, createdAt: m.f.F.serverTimestamp()}, {merge: true}); await refreshContent(); return true; } catch (e) { alert('সেভ হয়নি। ইন্টারনেট ও অ্যাডমিন লগইন দেখুন।'); return false; }
}
async function hideToggle(k) { const h = hidSafe(), i = h.d.indexOf(k); i >= 0 ? h.d.splice(i, 1) : h.d.push(k); if (await hideSave(h)) hideScan(); }
function hidForm() {
  const h = hidSafe(), qs = (_quizBase || QUIZ), ts = (_tipBase || TIPS);
  return `<div class="cx"><b>🙈 লুকানো ও সরানো</b><div class="hint">অ্যাপের নিজের কার্ড, লেখা, কুইজের প্রশ্ন বা টিপস যা চান লুকিয়ে ফেলুন। ভুল করলে আবার দেখানো যায়। অ্যাডমিন হিসেবে অ্যাপের যেকোনো পাতায় ঢুকলে প্রতিটি কার্ডে "🙈 লুকান" বাটন দেখবেন। তাতে চাপলেই ওই কার্ড সবার কাছ থেকে সরে যাবে।</div>
    <div class="hint">এখন লুকানো কার্ড: <b>${bn(h.d.length)}</b>টি ${h.d.length ? '<button class="btn sm" style="background:#475569" onclick="hidClear()">সব আবার দেখান</button>' : ''}</div></div>
    <div class="cx"><b>❓ কুইজের প্রশ্ন (${bn(qs.length)}টি)</b><input class="inp" placeholder="খুঁজুন..." oninput="hidFilter(this.value)">
    <div id="hidq">${qs.map((q, i) => `<label class="hrow" data-t="${esc(q[0])}"><input type="checkbox" ${h.q.includes(q[0]) ? 'checked' : ''} onchange="hidSet('q',${i},this.checked)"><span>${esc(q[0])}</span></label>`).join('')}</div><div class="hint">টিক দেওয়া প্রশ্ন আর কুইজে আসবে না।</div></div>
    <div class="cx"><b>💡 টিপস (${bn(ts.length)}টি)</b>${ts.map((t, i) => `<label class="hrow"><input type="checkbox" ${h.t.includes(t) ? 'checked' : ''} onchange="hidSet('t',${i},this.checked)"><span>${esc(t)}</span></label>`).join('')}</div>`;
}
function hidFilter(v) { document.querySelectorAll('#hidq .hrow').forEach(r => { r.style.display = !v || r.getAttribute('data-t').includes(v) ? '' : 'none'; }); }
async function hidSet(kind, i, on) {
  const h = hidSafe(), src = kind === 'q' ? (_quizBase || QUIZ).map(q => q[0]) : (_tipBase || TIPS), t = src[i], a = h[kind], j = a.indexOf(t);
  if (on && j < 0) a.push(t); if (!on && j >= 0) a.splice(j, 1);
  await hideSave(h); applyTips(); applyQuiz();
}
async function hidClear() { const h = hidSafe(); h.d = []; if (await hideSave(h)) adminPage('hid'); }
(function () { const st = document.createElement('style'); st.textContent = `.hrow{display:flex;gap:8px;align-items:flex-start;padding:7px 0;border-bottom:1px solid #eee;font-size:14px}.hrow input{margin-top:3px;width:20px;height:20px;flex:none}`; document.head.appendChild(st); })();

async function layHide(id) {
  layCommit(); const m = await sme(); if (!m) return; const t = JSON.parse(JSON.stringify(APPCFG().tiles || {})); t[id] = t[id] || {}; t[id].hide = !t[id].hide; if (!t[id].hide) delete t[id].hide;
  try { await m.f.F.setDoc(m.f.F.doc(m.f.db, 'content', 'appconfig'), {type: 'config', title: 'config', pub: true, by: m.u.uid, cfg: {tiles: t}, createdAt: m.f.F.serverTimestamp()}, {merge: true}); await refreshContent(); layRefresh(); adMsg('✅ হয়েছে। 🙈 মানে হোমে লুকানো, 👁️ মানে দেখা যাচ্ছে।'); } catch (e) { adMsg('⚠️ হয়নি।'); }
}

// ================= PDF নেওয়া ও চাকরির প্রশ্ন অর্ডার =================
const pdfCfg = () => { try { const c = APPCFG(); return {def: c.pdfDef !== false, off: c.pdfOff || [], on: c.pdfOn || []}; } catch (e) { return {def: true, off: [], on: []}; } };
const pdfAllowed = t => { const p = pdfCfg(); return p.def ? !p.off.includes(t) : p.on.includes(t); };
const pdfTitle = () => { const h = document.querySelector('#app .page-h h2'); return h ? h.textContent.trim() : ''; };
function pdfPageEls() { const a = document.getElementById('app'); return a ? Array.from(a.children).filter(x => x.id !== 'drw' && x.id !== 'dbg' && x.id !== 'pdfbar') : []; }
function pdfBar() {
  try {
    const old = document.getElementById('pdfbar'); if (old) old.remove();
    const els = pdfPageEls(); if (!els.length || !els.some(e => e.classList.contains('page-h'))) return;
    if (document.getElementById('sbody') || els.some(e => e.matches('.lhero,.profile') || e.querySelector('.lhero,.profile,input,textarea,select,canvas,.hrow'))) return;
    const t = pdfTitle(); if (!t) return;
    const adm = typeof isAdminFlag === 'function' && isAdminFlag(), ok = pdfAllowed(t); if (!ok && !adm) return;
    if (els.map(e => e.textContent).join('').length < 150) return;
    const d = document.createElement('div'); d.id = 'pdfbar'; d.className = 'pad';
    d.innerHTML = (ok ? `<button class="btn" style="width:100%;background:#b91c1c" onclick="pdfPage()">📄 এই পাতা PDF হিসেবে নিন</button>` : '') +
      (adm ? `<div class="adbar" style="margin-top:8px"><span>🛡️ PDF</span><button onclick="pdfToggle()">${ok ? '🔒 শুধু অ্যাপে রাখুন (লোকাল)' : '📄 PDF চালু করুন'}</button></div>` : '');
    const drw = document.getElementById('drw'); drw ? drw.parentNode.insertBefore(d, drw) : document.getElementById('app').appendChild(d);
  } catch (e) {}
}
async function pdfSaveCfg(patch) {
  const m = await sme(); if (!m) { alert('অ্যাডমিন লগইন দরকার।'); return false; }
  try { await m.f.F.setDoc(m.f.F.doc(m.f.db, 'content', 'appconfig'), {type: 'config', title: 'config', pub: true, by: m.u.uid, cfg: patch, createdAt: m.f.F.serverTimestamp()}, {merge: true}); await refreshContent(); return true; } catch (e) { alert('সেভ হয়নি। ইন্টারনেট ও অ্যাডমিন লগইন দেখুন।'); return false; }
}
async function pdfToggle() {
  const t = pdfTitle(), p = pdfCfg(), ok = pdfAllowed(t); let off = p.off.slice(), on = p.on.slice();
  if (p.def) { ok ? off.push(t) : off = off.filter(x => x !== t); } else { ok ? on = on.filter(x => x !== t) : on.push(t); }
  if (await pdfSaveCfg({pdfOff: off, pdfOn: on})) pdfBar();
}
async function pdfDefSet(v) { if (await pdfSaveCfg({pdfDef: !!v})) { adMsg('✅ সেভ হয়েছে।'); } }
function pdfPageText() {
  const box = document.createElement('div'); box.style.cssText = 'position:absolute;left:-9999px;top:0;width:380px;font:14px sans-serif';
  pdfPageEls().forEach(e => { if (e.classList.contains('page-h') || e.classList.contains('hero')) return; box.appendChild(e.cloneNode(true)); });
  box.querySelectorAll('button,.hbtn,.adbar,#pdfbar,#kids .adbar,script,style,input,select,textarea,.adtop,.adbot,.ticker,.nka').forEach(x => x.remove());
  box.querySelectorAll('details').forEach(d => d.setAttribute('open', ''));
  document.body.appendChild(box); const tx = (box.innerText || '').replace(/\n{3,}/g, '\n\n').trim(); box.remove(); return tx;
}
function pdfMulti(jpgs, w, h) {
  const enc = s => new TextEncoder().encode(s), W = 595, H = Math.round(595 * h / w), parts = [], off = []; let len = 0; const add = b => { parts.push(b); len += b.length; };
  const n = jpgs.length, tot = 2 + 3 * n; add(enc('%PDF-1.4\n'));
  const obj = (i, body) => { off[i] = len; add(enc(i + ' 0 obj\n' + body + '\nendobj\n')); };
  obj(1, '<< /Type /Catalog /Pages 2 0 R >>'); obj(2, `<< /Type /Pages /Kids [${jpgs.map((_, i) => (3 + 3 * i) + ' 0 R').join(' ')}] /Count ${n} >>`);
  jpgs.forEach((j, i) => {
    const p = 3 + 3 * i, cs = `q ${W} 0 0 ${H} 0 0 cm /Im${i} Do Q`;
    obj(p, `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${W} ${H}] /Contents ${p + 1} 0 R /Resources << /XObject << /Im${i} ${p + 2} 0 R >> >> >>`);
    obj(p + 1, `<< /Length ${cs.length} >>\nstream\n${cs}\nendstream`);
    off[p + 2] = len; add(enc(`${p + 2} 0 obj\n<< /Type /XObject /Subtype /Image /Width ${w} /Height ${h} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${j.length} >>\nstream\n`)); add(j); add(enc('\nendstream\nendobj\n'));
  });
  const xr = len; let x = `xref\n0 ${tot + 1}\n0000000000 65535 f \n`; for (let i = 1; i <= tot; i++) x += String(off[i]).padStart(10, '0') + ' 00000 n \n';
  add(enc(x + `trailer\n<< /Size ${tot + 1} /Root 1 0 R >>\nstartxref\n${xr}\n%%EOF`));
  const out = new Uint8Array(len); let q = 0; parts.forEach(b => { out.set(b, q); q += b.length; }); return out;
}
async function pdfBuild(title, text) {
  const fam = getComputedStyle(document.body).fontFamily || 'sans-serif', W = 1240, H = 1754, M = 100, FS = 34, LH = 56; const pages = [];
  try { await document.fonts.load('34px ' + fam); await document.fonts.load('bold 34px ' + fam); } catch (e) {}
  let cv, g, y;
  const col = () => { try { return getComputedStyle(document.documentElement).getPropertyValue('--p2').trim() || '#006a4e'; } catch (e) { return '#006a4e'; } };
  const newPage = () => {
    cv = document.createElement('canvas'); cv.width = W; cv.height = H; g = cv.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, W, H);
    g.fillStyle = col(); g.fillRect(0, 0, W, 14); g.textBaseline = 'alphabetic'; g.font = `bold 26px ${fam}`; g.fillStyle = '#64748b'; g.fillText(appName(), M, 70); y = 150; pages.push(cv);
  };
  const wrap = (s, font) => {
    g.font = font; const out = []; let line = '';
    s.split(/(\s+)/).forEach(w => {
      if (!w) return; const t = line + w;
      if (g.measureText(t).width <= W - 2 * M) { line = t; return; }
      if (line.trim()) out.push(line.trim()); line = '';
      if (g.measureText(w).width <= W - 2 * M) { line = w.trimStart(); return; }
      Array.from(w).forEach(ch => { if (g.measureText(line + ch).width > W - 2 * M) { out.push(line); line = ''; } line += ch; });
    });
    if (line.trim()) out.push(line.trim()); return out;
  };
  newPage(); g.font = `bold 50px ${fam}`; g.fillStyle = '#0f172a';
  const tl = wrap(title, `bold 50px ${fam}`); tl.forEach(l => { g.font = `bold 50px ${fam}`; g.fillStyle = '#0f172a'; g.fillText(l, M, y); y += 72; });
  g.fillStyle = col(); g.fillRect(M, y - 28, 140, 6); y += 36;
  text.split('\n').forEach(raw => {
    const s = raw.trim(); if (!s) { y += LH * 0.5; return; }
    const font = `${FS}px ${fam}`, ls = wrap(s, font);
    ls.forEach(l => { if (y > H - 140) newPage(); g.font = font; g.fillStyle = '#1e293b'; g.fillText(l, M, y); y += LH; });
  });
  pages.forEach((c, i) => { const x = c.getContext('2d'); x.font = `24px ${fam}`; x.fillStyle = '#94a3b8'; x.fillText(appName() + ' • পাতা ' + bn(i + 1) + '/' + bn(pages.length), M, H - 60); });
  return {jpgs: pages.map(c => Uint8Array.from(atob(c.toDataURL('image/jpeg', 0.9).split(',')[1]), ch => ch.charCodeAt(0))), W, H};
}
async function pdfPage() {
  const t = pdfTitle(), btn = document.querySelector('#pdfbar .btn'); if (btn) { btn.disabled = true; btn.textContent = '⏳ PDF বানানো হচ্ছে...'; }
  try {
    const tx = pdfPageText(); if (tx.length < 20) throw {message: 'পাতায় লেখা নেই।'};
    const r = await pdfBuild(t, tx), bytes = pdfMulti(r.jpgs, r.W, r.H), fname = (t.replace(/[^\wঀ-৿]+/g, '-').slice(0, 30) || 'page') + '.pdf', C = window.Capacitor;
    if (C && C.isNativePlatform && C.isNativePlatform()) {
      const FS = C.registerPlugin('Filesystem'), SH = C.registerPlugin('Share'); const o = await FS.writeFile({path: fname, data: u8b64(bytes), directory: 'CACHE'});
      await SH.share({title: t, url: o.uri, dialogTitle: 'PDF কোথায় রাখবেন?'});
    } else { const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([bytes], {type: 'application/pdf'})); a.download = fname; document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 800); }
  } catch (e) { if (!(e && /cancel/i.test(String(e.message || e)))) alert('PDF হয়নি: ' + ((e && e.message) || '')); }
  if (btn) { btn.disabled = false; btn.textContent = '📄 এই পাতা PDF হিসেবে নিন'; }
}

// ---- চাকরির প্রশ্ন অর্ডার ----
async function orderPage() {
  tab = 'community'; render(pageHead('চাকরির প্রশ্ন নিন') + hero('📨', 'চাকরির প্রশ্ন নিন', 'কোম্পানি বা ব্যক্তি — নিজের নিয়োগ পরীক্ষার প্রশ্ন বানিয়ে নিন') + '<div class="pad" id="sbody"><div class="empty"><span class="e1">⏳</span>লোড হচ্ছে...</div></div>');
  const b = document.getElementById('sbody'); if (!CLOUD_ON()) return b.innerHTML = sNeedSetup();
  const m = await sme(); if (!m) return b.innerHTML = sNeedLogin();
  b.innerHTML = `<div class="cx"><b>📨 প্রশ্নের অনুরোধ পাঠান</b><div class="hint">আপনার কোম্পানি বা পদের জন্য MCQ / লিখিত প্রশ্ন দরকার? তথ্য দিন, অ্যাপের নির্মাতা আপনার সাথে যোগাযোগ করবেন এবং প্রশ্ন PDF আকারে দেবেন।</div>
    <input class="inp" id="od_co" maxlength="80" placeholder="কোম্পানি / প্রতিষ্ঠানের নাম (বা আপনার নাম)">
    <input class="inp" id="od_pn" maxlength="60" placeholder="যোগাযোগকারীর নাম">
    <input class="inp" id="od_ph" maxlength="20" inputmode="tel" placeholder="মোবাইল নম্বর (যেমন 017XXXXXXXX)">
    <input class="inp" id="od_post" maxlength="80" placeholder="কোন পদের জন্য প্রশ্ন? (যেমন ড্রাইভার, হেলপার)">
    <input class="inp" id="od_cnt" maxlength="6" inputmode="numeric" placeholder="কতটি প্রশ্ন দরকার? (যেমন 50)">
    <select class="inp" id="od_kind"><option>MCQ (বহুনির্বাচনি)</option><option>লিখিত প্রশ্ন</option><option>MCQ ও লিখিত দুটোই</option><option>ড্রাইভিং ব্যবহারিক টেস্টের তালিকা</option></select>
    <textarea class="inp" id="od_note" rows="3" maxlength="500" placeholder="অন্য কিছু জানাতে চাইলে (পরীক্ষার তারিখ, বিষয়, ইত্যাদি)"></textarea>
    <div id="od_msg" class="warn" style="display:none"></div><button class="btn" onclick="orderSend()">📨 অনুরোধ পাঠান</button></div>
    <div id="od_mine"></div>`;
  orderMine(m);
}
async function orderMine(m) {
  try {
    const rows = await sList(m.f, ['qorders'], m.f.F.where('by', '==', m.u.uid)), el = document.getElementById('od_mine'); if (!el || !rows.length) return;
    el.innerHTML = `<div class="cx"><b>আপনার আগের অনুরোধ</b>` + rows.map(r => `<div class="hint" style="border-top:1px solid #eee;padding-top:6px">${esc(r.post || '')} — ${esc(String(r.count || ''))}টি ${esc(r.kind || '')} <span class="tag" style="background:${r.done ? '#128c4a' : '#b45309'}">${r.done ? 'সম্পন্ন' : 'অপেক্ষায়'}</span></div>`).join('') + '</div>';
  } catch (e) {}
}
async function orderSend() {
  const msg = t => { const b = document.getElementById('od_msg'); if (b) { b.style.display = 'block'; b.textContent = t; } };
  const m = await sme(); if (!m) return msg('লগইন করুন।');
  const o = {company: gv('od_co'), person: gv('od_pn'), phone: gv('od_ph').replace(/[^\d+]/g, ''), post: gv('od_post'), count: gv('od_cnt').replace(/\D/g, ''), kind: gv('od_kind'), note: gv('od_note')};
  if (!o.company) return msg('কোম্পানি বা আপনার নাম লিখুন।'); if (o.phone.length < 8) return msg('সঠিক মোবাইল নম্বর দিন।'); if (!o.post) return msg('কোন পদের জন্য প্রশ্ন তা লিখুন।');
  try { msg('⏳ পাঠানো হচ্ছে...'); await m.f.F.addDoc(m.f.F.collection(m.f.db, 'qorders'), Object.assign(o, {by: m.u.uid, done: false, createdAt: m.f.F.serverTimestamp()})); msg('✅ অনুরোধ পাঠানো হয়েছে। শীঘ্রই যোগাযোগ করা হবে।'); orderMine(m); }
  catch (e) { msg('⚠️ পাঠানো যায়নি। ইন্টারনেট ও লগইন দেখুন।'); }
}
async function orderAdminView(m) {
  const rows = await sList(m.f, ['qorders'], m.f.F.orderBy('createdAt', 'desc'), m.f.F.limit(60)); _acache.qorders = rows; const p = pdfCfg();
  return `<div class="cx"><b>📄 PDF নেওয়ার সাধারণ নিয়ম</b><div class="hint">চালু থাকলে প্রতিটি পাতার নিচে "PDF নিন" বাটন আসবে। কোনো পাতা আলাদা করে লোকাল (শুধু অ্যাপে) রাখতে সেই পাতা খুলে নিচের "🔒 শুধু অ্যাপে রাখুন" চাপুন।</div>
    <label style="display:block;margin:8px 0"><input type="radio" name="pdfdef" ${p.def ? 'checked' : ''} onchange="pdfDefSet(true)"> সব পাতায় PDF চালু (যেটা বন্ধ করব সেটা বাদ)</label>
    <label style="display:block;margin:8px 0"><input type="radio" name="pdfdef" ${p.def ? '' : 'checked'} onchange="pdfDefSet(false)"> সব পাতা লোকাল (যেটায় চালু করব শুধু সেটায় PDF)</label>
    <div class="hint">আলাদা করে বন্ধ করা পাতা: ${p.off.length ? esc(p.off.join(', ')) : 'নেই'}${p.on.length ? '<br>আলাদা করে চালু করা পাতা: ' + esc(p.on.join(', ')) : ''}</div><div id="ad_msg" class="warn" style="display:none"></div></div>` +
    `<div class="cx"><b>📨 প্রশ্নের অনুরোধ (${bn(rows.length)}টি)</b></div>` + (rows.length ? rows.map((r, i) => `<div class="cx" style="border-left-color:${r.done ? '#128c4a' : '#b45309'}"><b>${esc(r.company)}</b> — ${esc(r.post || '')}<div class="hint">${esc(r.person || '')} • ${esc(String(r.count || ''))}টি • ${esc(r.kind || '')}</div>${r.note ? `<div class="hint" style="white-space:pre-line">${esc(r.note)}</div>` : ''}
    <a class="btn sm" style="text-decoration:none;display:inline-block" href="tel:${esc(r.phone)}">📞 ${esc(r.phone)}</a> <button class="btn sm" style="background:#128c4a" onclick="orderAct(${i},'done')">${r.done ? '↩️ অপেক্ষায় দিন' : '✅ সম্পন্ন'}</button> <button class="btn sm" style="background:#dc2626" onclick="orderAct(${i},'del')">🗑️</button></div>`).join('') : sEmpty('📭', 'এখনো কোনো অনুরোধ আসেনি।'));
}
async function orderAct(i, a) {
  const m = await sme(); const r = _acache.qorders && _acache.qorders[i]; if (!m || !r) return;
  try { const d = m.f.F.doc(m.f.db, 'qorders', r.id); if (a === 'del') { if (!confirm('মুছবেন?')) return; await m.f.F.deleteDoc(d); } else await m.f.F.updateDoc(d, {done: !r.done}); adminPage('ord'); } catch (e) { alert('হয়নি।'); }
}

// =====================================================================
//  নতুন আপডেট: নোটিশ বোর্ড, আজকের প্রশ্ন, গ্রুপে আইকন, নোটপ্যাড, টুলস, পরিসংখ্যান, জুম
// =====================================================================
[{id: 'notes', name: 'নোটপ্যাড ও নোট', ic: '🗒️', color: '#7c3aed', sub: 'নোট, ডক, শিট, তারিখে নোটিফিকেশন'}, {id: 'tools', name: 'দৈনন্দিন টুলস', ic: '🧰', color: '#0891b2', sub: 'ক্যালকুলেটর, তেল খরচ, ইউনিট, বয়স'}, {id: 'viewset', name: 'দেখার সেটিং', ic: '🔎', color: '#475569', sub: 'লেখা ছোট-বড় ও রং'}, {id: 'qorder', name: 'চাকরির প্রশ্ন নিন', ic: '📨', color: '#b45309', sub: 'কোম্পানির জন্য প্রশ্ন'}].forEach(x => { if (!CATS.find(c => c.id === x.id)) CATS.push(x); });
const todayS = () => { const d = new Date(); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); };
const dTo = iso => { const a = String(iso).split('-').map(Number); if (a.length < 3 || !a[0]) return NaN; return Math.round((new Date(a[0], a[1] - 1, a[2]) - new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getDate())) / 864e5); };
const bnDate = iso => { const a = String(iso || '').split('-'); return a.length === 3 ? bn(+a[2]) + '/' + bn(+a[1]) + '/' + bn(+a[0]) : ''; };
const ntcCfg = () => { try { const c = APPCFG().ntc || {}; return {nw: c.nw !== false, jb: c.jb !== false}; } catch (e) { return {nw: true, jb: true}; } };
const isExp = c => !!(c.exp && c.exp < todayS());

// ---- আজকের প্রশ্ন (লুকান / ঠিক করা) ----
function dailyCardNew() {
  const c = APPCFG().daily || {}, adm = isAdminFlag(); if (c.hide && !adm) return '';
  const q = QUIZ[(Number.isInteger(c.pick) && c.pick >= 0 ? c.pick : dayIdx()) % QUIZ.length], st = load('daily', {}), ans = st.d === todayISO() ? st.a : -1;
  return `<div class="daily" id="daily" ${c.hide ? 'style="opacity:.55"' : ''}>${adm ? `<div class="adbar" style="margin:0 0 8px"><span>🛡️ আজকের প্রশ্ন${c.hide ? ' (লুকানো)' : ''}</span><button onclick="dailyAdmin()">✏️ বদলান / লুকান</button></div>` : ''}<div class="dh2"><b>আজকের প্রশ্ন</b><span>${ans >= 0 ? (ans === q[2] ? '✅ সঠিক' : '❌ ভুল') : ''}</span></div><div class="dq">${esc(q[0])}</div>` +
    q[1].map((o, i) => `<div class="opt ${ans >= 0 ? (i === q[2] ? 'ok' : (i === ans ? 'no' : '')) : ''}" onclick="dailyPick(${i})">${esc(o)}</div>`).join('') + '</div>';
}
function dailyAdmin() {
  const c = APPCFG().daily || {}, fix = Number.isInteger(c.pick) && c.pick >= 0;
  showModal(`<h3 style="margin:0 0 8px">✏️ আজকের প্রশ্ন</h3><label style="display:block;margin:6px 0"><input type="radio" name="dq" value="auto" ${fix ? '' : 'checked'}> প্রতিদিন নিজে বদলাবে (একটার পর একটা)</label>
    <label style="display:block;margin:6px 0"><input type="radio" name="dq" value="fix" ${fix ? 'checked' : ''}> সবসময় এই প্রশ্নটি দেখাবে:</label>
    <select class="inp" id="dq_sel">${QUIZ.map((q, i) => `<option value="${i}" ${c.pick === i ? 'selected' : ''}>${esc(String(q[0]).slice(0, 70))}</option>`).join('')}</select>
    <label style="display:block;margin:8px 0"><input type="checkbox" id="dq_hide" ${c.hide ? 'checked' : ''}> ব্যবহারকারীদের থেকে পুরোটা লুকান</label>
    <div class="hint">নিজের নতুন প্রশ্ন যোগ করতে: অ্যাডমিন → নতুন → কুইজ প্রশ্ন।</div><button class="btn" onclick="dailySave()">💾 সেভ করুন</button>`);
}
async function dailySave() {
  const fix = (document.querySelector('input[name=dq]:checked') || {}).value === 'fix', pick = fix ? +document.getElementById('dq_sel').value : -1;
  if (await pdfSaveCfg({daily: {hide: document.getElementById('dq_hide').checked, pick}})) { closeModal(); home(); }
}

// ---- নোটিশ বোর্ড (হোমে) ----
function noticeItems() {
  const out = [], tdy = todayS(), cf = ntcCfg();
  if (cf.jb) ADMIN_CONTENT.filter(c => c.type === 'job' && c.pub !== false && c.job && c.job.deadline).forEach(c => { const d = dTo(c.job.deadline); if (d >= 0 && d <= 30) out.push({k: 0, d, ic: '💼', t: ((c.job.c ? c.job.c + ' — ' : '') + (c.title || '')), s: d === 0 ? 'আজই শেষ দিন!' : 'আর ' + bn(d) + ' দিন', hot: d <= 3, go: "open_('job')"}); });
  (() => { const pn = ADMIN_CONTENT.find(c => c.type === 'notice' && c.pin && !isExp(c)); let dx = []; try { dx = JSON.parse(localStorage.getItem('noticeX') || '[]'); } catch (e) {} return ADMIN_CONTENT.filter(c => c.type === 'notice' && c.pub !== false && !isExp(c) && !(pn && c.id === pn.id && !dx.includes(pn.id))); })().slice(0, 6).forEach(c => out.push({k: 1, d: 99, ic: c.pin ? '📌' : '📢', t: c.title || (c.body || '').slice(0, 50), s: c.exp ? 'শেষ: ' + bnDate(c.exp) : '', hot: false, go: `boardItem('${esc(c.id)}')`, id: c.id}));
  if (cf.nw) ADMIN_CONTENT.filter(c => ['node', 'article', 'video', 'audio', 'image', 'section'].includes(c.type) && c.pub !== false && c.at && Date.now() - c.at < 3 * 864e5).slice(0, 4).forEach(c => out.push({k: 2, d: 98, ic: '🆕', t: 'নতুন: ' + (c.title || ''), s: '', hot: false, go: c.type === 'node' ? `push(()=>home());nodePage('${esc(c.id)}')` : c.type === 'section' ? `open_('sec_${esc(c.id)}')` : `boardItem('${esc(c.id)}')`}));
  try { notesDue().forEach(n => out.push({k: -1, d: n.dd, ic: '🗒️', t: 'আমার নোট: ' + n.t, s: n.dd < 0 ? 'সময় পার হয়ে গেছে' : n.dd === 0 ? 'আজ' : 'আর ' + bn(n.dd) + ' দিন', hot: n.dd <= 0, go: "open_('notes')"})); } catch (e) {}
  return out.sort((a, b) => a.k - b.k || a.d - b.d);
}
function noticeBoard(adm) {
  const items = noticeItems(); if (!items.length && !adm) return '';
  return `<div class="nboard" id="nboard"><div class="nbh"><b>📌 নোটিশ বোর্ড</b>${adm ? `<span><button onclick="ntcNew()">➕ নোটিশ</button></span>` : ''}</div>` +
    (items.length ? items.map(x => `<div class="nbi ${x.hot ? 'hot' : ''}" onclick="${x.go}"><span class="nbic">${x.ic}</span><span class="nbt">${esc(x.t)}</span>${x.s ? `<span class="nbs">${esc(x.s)}</span>` : ''}${adm && x.id ? `<button class="nbx" onclick="event.stopPropagation();adDelNotice('${esc(x.id)}')">🗑️</button>` : ''}</div>`).join('') : '<div class="hint" style="padding:6px 2px">এখন কোনো নোটিশ নেই। "➕ নোটিশ" চেপে দিন।</div>') + '</div>';
}
function ntcNew() {
  showModal(`<h3 style="margin:0 0 8px">📣 নতুন নোটিশ</h3><input class="inp" id="nt_ti" maxlength="100" placeholder="শিরোনাম (যেমন: নতুন আপডেট হয়েছে)"><textarea class="inp" id="nt_bo" rows="4" maxlength="800" placeholder="বিস্তারিত (ঐচ্ছিক)"></textarea>
    <select class="inp" id="nt_ex"><option value="0">মেয়াদ নেই (নিজে মুছব)</option><option value="3">৩ দিন পর নিজে সরে যাবে</option><option value="7" selected>৭ দিন পর নিজে সরে যাবে</option><option value="15">১৫ দিন পর</option><option value="30">৩০ দিন পর</option></select>
    <label style="display:block;margin:8px 0"><input type="checkbox" id="nt_pin" checked> হোমের উপরে ভেসে থাকুক (পিন)</label><div id="nt_m" class="warn" style="display:none"></div><button class="btn" onclick="ntcSave()">📣 প্রকাশ করুন</button>`);
}
async function ntcSave() {
  const msg = t => { const b = document.getElementById('nt_m'); if (b) { b.style.display = 'block'; b.textContent = t; } };
  const ti = gv('nt_ti'); if (!ti) return msg('শিরোনাম লিখুন।'); const m = await sme(); if (!m) return msg('অ্যাডমিন লগইন দরকার।');
  const dd = +gv('nt_ex'); let exp = ''; if (dd) { const d = new Date(); d.setDate(d.getDate() + dd); exp = d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); }
  try { await m.f.F.addDoc(m.f.F.collection(m.f.db, 'content'), {type: 'notice', title: ti.slice(0, 100), body: gv('nt_bo').slice(0, 800), url: '', pub: true, pin: document.getElementById('nt_pin').checked, exp, by: m.u.uid, createdAt: m.f.F.serverTimestamp()}); await refreshContent(); closeModal(); home(); }
  catch (e) { msg('⚠️ হয়নি। ইন্টারনেট ও অ্যাডমিন লগইন দেখুন।'); }
}
async function adDelNotice(id) { if (!confirm('নোটিশটি মুছবেন?')) return; const m = await sme(); if (!m) return; try { await m.f.F.deleteDoc(m.f.F.doc(m.f.db, 'content', id)); await refreshContent(); home(); } catch (e) { alert('মোছা যায়নি।'); } }

// ---- হোমে অ্যাডমিনের বাড়তি বাটন (গ্রুপ ও আইকন) ----
function homeExtras() {
  try {
    const old = document.getElementById('nboard'); if (old) old.remove();
    document.querySelectorAll('#app .gh-b, #app .tl-b').forEach(e => e.remove());
    if (!document.querySelector('#app .qrow')) return;
    const adm = typeof isAdminFlag === 'function' && isAdminFlag(), html = noticeBoard(adm), anchor = document.getElementById('daily') || document.querySelector('#app .tip');
    if (html && anchor) anchor.insertAdjacentHTML('beforebegin', html);
    if (!adm) return;
    document.querySelectorAll('#app .sec-h').forEach(h => {
      const name = h.getAttribute('data-gn') || (h.dataset.gn = h.textContent.trim());
      const s = document.createElement('span'); s.className = 'gh-b';
      s.innerHTML = `<button title="এই গ্রুপে নতুন আইকন" onclick="grpAdd(this)">➕</button><button title="গ্রুপের নাম বদলান" onclick="grpRename(this)">✏️</button>`; s.dataset.gn = name; h.appendChild(s);
    });
    document.querySelectorAll('#app .tile').forEach(t => {
      const mm = (t.getAttribute('onclick') || '').match(/open_\('([^']+)'\)/); if (!mm) return; const id = mm[1]; t.style.position = 'relative';
      const s = document.createElement('span'); s.className = 'tl-b'; s.innerHTML = `<button onclick="event.stopPropagation();tileEdit('${id}')">✏️</button><button onclick="event.stopPropagation();tileDel('${id}')">🗑️</button>`; t.appendChild(s);
    });
  } catch (e) {}
}
let _presetGrp = '';
function grpAdd(b) { _presetGrp = b.parentNode.dataset.gn; _presetType = 'section'; adminPage('pub'); }
async function grpSaveLayout(mut) {
  await refreshContent(); layInit(); mut(_lay); const m = await sme(); if (!m) return false; const layout = _lay.filter(g => g.name || g.ids.length).map(g => ({name: g.name || 'গ্রুপ', ids: g.ids}));
  return pdfSaveCfg({layout});
}
async function grpPlace(id, name) { return grpSaveLayout(L => { L.forEach(g => { g.ids = g.ids.filter(x => x !== 'sec_' + id); }); const t = L.find(g => g.name === name); if (t) t.ids.push('sec_' + id); else L.push({name, ids: ['sec_' + id]}); }); }
async function grpRename(b) {
  const old = b.parentNode.dataset.gn, nn = (prompt('গ্রুপের নতুন নাম:', old) || '').trim().slice(0, 40); if (!nn || nn === old) return;
  if (await grpSaveLayout(L => { const g = L.find(x => x.name === old); if (g) g.name = nn; })) home();
}
function tileEdit(id) {
  const o = tileOv(id), c = CATS.find(x => x.id === id) || {}, nm = o.name || SHORT[id] || c.name || id, ic = o.ic || c.ic || '';
  showModal(`<h3 style="margin:0 0 8px">✏️ আইকন বদলান</h3><input class="inp" id="te_nm" maxlength="40" value="${esc(nm)}" placeholder="নাম"><input class="inp" id="te_ic" maxlength="4" value="${esc(ic)}" placeholder="ইমোজি"><div id="te_m" class="warn" style="display:none"></div><button class="btn" onclick="tileSave('${esc(id)}')">💾 সেভ করুন</button> <button class="btn sm" style="background:#475569" onclick="tileSave('${esc(id)}',1)">↩️ আসল নাম ফেরান</button>`);
}
async function tileSave(id, reset) {
  const o = Object.assign({}, tileOv(id)); if (reset) { delete o.name; delete o.ic; } else { const n = gv('te_nm'), i = Array.from(gv('te_ic')).slice(0, 2).join(''); if (n) o.name = n.slice(0, 40); if (i) o.ic = i; }
  if (await pdfSaveCfg({tiles: {[id]: o}})) { closeModal(); home(); }
}
async function tileDel(id) { if (!confirm('এই আইকনটি হোম থেকে সরাবেন? (অ্যাডমিন → রং ও পরিচয় থেকে ফেরানো যাবে)')) return; const o = Object.assign({}, tileOv(id), {hide: true}); if (await pdfSaveCfg({tiles: {[id]: o}})) home(); }

// ---- পুরনো তারিখের পত্রিকা খোঁজা ----
function paperDateBox() {
  try {
    const host = document.querySelector('#app .pad:not(#kids)'); if (!host) return;
    const nodes = ADMIN_CONTENT.filter(c => c.type === 'node' && c.parent === 'paper' && c.pd), ms = [...new Set(nodes.map(c => c.pd.slice(0, 7)))].sort().reverse();
    host.insertAdjacentHTML('afterbegin', `<div class="cx" style="border-left-color:#9333ea"><b>📅 পুরনো পত্রিকা তারিখ দিয়ে খুঁজুন</b><div class="hint">যে তারিখের পত্রিকা চান সেই তারিখ বেছে "খুঁজুন" চাপুন।</div><div class="two"><input class="inp" type="date" id="pp_d" max="${todayS()}"><button class="btn" onclick="ppFind()">🔍 খুঁজুন</button></div>
      ${ms.length ? `<div class="chips" style="margin-top:6px">${ms.map(x => `<button class="chip" onclick="ppMonth('${x}')">${bn(x.slice(5, 7))}/${bn(x.slice(0, 4))}</button>`).join('')}</div>` : ''}<div id="pp_res"></div></div>`);
  } catch (e) {}
}
function ppShow(list, note) { const r = document.getElementById('pp_res'); if (r) r.innerHTML = (note ? `<div class="hint" style="margin:8px 0">${note}</div>` : '') + list.map(c => nodeCard(c, 'paper')).join(''); }
function ppFind() {
  const d = gv('pp_d'); if (!d) return ppShow([], 'আগে একটি তারিখ বেছে নিন।');
  const all = ADMIN_CONTENT.filter(c => c.type === 'node' && c.parent === 'paper' && c.pd), hit = all.filter(c => c.pd === d);
  if (hit.length) return ppShow(hit, '✅ ' + bnDate(d) + ' এর পত্রিকা:');
  const near = all.slice().sort((a, b) => Math.abs(dTo(a.pd) - dTo(d)) - Math.abs(dTo(b.pd) - dTo(d))).slice(0, 3);
  ppShow(near, '⚠️ ' + bnDate(d) + ' তারিখের পত্রিকা এখনো যোগ হয়নি।' + (near.length ? ' কাছাকাছি তারিখের গুলো:' : ''));
}
function ppMonth(m) { ppShow(ADMIN_CONTENT.filter(c => c.type === 'node' && c.parent === 'paper' && c.pd && c.pd.slice(0, 7) === m).sort((a, b) => b.pd.localeCompare(a.pd)), '📅 ' + bn(m.slice(5, 7)) + '/' + bn(m.slice(0, 4)) + ' মাসের পত্রিকা:'); }

// ---- পাতার নিচে নাম/ক্রেডিট ও তারিখ; ভিতরেই PDF পড়া ----
function nodeExtra(id) {
  try {
    const c = ADMIN_CONTENT.find(x => x.id === id); if (!c || !(c.pd || c.credit)) return; const h = document.querySelector('#app .cx h3'); if (!h) return;
    h.parentNode.insertAdjacentHTML('beforeend', `<div class="hint" style="margin-top:10px">${c.pd ? '📅 ' + bnDate(c.pd) : ''}${c.pd && c.credit ? ' • ' : ''}${c.credit ? '✍️ ' + esc(c.credit) : ''}</div>`);
  } catch (e) {}
}
function pdfInline(u) { return `<button class="btn" style="width:100%;margin:6px 0;background:#b91c1c" data-u="${esc(u)}" onclick="pvToggle(this)">📖 অ্যাপের ভিতরে পড়ুন</button><div class="pvbox"></div>`; }
function pvToggle(b) {
  const el = b.nextElementSibling; if (el.innerHTML) { el.innerHTML = ''; b.textContent = '📖 অ্যাপের ভিতরে পড়ুন'; return; }
  const u = b.dataset.u, dm = u.match(/drive\.google\.com\/file\/d\/([^/?#]+)/), src = dm ? 'https://drive.google.com/file/d/' + dm[1] + '/preview' : 'https://docs.google.com/gview?embedded=1&url=' + encodeURIComponent(u);
  el.innerHTML = `<iframe src="${esc(src)}" style="width:100%;height:70vh;border:1px solid #ddd;border-radius:10px"></iframe><div class="hint">না খুললে নিচের "PDF খুলুন" বাটন চাপুন।</div>`; b.textContent = '❌ বন্ধ করুন';
}

// ---- পরিসংখ্যান (অ্যাডমিন) ----
async function statView(m) {
  const rows = await sList(m.f, ['profiles'], m.f.F.limit(3000)), now = Date.now(), t0 = new Date(); t0.setHours(0, 0, 0, 0);
  const a1 = rows.filter(r => r.at >= now - 864e5).length, a7 = rows.filter(r => r.at >= now - 7 * 864e5).length, nw = rows.filter(r => (r.first || 0) >= t0.getTime()).length, n7 = rows.filter(r => (r.first || 0) >= now - 7 * 864e5).length;
  const rec = rows.slice().sort((x, y) => (y.at || 0) - (x.at || 0)).slice(0, 15);
  const box = (n, l, c) => `<div style="flex:1;min-width:46%;background:${c}1a;border-radius:12px;padding:10px;margin:4px;text-align:center"><div style="font-size:28px;font-weight:800;color:${c}">${bn(n)}</div><div style="font-size:12.5px">${l}</div></div>`;
  return `<div class="cx"><b>👥 ব্যবহারকারীর পরিসংখ্যান</b><div style="display:flex;flex-wrap:wrap">${box(rows.length, 'মোট অ্যাকাউন্ট', '#0369a1')}${box(a1, 'গত ২৪ ঘণ্টায় সক্রিয়', '#b45309')}${box(a7, 'গত ৭ দিনে সক্রিয়', '#128c4a')}${box(nw, 'আজ নতুন', '#7c3aed')}${box(n7, 'গত ৭ দিনে নতুন', '#be185d')}</div>
    <div class="hint">যারা লগইন করে অ্যাপ খুলেছেন তাদের গোনা হয়। লগইন ছাড়া ব্যবহারকারী এখানে আসে না।</div></div>
    <div class="cx"><b>🕒 সবশেষ সক্রিয়</b>${rec.length ? rec.map(r => `<div class="hint" style="border-top:1px solid #eee;padding:5px 0">${esc(r.name || 'নামহীন')} <span style="float:right">${sdate(r.at)}</span></div>`).join('') : sEmpty('📭', 'এখনো কেউ নেই।')}</div>
    <div class="cx"><b>📢 নোটিশ বোর্ডের সেটিং</b><label style="display:block;margin:6px 0"><input type="checkbox" ${ntcCfg().jb ? 'checked' : ''} onchange="ntcSet('jb',this.checked)"> চাকরির মেয়াদ কত দিন বাকি — নিজে দেখাক</label>
    <label style="display:block;margin:6px 0"><input type="checkbox" ${ntcCfg().nw ? 'checked' : ''} onchange="ntcSet('nw',this.checked)"> নতুন কনটেন্ট দিলে "🆕 নতুন" নিজে দেখাক (৩ দিন)</label><button class="btn sm" onclick="ntcNew()">➕ নতুন নোটিশ দিন</button><div id="ad_msg" class="warn" style="display:none"></div></div>`;
}
async function ntcSet(k, v) { const c = Object.assign({}, ntcCfg(), {[k]: !!v}); if (await pdfSaveCfg({ntc: c})) adMsg('✅ সেভ হয়েছে।'); }

// ---- দেখার সেটিং: জুম, রং, শেষ পাতায় ফেরা ----
function uzoomApply() { try { const z = +localStorage.getItem('uzoom'); document.body.style.zoom = z >= 70 && z <= 160 ? z / 100 : ''; } catch (e) {} }
function uzoomSet(v) { try { v === 0 ? localStorage.removeItem('uzoom') : localStorage.setItem('uzoom', String(Math.max(70, Math.min(160, v)))); } catch (e) {} uzoomApply(); viewsetPage(); }
function viewsetPage() {
  tab = 'profile'; let z = 100, nr = false; try { z = +localStorage.getItem('uzoom') || 100; nr = localStorage.getItem('noresume') === '1'; } catch (e) {}
  render(pageHead('দেখার সেটিং') + hero('🔎', 'দেখার সেটিং', 'আপনার মতো করে সাজান') + `<div class="pad" id="vs"><div class="box" style="text-align:center"><b>🔎 পুরো অ্যাপ ছোট-বড় (জুম)</b>
    <div style="font-size:30px;font-weight:800;margin:8px 0">${bn(z)}%</div><div class="two"><button class="btn" onclick="uzoomSet(${z - 10})">➖ ছোট</button><button class="btn" onclick="uzoomSet(${z + 10})">➕ বড়</button></div><button class="btn sm" style="background:#475569;margin-top:8px" onclick="uzoomSet(0)">↩️ স্বাভাবিক (১০০%)</button></div>
    ${ucolorBox()}<div class="box"><b>🌙 রাতের মোড</b><div style="margin-top:6px"><button class="btn sm" onclick="toggleDark()">🌙 চালু / বন্ধ</button></div></div>
    <div class="box"><label><input type="checkbox" ${nr ? '' : 'checked'} onchange="try{localStorage.setItem('noresume',this.checked?'0':'1');if(!this.checked)localStorage.removeItem('lastPg')}catch(e){}"> অ্যাপ আবার খুললে শেষ দেখা পাতায় ফিরুন</label></div></div>`);
}

// ---- নোটপ্যাড, ডক, শিট (তারিখে নোটিফিকেশনসহ) ----
const notesLoad = () => { try { const a = JSON.parse(localStorage.getItem('notes') || '[]'); return Array.isArray(a) ? a : []; } catch (e) { return []; } };
const notesSaveAll = a => { try { localStorage.setItem('notes', JSON.stringify(a)); } catch (e) { alert('জায়গা শেষ, সেভ হয়নি।'); } };
function notesDue() {
  return notesLoad().filter(n => n.d && !n.done && n.r).map(n => ({t: n.t || 'নোট', dd: dTo(n.d), ah: +n.ah || 0})).filter(n => n.dd <= n.ah).sort((a, b) => a.dd - b.dd);
}
const LNP = () => { try { const C = window.Capacitor; if (C && C.isNativePlatform && C.isNativePlatform()) return C.registerPlugin('LocalNotifications'); } catch (e) {} return null; };
const notifId = id => (parseInt(String(id).slice(-7), 36) || 1) % 2000000000;
async function notifCancel(id) { const ln = LNP(); if (!ln) return; try { await ln.cancel({notifications: [{id: notifId(id)}]}); } catch (e) {} }
async function notifSchedule(n) {
  const ln = LNP(); if (!ln) return 'web'; await notifCancel(n.id); if (!n.r || !n.d || n.done) return 'off';
  try {
    const p = await ln.requestPermissions(); if (p.display !== 'granted') return 'denied';
    const a = n.d.split('-').map(Number), tm = (n.tm || '09:00').split(':').map(Number), at = new Date(a[0], a[1] - 1, a[2] - (+n.ah || 0), tm[0] || 9, tm[1] || 0, 0);
    if (at <= new Date()) return 'past';
    await ln.schedule({notifications: [{id: notifId(n.id), title: 'চালক ভাই: ' + (n.t || 'নোট'), body: (n.b || '').slice(0, 100) || 'আপনার নোটের সময় হয়েছে', schedule: {at, allowWhileIdle: true}}]}); return 'ok';
  } catch (e) { return 'err'; }
}
let _nk = 'note', _nid = '', _sh = null;
function notesPage(k) {
  if (k) _nk = k; tab = 'home'; const all = notesLoad(), list = all.filter(n => (n.k || 'note') === _nk).sort((a, b) => (a.d || '9').localeCompare(b.d || '9') || (b.u || 0) - (a.u || 0));
  const tabs = [['note', '🗒️ নোট'], ['doc', '📄 ডক'], ['sheet', '📊 শিট']];
  render(pageHead('নোটপ্যাড') + hero('🗒️', 'আমার নোট', 'নোট, ডক ও শিট — তারিখে নোটিফিকেশন') + `<div class="pad"><div class="seg">${tabs.map(t => `<button class="${_nk === t[0] ? 'on' : ''}" onclick="notesPage('${t[0]}')">${t[1]}</button>`).join('')}</div>
    <button class="btn" style="width:100%;margin:8px 0" onclick="notesEdit('')">➕ নতুন ${{note: 'নোট', doc: 'ডক', sheet: 'শিট'}[_nk]}</button>` +
    (list.length ? list.map(n => { const dd = n.d ? dTo(n.d) : NaN; return `<div class="nk" style="border-left-color:${n.done ? '#9ca3af' : '#7c3aed'}" onclick="notesEdit('${esc(n.id)}')"><span class="nki" style="background:#7c3aed22">${{note: '🗒️', doc: '📄', sheet: '📊'}[n.k || 'note']}</span><div class="nkt"><b style="${n.done ? 'text-decoration:line-through;opacity:.6' : ''}">${esc(n.t || 'নামহীন')}</b><small>${n.d ? '📅 ' + bnDate(n.d) + (n.r ? ' 🔔' : '') + (!n.done && dd === 0 ? ' • আজ' : !n.done && dd < 0 ? ' • সময় পার' : '') : esc(((n.k === 'sheet' ? '' : n.b) || '').slice(0, 40))}</small></div><span class="nka">›</span></div>`; }).join('') : sEmpty('📭', 'এখনো কিছু নেই। ওপরের বাটনে চাপুন।')) + '</div>');
}
function notesEdit(id) {
  _nid = id; const n = notesLoad().find(x => x.id === id) || {k: _nk, t: '', b: '', d: '', tm: '09:00', r: false, ah: 0}, k = n.k || _nk; _nk = k;
  if (k === 'sheet') { try { _sh = JSON.parse(n.b || 'null'); } catch (e) { _sh = null; } if (!Array.isArray(_sh) || !_sh.length) _sh = [['তারিখ', 'বিষয়', 'টাকা'], ['', '', ''], ['', '', '']]; }
  const tools = k === 'doc' ? `<div class="tbar">${[['b', '<b>B</b> মোটা'], ['h1', 'বড় শিরোনাম'], ['h2', 'মাঝারি'], ['li', '• তালিকা'], ['red', '🔴 লাল']].map(x => `<button type="button" onclick="tbIns('nt_b','${x[0]}')">${x[1]}</button>`).join('')}</div>` : '';
  stack.push(() => notesPage(k));
  render(pageHead(n.id ? 'নোট সম্পাদনা' : 'নতুন ' + {note: 'নোট', doc: 'ডক', sheet: 'শিট'}[k]) + `<div class="pad"><div class="cx"><input class="inp" id="nt_t" maxlength="100" placeholder="শিরোনাম" value="${esc(n.t)}">
    ${k === 'sheet' ? `<div id="sh_w">${shHtml()}</div><div class="two"><button class="btn sm" onclick="shAdd('r')">➕ সারি</button><button class="btn sm" onclick="shAdd('c')">➕ কলাম</button></div>`
      : `${tools}<textarea class="inp" id="nt_b" rows="${k === 'doc' ? 14 : 7}" placeholder="${k === 'doc' ? 'এখানে লিখুন (# বড় শিরোনাম, - তালিকা, **মোটা**)' : 'নোট লিখুন (যেমন: রহিমের কাছে ১০০ টাকা ধার নিয়েছি)'}">${esc(n.b)}</textarea>`}
    <div class="hint" style="margin-top:8px"><b>🔔 তারিখে মনে করিয়ে দিন</b></div><div class="two"><input class="inp" type="date" id="nt_d" value="${esc(n.d || '')}"><input class="inp" type="time" id="nt_tm" value="${esc(n.tm || '09:00')}"></div>
    <select class="inp" id="nt_ah"><option value="0" ${!n.ah ? 'selected' : ''}>ওই দিনই জানান</option><option value="1" ${+n.ah === 1 ? 'selected' : ''}>১ দিন আগে জানান</option><option value="3" ${+n.ah === 3 ? 'selected' : ''}>৩ দিন আগে জানান</option></select>
    <label style="display:block;margin:8px 0"><input type="checkbox" id="nt_r" ${n.r ? 'checked' : ''}> মোবাইলে নোটিফিকেশন দিন</label>
    <div id="nt_msg" class="warn" style="display:none"></div><button class="btn" onclick="notesSave()">💾 সেভ করুন</button>
    ${n.id ? `<button class="btn sm" style="background:#128c4a" onclick="notesDone()">${n.done ? '↩️ আবার চালু' : '✅ হয়ে গেছে'}</button><button class="btn sm" style="background:#dc2626" onclick="notesDel()">🗑️ মুছুন</button>` : ''}
    ${k !== 'sheet' && n.id ? `<button class="btn sm" style="background:#b91c1c" onclick="notesPdf()">📄 PDF</button>` : ''}</div></div>`);
}
const shCols = () => Math.max(...(_sh || [[]]).map(r => r.length));
const shSums = () => { const nc = shCols(), out = []; for (let c = 0; c < nc; c++) { let s = 0, any = false; _sh.slice(1).forEach(r => { const v = parseFloat(_bd(String(r[c] || '').replace(/,/g, ''))); if (!isNaN(v)) { s += v; any = true; } }); out.push(c === 0 ? 'মোট' : any ? bn(Math.round(s * 100) / 100) : ''); } return out; };
function shHtml() {
  const nc = shCols();
  return `<div style="overflow-x:auto"><table class="sht">${_sh.map((r, i) => `<tr>${Array.from({length: nc}, (_, c) => `<${i ? 'td' : 'th'}><input value="${esc(r[c] || '')}" oninput="shSet(${i},${c},this.value)"></${i ? 'td' : 'th'}>`).join('')}</tr>`).join('')}<tr class="shs">${shSums().map(s => `<td>${s}</td>`).join('')}</tr></table></div>`;
}
function shSet(r, c, v) { while (_sh[r].length <= c) _sh[r].push(''); _sh[r][c] = v; const w = document.querySelector('.shs'); if (w) w.innerHTML = shSums().map(s => `<td>${s}</td>`).join(''); }
function shAdd(w) { if (w === 'r') _sh.push(Array(shCols()).fill('')); else { const n = shCols() + 1; _sh.forEach((r, i) => { while (r.length < n) r.push(i ? '' : 'কলাম'); }); } document.getElementById('sh_w').innerHTML = shHtml(); }
async function notesSave() {
  const msg = t => { const b = document.getElementById('nt_msg'); if (b) { b.style.display = 'block'; b.textContent = t; } };
  const k = _nk, t = gv('nt_t'); if (!t) return msg('শিরোনাম লিখুন।'); const all = notesLoad(); let n = all.find(x => x.id === _nid);
  if (!n) { n = {id: Date.now().toString(36) + Math.random().toString(36).slice(2, 5), k}; all.push(n); }
  Object.assign(n, {k, t, b: k === 'sheet' ? JSON.stringify(_sh) : (document.getElementById('nt_b').value || '').slice(0, 20000), d: gv('nt_d'), tm: gv('nt_tm') || '09:00', ah: +gv('nt_ah') || 0, r: chk('nt_r'), u: Date.now(), done: false});
  if (n.r && !n.d) return msg('নোটিফিকেশনের জন্য তারিখ দিন।');
  notesSaveAll(all); const r = n.r ? await notifSchedule(n) : (await notifCancel(n.id), 'off');
  const info = {web: 'সেভ হয়েছে। (নোটিফিকেশন শুধু অ্যাপে আসে; এখানে অ্যাপ খুললে নোটিশ বোর্ডে দেখাবে।)', denied: 'সেভ হয়েছে, কিন্তু নোটিফিকেশনের অনুমতি দেওয়া হয়নি। ফোনের সেটিংসে অনুমতি দিন।', past: 'সেভ হয়েছে, কিন্তু সময়টি পার হয়ে গেছে।', err: 'সেভ হয়েছে, নোটিফিকেশন ঠিক করা যায়নি।'}[r];
  if (info) alert(info); stack.pop(); notesPage(k);
}
function notesDone() { const all = notesLoad(), n = all.find(x => x.id === _nid); if (!n) return; n.done = !n.done; notesSaveAll(all); n.done ? notifCancel(n.id) : notifSchedule(n); stack.pop(); notesPage(n.k); }
function notesDel() { if (!confirm('মুছে ফেলবেন?')) return; const all = notesLoad(), n = all.find(x => x.id === _nid); notifCancel(_nid); notesSaveAll(all.filter(x => x.id !== _nid)); stack.pop(); notesPage(n ? n.k : 'note'); }
function notesPdf() { const n = notesLoad().find(x => x.id === _nid); if (n) pdfShareText(n.t || 'নোট', (n.b || '').replace(/\*\*/g, '').replace(/^#+\s*/gm, '').replace(/\{red:([^}]*)\}/g, '$1')); }

// ---- দৈনন্দিন টুলস ----
let _calc = '';
function tlCalc(k) {
  if (k === 'C') _calc = ''; else if (k === '⌫') _calc = _calc.slice(0, -1);
  else if (k === '=') { try { const e = _bd(_calc).replace(/×/g, '*').replace(/÷/g, '/'); if (!/^[0-9+\-*/().% ]+$/.test(e)) throw 0; const v = Function('"use strict";return (' + e + ')')(); _calc = isFinite(v) ? String(Math.round(v * 1e8) / 1e8) : 'ভুল'; } catch (e) { _calc = 'ভুল'; } }
  else { if (_calc === 'ভুল') _calc = ''; _calc += k; }
  const d = document.getElementById('cl_d'); if (d) d.textContent = _calc ? bn(_calc) : '০';
}
const nv = id => parseFloat(_bd(gv(id))) || 0;
function tlFuel() { const km = nv('tf_k'), mi = nv('tf_m'), pr = nv('tf_p'), L = mi ? km / mi : 0; document.getElementById('tf_r').innerHTML = mi && km ? `⛽ তেল লাগবে: <b>${bn(Math.round(L * 100) / 100)} লিটার</b>${pr ? `<br>💰 খরচ: <b>${bn(Math.round(L * pr))} টাকা</b> • কিমি প্রতি ${bn(Math.round(L * pr / km * 100) / 100)} টাকা` : ''}` : ''; }
const UNITS = {km: ['কিমি ↔ মাইল', 'কিমি', 'মাইল', 0.621371], kg: ['কেজি ↔ পাউন্ড', 'কেজি', 'পাউন্ড', 2.20462], l: ['লিটার ↔ গ্যালন', 'লিটার', 'গ্যালন', 0.264172], m: ['মিটার ↔ ফুট', 'মিটার', 'ফুট', 3.28084], c: ['°C ↔ °F', '°C', '°F', 0]};
function tlUnit() { const t = gv('tu_t'), u = UNITS[t], v = parseFloat(_bd(gv('tu_v'))), r = document.getElementById('tu_r'); if (isNaN(v)) return r.innerHTML = ''; const a = t === 'c' ? v * 9 / 5 + 32 : v * u[3], b = t === 'c' ? (v - 32) * 5 / 9 : v / u[3]; r.innerHTML = `${bn(v)} ${u[1]} = <b>${bn(Math.round(a * 1000) / 1000)} ${u[2]}</b><br>${bn(v)} ${u[2]} = <b>${bn(Math.round(b * 1000) / 1000)} ${u[1]}</b>`; }
function tlAge() { const d = gv('ta_d'); if (!d) return; const a = d.split('-').map(Number), n = new Date(); let y = n.getFullYear() - a[0], m = n.getMonth() + 1 - a[1], dd = n.getDate() - a[2]; if (dd < 0) { m--; dd += new Date(n.getFullYear(), n.getMonth(), 0).getDate(); } if (m < 0) { y--; m += 12; } document.getElementById('ta_r').innerHTML = `বয়স: <b>${bn(y)} বছর ${bn(m)} মাস ${bn(dd)} দিন</b>`; }
function tlDate() { const a = gv('td_a'), b = gv('td_b') || todayS(), n = parseInt(_bd(gv('td_n'))); let h = ''; if (a) { const df = Math.round((new Date(b) - new Date(a)) / 864e5); h += `দুই তারিখের ব্যবধান: <b>${bn(Math.abs(df))} দিন</b>`; } if (a && !isNaN(n)) { const x = new Date(a); x.setDate(x.getDate() + n); h += `<br>${bnDate(a)} + ${bn(n)} দিন = <b>${bnDate(x.getFullYear() + '-' + String(x.getMonth() + 1).padStart(2, '0') + '-' + String(x.getDate()).padStart(2, '0'))}</b>`; } document.getElementById('td_r').innerHTML = h; }
function tlSplit() { const t = nv('ts_t'), p = nv('ts_p'); document.getElementById('ts_r').innerHTML = t && p ? `জনপ্রতি: <b>${bn(Math.round(t / p * 100) / 100)} টাকা</b>` : ''; }
function tlPct() { const x = nv('tp_x'), y = nv('tp_y'); document.getElementById('tp_r').innerHTML = y ? `${bn(x)}% of ${bn(y)} = <b>${bn(Math.round(x * y) / 100)}</b><br>${bn(y)} থেকে ${bn(x)}% ছাড়ে = <b>${bn(Math.round(y * (100 - x)) / 100)}</b>` : ''; }
function tlCur() { const a = nv('tc_a'), r = nv('tc_r'); document.getElementById('tc_r2').innerHTML = a && r ? `= <b>${bn(Math.round(a * r * 100) / 100)} টাকা</b>` : ''; }
function toolsPage() {
  tab = 'home'; const key = ['7', '8', '9', '÷', '4', '5', '6', '×', '1', '2', '3', '-', '0', '.', '%', '+', 'C', '⌫', '(', ')'];
  const T = (ic, t, inner, open) => `<details class="tl" ${open ? 'open' : ''}><summary><span>${ic}</span> ${t}</summary><div class="tlb">${inner}</div></details>`;
  render(pageHead('দৈনন্দিন টুলস') + hero('🧰', 'দৈনন্দিন টুলস', 'দরকারি হিসাব এক জায়গায়') + `<div class="pad">
    ${T('🧮', 'ক্যালকুলেটর', `<div id="cl_d" class="cld">${_calc ? bn(_calc) : '০'}</div><div class="ckeys">${key.map(k => `<button onclick="tlCalc('${k}')">${k}</button>`).join('')}<button class="eq" onclick="tlCalc('=')">=</button></div>`, 1)}
    ${T('⛽', 'তেল খরচ', `<input class="inp" id="tf_k" inputmode="decimal" placeholder="কত কিলোমিটার যাবেন" oninput="tlFuel()"><input class="inp" id="tf_m" inputmode="decimal" placeholder="গাড়ির মাইলেজ (কিমি প্রতি লিটার)" oninput="tlFuel()"><input class="inp" id="tf_p" inputmode="decimal" placeholder="তেলের দাম (টাকা প্রতি লিটার)" oninput="tlFuel()"><div id="tf_r" class="tlr"></div>`)}
    ${T('📏', 'ইউনিট বদল', `<select class="inp" id="tu_t" onchange="tlUnit()">${Object.keys(UNITS).map(k => `<option value="${k}">${UNITS[k][0]}</option>`).join('')}</select><input class="inp" id="tu_v" inputmode="decimal" placeholder="সংখ্যা" oninput="tlUnit()"><div id="tu_r" class="tlr"></div>`)}
    ${T('🎂', 'বয়স হিসাব', `<input class="inp" type="date" id="ta_d" onchange="tlAge()"><div id="ta_r" class="tlr"></div>`)}
    ${T('📅', 'তারিখ হিসাব', `<input class="inp" type="date" id="td_a" onchange="tlDate()"><input class="inp" type="date" id="td_b" onchange="tlDate()"><div class="hint">দ্বিতীয় তারিখ ফাঁকা থাকলে আজ ধরা হবে</div><input class="inp" id="td_n" inputmode="numeric" placeholder="কত দিন যোগ করবেন (যেমন 30)" oninput="tlDate()"><div id="td_r" class="tlr"></div>`)}
    ${T('🧾', 'ভাগাভাগি (বিল)', `<input class="inp" id="ts_t" inputmode="decimal" placeholder="মোট টাকা" oninput="tlSplit()"><input class="inp" id="ts_p" inputmode="numeric" placeholder="কতজন" oninput="tlSplit()"><div id="ts_r" class="tlr"></div>`)}
    ${T('％', 'শতাংশ ও ছাড়', `<input class="inp" id="tp_x" inputmode="decimal" placeholder="কত শতাংশ" oninput="tlPct()"><input class="inp" id="tp_y" inputmode="decimal" placeholder="মূল সংখ্যা / দাম" oninput="tlPct()"><div id="tp_r" class="tlr"></div>`)}
    ${T('💱', 'বিদেশি টাকা → টাকা', `<input class="inp" id="tc_a" inputmode="decimal" placeholder="বিদেশি টাকার পরিমাণ (ডলার/রিয়াল...)" oninput="tlCur()"><input class="inp" id="tc_r" inputmode="decimal" placeholder="আজকের রেট (১ এককের দাম টাকায়)" oninput="tlCur()"><div id="tc_r2" class="tlr"></div>`)}
    </div>`);
}

// ---- সাজানো ফর্মের সরঞ্জাম: টুলবার, প্রশ্ন-উত্তর/MCQ বিল্ডার, ব্লক সাজান, ১০০ MCQ যাচাই ----
function tbIns(id, kind) {
  const t = document.getElementById(id); if (!t) return; const s = t.selectionStart, e = t.selectionEnd, v = t.value, sel = v.slice(s, e), ls = v.lastIndexOf('\n', s - 1) + 1; let nvv, cs = s;
  if (kind === 'b') { nvv = v.slice(0, s) + '**' + (sel || 'মোটা লেখা') + '**' + v.slice(e); cs = s + 2; }
  else if (kind === 'red') { nvv = v.slice(0, s) + '{red:' + (sel || 'লাল লেখা') + '}' + v.slice(e); cs = s + 5; }
  else { const p = {h1: '# ', h2: '## ', li: '- '}[kind]; nvv = v.slice(0, ls) + p + v.slice(ls); cs = s + p.length; }
  t.value = nvv; t.focus(); try { t.setSelectionRange(cs, cs); } catch (x) {}
}
const bodyTools = () => `<div class="tbar">${[['b', '<b>B</b> মোটা'], ['h1', 'বড় শিরোনাম'], ['h2', 'মাঝারি'], ['li', '• তালিকা'], ['red', '🔴 লাল']].map(x => `<button type="button" onclick="tbIns('ad_body','${x[0]}')">${x[1]}</button>`).join('')}</div>`;
function qbBox() {
  return `<div class="cx" style="border-left-color:#1d4ed8;margin:8px 0"><b>❓ প্রশ্ন–উত্তর যোগ করুন</b><div class="hint">লিখে "যোগ" চাপলে উপরের লেখার ঘরে সুন্দর করে বসে যাবে।</div>
    <details style="margin:6px 0"><summary><b>✍️ লিখিত প্রশ্ন–উত্তর</b></summary><input class="inp" id="qb_q" placeholder="প্রশ্ন"><textarea class="inp" id="qb_a" rows="2" placeholder="উত্তর"></textarea><button type="button" class="btn sm" onclick="qbAdd('qa')">➕ যোগ করুন</button></details>
    <details style="margin:6px 0"><summary><b>🔘 MCQ (৪টি উত্তর)</b></summary><input class="inp" id="qb_mq" placeholder="প্রশ্ন"><input class="inp" id="qb_o1" placeholder="ক) উত্তর"><input class="inp" id="qb_o2" placeholder="খ) উত্তর"><input class="inp" id="qb_o3" placeholder="গ) উত্তর"><input class="inp" id="qb_o4" placeholder="ঘ) উত্তর">
    <select class="inp" id="qb_ok"><option value="0">সঠিক উত্তর: ক</option><option value="1">সঠিক উত্তর: খ</option><option value="2">সঠিক উত্তর: গ</option><option value="3">সঠিক উত্তর: ঘ</option></select><input class="inp" id="qb_ex" placeholder="ব্যাখ্যা (ঐচ্ছিক)"><button type="button" class="btn sm" onclick="qbAdd('mcq')">➕ MCQ যোগ করুন</button></details>
    <button type="button" class="btn sm" style="background:#b45309" onclick="blkOpen()">🔀 ব্লক সাজান (উপর-নিচ, বদল, মোছা)</button><button type="button" class="btn sm" style="background:#475569" onclick="qbPreview()">👁️ প্রিভিউ</button><div id="qb_m" class="warn" style="display:none"></div></div>`;
}
function qbAdd(kind) {
  const b = document.getElementById('ad_body'), m = document.getElementById('qb_m'), er = t => { m.style.display = 'block'; m.textContent = t; }; let add;
  const n = ((b.value.match(/^\*\*[০-৯\d]+[.।]/gm) || []).length) + 1, N = bn(n);
  if (kind === 'qa') { const q = gv('qb_q'), a = gv('qb_a'); if (!q || !a) return er('প্রশ্ন ও উত্তর দুটোই লিখুন।'); add = `**${N}. ${q}**\n${a}`; ['qb_q', 'qb_a'].forEach(i => document.getElementById(i).value = ''); }
  else { const q = gv('qb_mq'), o = [1, 2, 3, 4].map(i => gv('qb_o' + i)), k = +gv('qb_ok'); if (!q) return er('প্রশ্ন লিখুন।'); if (o.filter(Boolean).length < 2) return er('কমপক্ষে দুটি উত্তর দিন।'); if (!o[k]) return er('সঠিক উত্তরের ঘরটি ফাঁকা।'); const L = ['ক', 'খ', 'গ', 'ঘ']; add = `**${N}. ${q}**\n${o.map((x, i) => x ? L[i] + ') ' + x : '').filter(Boolean).join('\n')}\n✅ উত্তর: ${L[k]}) ${o[k]}${gv('qb_ex') ? '\nব্যাখ্যা: ' + gv('qb_ex') : ''}`; ['qb_mq', 'qb_o1', 'qb_o2', 'qb_o3', 'qb_o4', 'qb_ex'].forEach(i => document.getElementById(i).value = ''); }
  b.value = (b.value.trim() ? b.value.replace(/\s+$/, '') + '\n\n' : '') + add; m.style.display = 'block'; m.textContent = '✅ যোগ হয়েছে (প্রশ্ন নম্বর ' + N + ')।';
}
function qbPreview() { showModal('<h3 style="margin:0 0 8px">👁️ প্রিভিউ</h3><div class="rich">' + rich(document.getElementById('ad_body').value) + '</div>'); }
let _blk = [], _blkE = -1;
function blkOpen() { _blk = document.getElementById('ad_body').value.split(/\n\s*\n/).map(x => x.trim()).filter(Boolean); _blkE = -1; blkDraw(); }
function blkDraw() {
  showModal(`<h3 style="margin:0 0 8px">🔀 ব্লক সাজান</h3><div class="hint">প্রতিটি অংশ (প্রশ্ন বা অনুচ্ছেদ) আলাদা ব্লক। ওঠান, নামান, বদলান বা মুছুন।</div>` + (_blk.length ? _blk.map((x, i) => `<div class="blk">${_blkE === i ? `<div style="flex:1"><textarea class="inp" id="blk_e" rows="5">${esc(x)}</textarea><button class="btn sm" onclick="blkOk(${i})">✔️ ঠিক</button></div>` : `<div class="blkt">${bn(i + 1)}. ${esc(x.replace(/[*#{}]/g, '').split('\n')[0].slice(0, 70))}</div><div class="blkb"><button onclick="blkMv(${i},-1)">⬆️</button><button onclick="blkMv(${i},1)">⬇️</button><button onclick="_blkE=${i};blkDraw()">✏️</button><button onclick="blkDel(${i})">🗑️</button></div>`}</div>`).join('') : sEmpty('📭', 'কোনো ব্লক নেই।')) + `<button class="btn" onclick="blkApply()">✔️ ঠিক আছে, লেখায় বসান</button>`);
}
function blkMv(i, d) { const j = i + d; if (j < 0 || j >= _blk.length) return; [_blk[i], _blk[j]] = [_blk[j], _blk[i]]; blkDraw(); }
function blkDel(i) { _blk.splice(i, 1); blkDraw(); }
function blkOk(i) { _blk[i] = (document.getElementById('blk_e').value || '').trim() || _blk[i]; _blkE = -1; blkDraw(); }
function blkApply() { if (_blkE >= 0) blkOk(_blkE); document.getElementById('ad_body').value = _blk.join('\n\n'); closeModal(); }
function bulkCheck(id) {
  const t = gv(id); if (!t) return alert('আগে প্রশ্নগুলো পেস্ট করুন।'); const lines = t.split('\n').map((l, i) => [i + 1, l]).filter(x => x[1].trim()); let ok = 0; const bad = [];
  lines.forEach(([n, l]) => { parseQuizBulk(l).length ? ok++ : bad.push(n); });
  showModal(`<h3 style="margin:0 0 8px">👁️ যাচাই</h3><div style="font-size:15px">✅ ঠিক আছে: <b>${bn(ok)}</b>টি প্রশ্ন<br>${bad.length ? `⚠️ বোঝা যায়নি: <b>${bn(bad.length)}</b>টি লাইন (লাইন নম্বর: ${bad.slice(0, 40).map(bn).join(', ')})<div class="hint">প্রতি লাইনে হবে: প্রশ্ন | উত্তর১ | উত্তর২ | উত্তর৩ | উত্তর৪ | সঠিক নম্বর | ব্যাখ্যা</div>` : '🎉 সব লাইন ঠিক আছে।'}</div>`);
}
async function pdfShareText(title, text) {
  try {
    const r = await pdfBuild(title, text), bytes = pdfMulti(r.jpgs, r.W, r.H), fname = (title.replace(/[^\wঀ-৿]+/g, '-').slice(0, 30) || 'note') + '.pdf', C = window.Capacitor;
    if (C && C.isNativePlatform && C.isNativePlatform()) { const FS = C.registerPlugin('Filesystem'), SH = C.registerPlugin('Share'); const o = await FS.writeFile({path: fname, data: u8b64(bytes), directory: 'CACHE'}); await SH.share({title, url: o.uri, dialogTitle: 'PDF কোথায় রাখবেন?'}); }
    else { const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([bytes], {type: 'application/pdf'})); a.download = fname; document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 800); }
  } catch (e) { if (!(e && /cancel/i.test(String(e.message || e)))) alert('PDF হয়নি।'); }
}

// ---- অ্যাপ চালুর সময় একবারের সেটআপ (app.js শেষে ডাকা হয়) ----
function lateInit() {
  uzoomApply();
  dailyCard = dailyCardNew;
  const pp0 = paperPage; paperPage = function () { pp0.apply(this, arguments); paperDateBox(); };
  const np0 = nodePage; nodePage = function (id) { np0.apply(this, arguments); nodeExtra(id); };
  setTimeout(async () => { try { const m = await sme(); if (m && localStorage.getItem('pfDay') !== todayS()) { await upsertProfile(); localStorage.setItem('pfDay', todayS()); } } catch (e) {} }, 4500);
}
(function () { const st = document.createElement('style'); st.textContent = `
.nboard{margin:12px 12px 0;background:#fff;border:1.5px solid #fecaca;border-left:6px solid #dc2626;border-radius:14px;padding:10px 12px;box-shadow:0 2px 10px rgba(0,0,0,.06)}
.nbh{display:flex;align-items:center;justify-content:space-between;margin-bottom:4px}.nbh button{border:0;background:#c2410c;color:#fff;border-radius:9px;padding:5px 10px;font:inherit;font-size:12.5px}
.nbi{display:flex;align-items:center;gap:8px;padding:7px 0;border-top:1px solid #f1f5f9;font-size:14px}.nbi.hot .nbs{color:#dc2626;font-weight:800}.nbt{flex:1;font-weight:600}.nbs{font-size:12px;color:#b45309;white-space:nowrap}.nbx{border:0;background:none;font-size:15px}
.gh-b{float:right}.gh-b button,.tl-b button{border:0;background:#c2410c;color:#fff;border-radius:8px;padding:2px 7px;font-size:13px;margin-left:4px}
.tl-b{position:absolute;top:2px;right:2px;display:flex}.tl-b button{padding:1px 5px;font-size:12px;margin:0 1px;opacity:.92}
.fsh{background:var(--tint,#e7f3ee);color:var(--p2,#006a4e);font-weight:800;font-size:13.5px;padding:7px 10px;border-radius:9px;margin:12px 0 6px}
.tbar{display:flex;flex-wrap:wrap;gap:5px;margin:6px 0}.tbar button{border:1px solid #cbd5e1;background:#eef2f7;border-radius:8px;padding:5px 9px;font:inherit;font-size:12.5px}
.blk{display:flex;align-items:center;gap:6px;border-bottom:1px solid #eee;padding:6px 0}.blkt{flex:1;font-size:13.5px}.blkb{display:flex}.blkb button{border:0;background:var(--p2,#006a4e);color:#fff;border-radius:8px;width:32px;height:30px;margin-left:3px}
.sht{border-collapse:collapse;width:100%;min-width:300px}.sht td,.sht th{border:1px solid #cbd5e1;padding:0}.sht th{background:#e7f3ee}.sht input{width:100%;border:0;background:transparent;padding:8px 6px;font:inherit;font-size:13.5px;min-width:70px}.shs td{background:#f1f5f9;font-weight:800;padding:6px;font-size:13px}
.tl{background:var(--cd,#fff);border-radius:14px;margin:9px 0;box-shadow:0 2px 8px rgba(0,0,0,.06)}.tl summary{padding:13px 14px;font-weight:700;font-size:15.5px;cursor:pointer;list-style:none}.tl summary span{font-size:22px;margin-right:6px}.tlb{padding:0 14px 14px}
.tlr{margin-top:8px;font-size:15px;line-height:1.6}.cld{background:#111827;color:#fff;border-radius:12px;padding:12px 14px;font-size:28px;text-align:right;min-height:30px;margin-bottom:8px;word-break:break-all}
.ckeys{display:grid;grid-template-columns:repeat(4,1fr);gap:7px}.ckeys button{border:0;background:#eef2f7;border-radius:12px;padding:13px 0;font:inherit;font-size:19px;font-weight:700}.ckeys .eq{grid-column:span 4;background:var(--p2,#006a4e);color:#fff}
body.dark .nboard,body.dark .tl{background:#1f2937}
`; document.head.appendChild(st); })();
