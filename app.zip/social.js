// কমিউনিটি, চাকরিপ্রার্থী আইডি, নোটিশ বোর্ড ও অ্যাডমিন প্যানেল।
// সবই Firebase (Firestore) এ চলে, তাই firebase-config.js ভরা না থাকলে এগুলো দেখা যায় না।
// নিরাপত্তা আসে Firestore Rules থেকে (SETUP.md)। অ্যাডমিন বাটন দেখা গেলেও অধিকার ছাড়া কিছু লেখা যায় না।
if (typeof CLOUD_ON === 'function' && CLOUD_ON()) {
  [['board', 'নোটিশ বোর্ড', '📢', '#b45309', 'নোটিশ, ভিডিও, অডিও, লেখা'],
   ['community', 'কমিউনিটি', '💬', '#0369a1', 'প্রশ্ন, আলোচনা, মন্তব্য'],
   ['seeker', 'চাকরিপ্রার্থী আইডি', '🪪', '#6d28d9', 'নিজের আইডি বানান']].forEach(a => {
    if (!CATS.some(c => c.id === a[0])) CATS.push({id: a[0], name: a[1], ic: a[2], color: a[3], sub: a[4]});
  });
}

if (!CATS.some(c => c.id === 'contact')) CATS.push({id: 'contact', name: 'যোগাযোগ', ic: '📞', color: '#0f766e', sub: 'ডেভেলপার ও অ্যাডমিন'});

// ---------- সাধারণ সহায়ক ----------
let _acache = {content: [], posts: [], reports: [], seekers: [], admins: []};
const sdate = ts => { try { const d = ts && ts.toDate ? ts.toDate() : new Date(ts); return isNaN(d) ? '' : d.toLocaleDateString('bn-BD'); } catch (e) { return ''; } };
const sbody = h => { const e = document.getElementById('sbody'); if (e) e.innerHTML = h; };
const initial = n => (Array.from(String(n || 'ব'))[0] || 'ব');
async function sme() {
  if (!CLOUD_ON() || !cloudInfo()) return null;
  const f = await fb(); const u = f.auth.currentUser; return u ? {f, u} : null;
}
const sEmpty = (ic, t) => `<div class="empty"><span class="e1">${ic}</span>${esc(t)}</div>`;
function sNeedSetup() { return `<div class="warn">এই অংশ চালু করতে অ্যাপের নির্মাতাকে Firebase সেটআপ করতে হবে।</div>`; }
function sNeedLogin() { return `<div class="cx"><b>🔒 লগইন দরকার</b><div class="hint">এই অংশ ব্যবহারে আগে লগইন করতে হবে। লগইন করলে আপনার সব তথ্য ফোন বদলালেও ফেরত পাবেন।</div><button class="btn" onclick="open_('account')">👤 লগইন / নতুন অ্যাকাউন্ট</button></div>`; }
function sShell(title, tabKey, ic, sub) { tab = tabKey || 'home'; render(pageHead(title) + (ic ? hero(ic, title, sub) : '') + '<div class="pad" id="sbody"><div class="empty"><span class="e1">⏳</span>লোড হচ্ছে...</div></div>'); }
function sErr(e) { return `<div class="warn">⚠️ ${esc((e && e.code === 'permission-denied') ? 'অনুমতি নেই। লগইন করে আবার চেষ্টা করুন।' : 'লোড করা যায়নি। ইন্টারনেট সংযোগ দেখুন।')}</div>`; }
async function sList(f, path, ...cons) {
  const q = f.F.query(f.F.collection(f.db, ...path), ...cons);
  const s = await f.F.getDocs(q); const r = []; s.forEach(d => r.push(Object.assign({id: d.id}, d.data()))); return r;
}

// ---------- ইউজার প্রোফাইল (অ্যাডমিন যোগ করার সময় খোঁজার জন্য) ও লগআউটে ক্লিনআপ ----------
async function upsertProfile() {
  const m = await sme(); if (!m) return; const ci = cloudInfo() || {};
  await m.f.F.setDoc(m.f.F.doc(m.f.db, 'profiles', m.u.uid), {name: ci.name || '', idKey: loginEmail(ci.id || ''), at: Date.now()});
}
(function () {
  const L = cloudLogin, S = cloudSignup, O = cloudLogout;
  cloudLogin = async (...a) => { const r = await L(...a); upsertProfile().catch(() => {}); adminProbe(); return r; };
  cloudSignup = async (...a) => { const r = await S(...a); upsertProfile().catch(() => {}); return r; };
  cloudLogout = async (...a) => { const r = await O(...a); try { localStorage.removeItem('isAdmin'); } catch (e) {} return r; };
})();

// ---------- অ্যাডমিন চেনা ----------
async function adminRole() {
  const m = await sme(); if (!m) return null;
  const d = await m.f.F.getDoc(m.f.F.doc(m.f.db, 'admins', m.u.uid));
  if (d.exists()) return (d.data() || {}).role || 'admin';
  // Rules এ নাম থাকা মালিকদের জন্য: শুধু অ্যাডমিন এই ডকুমেন্ট পড়তে পারে
  try { await m.f.F.getDoc(m.f.F.doc(m.f.db, 'meta', 'adm')); return 'owner'; } catch (e) { if (e && e.code === 'permission-denied') return null; throw e; }
}
async function adminProbe() {
  try { const r = await adminRole(); try { r ? localStorage.setItem('isAdmin', r) : localStorage.removeItem('isAdmin'); } catch (e) {} } catch (e) {}
}
const isAdminFlag = () => { try { return !!localStorage.getItem('isAdmin'); } catch (e) { return false; } };

// ---------- অ্যাডমিনের প্রকাশ করা কনটেন্ট (লগইন ছাড়াই সবাই দেখে, অফলাইনে শেষ কপি থাকে) ----------
let ADMIN_CONTENT = []; try { ADMIN_CONTENT = JSON.parse(localStorage.getItem('adminContent') || '[]'); } catch (e) {}
const TYPE_LBL = {notice: '📢 নোটিশ', section: '🧩 নতুন সেকশন', tip: '💡 টিপস', article: '📝 লেখা', video: '🎬 ভিডিও', audio: '🎧 অডিও', image: '🖼️ ছবি', job: '💼 চাকরি', quiz: '❓ কুইজ প্রশ্ন', contact: '📞 যোগাযোগ', node: '🧱 পাতা / অধ্যায়', ad: '📣 বিজ্ঞাপন', ticker: '📰 খবর'};
const TYPE_SEL = Object.keys(TYPE_LBL).filter(k => !['contact', 'config', 'ad', 'ticker'].includes(k));
const TYPE_BG = {notice: '#fef3c7', section: '#dbeafe', tip: '#fef9c3', article: '#dcfce7', video: '#fee2e2', audio: '#ede9fe', image: '#fce7f3', job: '#e0f2fe', quiz: '#ffedd5'};
const TILE_COL = ['#0369a1', '#b45309', '#6d28d9', '#15803d', '#be123c', '#0f766e'];
const mapRow = r => ({id: r.id, type: r.type, title: r.title, body: r.body, url: r.url, sub: r.sub, ic: r.ic, mt: r.mt, pin: !!r.pin, pub: r.pub !== false, at: r.createdAt && r.createdAt.toMillis ? r.createdAt.toMillis() : (+r.createdAt || 0), job: r.job || null, contact: r.contact || null, cfg: r.cfg || null, quiz: r.quiz || null, img: r.img || '', parent: r.parent || '', titleEn: r.titleEn || '', bodyEn: r.bodyEn || '', lang: r.lang || 'auto', color: r.color || '', ord: +r.ord || 0, slot: r.slot || '', label: r.label || ''});

let _tipBase = null;
function applyTips() {
  if (typeof TIPS === 'undefined') return;
  if (!_tipBase) _tipBase = TIPS.slice();
  const extra = ADMIN_CONTENT.filter(c => c.type === 'tip' && c.body).map(c => c.body);
  TIPS.length = 0; _tipBase.concat(extra).forEach(t => TIPS.push(t));
}
applyTips();

let _quizBase = null;
function applyQuiz() {
  if (typeof QUIZ === 'undefined') return;
  if (!_quizBase) _quizBase = QUIZ.slice();
  const extra = ADMIN_CONTENT.filter(c => c.type === 'quiz' && c.quiz && Array.isArray(c.quiz.o) && c.title).map(c => { const right = c.quiz.o[+c.quiz.a || 0], o = c.quiz.o.filter(Boolean); return [c.title, o, Math.max(0, o.indexOf(right)), c.quiz.e || '']; }).filter(q => q[1].length >= 2);
  QUIZ.length = 0; _quizBase.concat(extra).forEach(q => QUIZ.push(q));
}
applyQuiz();

async function refreshContent() {
  if (!CLOUD_ON() || !navigator.onLine) return;
  try {
    const f = await fb();
    const rows = await sList(f, ['content'], f.F.orderBy('createdAt', 'desc'), f.F.limit(500));
    const next = rows.map(mapRow).filter(r => r.pub);
    const changed = JSON.stringify(next) !== JSON.stringify(ADMIN_CONTENT);
    ADMIN_CONTENT = next; applyTips(); applyQuiz(); applyTheme(); renderBars();
    try { localStorage.setItem('adminContent', JSON.stringify(ADMIN_CONTENT)); } catch (e) {
      try { localStorage.setItem('adminContent', JSON.stringify(ADMIN_CONTENT.map(c => Object.assign({}, c, {img: ['config', 'ad'].includes(c.type) ? c.img : ''})))); } catch (e2) {}
    }
    // হোমে থাকলে ও কিছু বদলালে নতুন আইকন/নোটিশ দেখাতে হোম আবার আঁকা
    const q = document.getElementById('q');
    if (changed && tab === 'home' && !stack.length && q && !q.value && !document.getElementById('modal')) home();
  } catch (e) {}
}
setTimeout(() => { if (CLOUD_ON()) { if (cloudInfo()) adminProbe(); refreshContent(); } }, 2500);

// চাকরির তালিকায় মেশানোর জন্য (app.js এর activeJobs ডাকে)
function adminJobs() {
  return ADMIN_CONTENT.filter(c => c.type === 'job' && c.job).map(c => Object.assign({kind: 'local', t: c.title, d: c.body || ''}, c.job));
}
// হোমের নতুন আইকন (অ্যাডমিনের বানানো সেকশন)
function adminTiles() {
  return ADMIN_CONTENT.filter(c => c.type === 'section' && c.title).map((c, i) => ({id: 'sec_' + c.id, name: c.title, ic: c.ic || '📌', color: TILE_COL[i % TILE_COL.length], sub: c.sub || ''}));
}
// হোমে পিন করা নোটিশ
function homeNotice() {
  const n = ADMIN_CONTENT.find(c => c.type === 'notice' && c.pin); if (!n) return '';
  let d = []; try { d = JSON.parse(localStorage.getItem('noticeX') || '[]'); } catch (e) {}
  if (d.includes(n.id)) return '';
  return `<div class="pin" onclick="boardItem('${esc(n.id)}')"><button class="x" onclick="event.stopPropagation();noticeX('${esc(n.id)}')">✕</button><b>📢 ${esc(n.title || '')}</b>${esc((n.body || '').slice(0, 110))}</div>`;
}
function noticeX(id) { let d = []; try { d = JSON.parse(localStorage.getItem('noticeX') || '[]'); } catch (e) {} d.push(id); try { localStorage.setItem('noticeX', JSON.stringify(d.slice(-30))); } catch (e) {} home(); }

function mediaHtml(c) {
  const pic = okImg(c.img) ? `<img loading="lazy" src="${c.img}" style="max-width:100%;border-radius:14px;display:block;margin-bottom:8px">` : '';
  const u = safeUrl(c.url); if (!u) return pic;
  const t = c.mt && c.mt !== 'none' ? c.mt : c.type;
  const yt = u.match(/(?:youtu\.be\/|[?&]v=|embed\/|shorts\/)([\w-]{11})/);
  if (yt && t !== 'audio' && t !== 'image') return pic + `<iframe style="width:100%;aspect-ratio:16/9;border:0;border-radius:14px" src="https://www.youtube.com/embed/${yt[1]}" allowfullscreen></iframe>`;
  if (t === 'video') return pic + `<video controls playsinline preload="none" src="${esc(u)}" style="width:100%;border-radius:14px"></video>`;
  if (t === 'audio') return pic + `<audio controls preload="none" src="${esc(u)}" style="width:100%"></audio>`;
  if (t === 'image') return pic + `<img loading="lazy" src="${esc(u)}" style="max-width:100%;border-radius:14px">`;
  return pic;
}
const isPdfUrl = u => /\.pdf($|[?#])|drive\.google\.com\/file|docs\.google\.com\/(document|presentation)/i.test(u || '');
const isYtUrl = u => /(?:youtu\.be\/|youtube\.com\/)/i.test(u || '');
const linkBtn = u => safeUrl(u) ? `<a class="btn" style="display:block;text-align:center;text-decoration:none;margin-top:12px" href="${esc(safeUrl(u))}" target="_blank" rel="noopener" onclick="goUrl(this.getAttribute('href'));return false">${isPdfUrl(u) ? '📄 PDF খুলুন' : isYtUrl(u) ? '▶️ YouTube এ দেখুন' : '🔗 খুলুন'}</a>` : '';
const speakBtn = t => `<button class="btn sm" style="margin-top:10px" onclick="speak(${JSON.stringify(String(t || '')).replace(/"/g, '&quot;')})">🔊 শুনুন</button>`;

function boardPage(flt = '') {
  tab = 'home';
  const list = ADMIN_CONTENT.filter(c => ['notice', 'article', 'video', 'audio', 'image'].includes(c.type) && (!flt || c.type === flt));
  const chips = `<div class="seg">${['', 'notice', 'article', 'video', 'audio', 'image'].map(t => `<button class="${flt === t ? 'on' : ''}" onclick="boardPage('${t}')">${t ? TYPE_LBL[t] : 'সব'}</button>`).join('')}</div>`;
  render(pageHead('নোটিশ বোর্ড') + hero('📢', 'নোটিশ বোর্ড', 'নতুন নিয়ম, ভিডিও, অডিও ও দরকারি লেখা') + '<div class="pad">' + chips +
    (list.length ? list.map(c => `<div class="bi" onclick="boardItem('${esc(c.id)}')"><div class="bic" style="background:${TYPE_BG[c.type] || '#eee'}">${(TYPE_LBL[c.type] || '').split(' ')[0]}</div><div><b>${esc(c.title || '')}</b><small>${(TYPE_LBL[c.type] || '').split(' ').slice(1).join(' ')} • ${sdate(c.at)}</small></div></div>`).join('') : sEmpty('📭', 'এখনো কিছু নেই। ইন্টারনেট থাকলে নতুন কনটেন্ট নিজে থেকে আসবে।')) +
    `<button class="btn sm" style="background:#475569" onclick="refreshContent().then(()=>boardPage('${flt}'))">🔄 নতুন আছে কি দেখুন</button></div>`);
  if (CLOUD_ON() && !ADMIN_CONTENT.length) refreshContent().then(() => { if (ADMIN_CONTENT.length) boardPage(flt); });
}
function boardItem(id) {
  const c = ADMIN_CONTENT.find(x => x.id === id); if (!c) return;
  showModal(`<span class="tag" style="background:#b45309">${TYPE_LBL[c.type] || ''}</span><h3 style="margin:8px 0">${esc(c.title || '')}</h3>${mediaHtml(c)}<div class="rich" style="margin-top:8px">${rich(c.body)}</div>${linkBtn(c.url)}${speakBtn(c.body || c.title)}`);
}
function sectionPage(id) {
  const c = ADMIN_CONTENT.find(x => x.id === id); tab = 'home';
  if (!c) return render(pageHead('পাতা') + '<div class="pad">' + sEmpty('🔍', 'এই পাতাটি আর নেই।') + '</div>');
  render(pageHead(c.title || '') + hero(c.ic || '📌', c.title || '', c.sub || '') + `<div class="pad"><div class="cx">${mediaHtml(c)}<div class="rich" style="margin-top:${mediaHtml(c) ? 10 : 0}px">${rich(c.body)}</div>${linkBtn(c.url)}${speakBtn(c.body || c.title)}</div></div>`);
  injectKids('sec_' + id);
}

// ---------- কমিউনিটি ----------
let _lastPost = 0;
async function communityPage() {
  sShell('কমিউনিটি', 'home', '💬', 'প্রশ্ন করুন, অভিজ্ঞতা শেয়ার করুন, একে অপরকে সাহায্য করুন');
  if (!CLOUD_ON()) return sbody(sNeedSetup());
  const m = await sme(); if (!m) return sbody(sNeedLogin());
  try {
    const rows = await sList(m.f, ['posts'], m.f.F.orderBy('createdAt', 'desc'), m.f.F.limit(40)); _acache.posts = rows;
    const adm = isAdminFlag();
    sbody(`<div class="cx"><b>✍️ নতুন পোস্ট</b>
      <textarea class="inp" id="ptext" rows="3" maxlength="500" placeholder="প্রশ্ন বা অভিজ্ঞতা লিখুন (সর্বোচ্চ ৫০০ অক্ষর)"></textarea>
      <button class="btn sm" onclick="postNew()">পোস্ট করুন</button>
      <div class="hint" style="margin-top:8px">নিয়ম: গালি, বিজ্ঞাপন, প্রতারণা, ধর্ম বা রাজনীতি নিয়ে উস্কানি ও অন্যের ব্যক্তিগত তথ্য দেওয়া নিষেধ। নিয়ম ভাঙলে পোস্ট মুছে অ্যাকাউন্ট বন্ধ করা হতে পারে।</div></div>` +
      (rows.length ? rows.map((p, i) => `<div class="post"><div class="ph"><div class="av">${esc(initial(p.name))}</div><div><div class="pn">${esc(p.name || 'ব্যবহারকারী')}</div><div class="pd">${sdate(p.createdAt)}</div></div></div>
        <div class="pt">${esc(p.text || '')}</div>
        <div class="pa"><button onclick="openThread(${i})">💬 মন্তব্য</button><button onclick="reportPost(${i})">🚩 রিপোর্ট</button>${(p.uid === m.u.uid || adm) ? `<button class="del" onclick="delPost(${i})">🗑️ মুছুন</button>` : ''}</div></div>`).join('') : sEmpty('💭', 'এখনো কোনো পোস্ট নেই। প্রথম পোস্টটি আপনিই করুন।')));
  } catch (e) { sbody(sErr(e)); }
}
async function postNew() {
  const t = (document.getElementById('ptext').value || '').trim(); if (!t) return;
  if (Date.now() - _lastPost < 30000) return alert('একটু অপেক্ষা করে আবার পোস্ট করুন।');
  const m = await sme(); if (!m) return;
  try { await m.f.F.addDoc(m.f.F.collection(m.f.db, 'posts'), {uid: m.u.uid, name: (cloudInfo() || {}).name || 'ব্যবহারকারী', text: t.slice(0, 500), createdAt: m.f.F.serverTimestamp()}); _lastPost = Date.now(); communityPage(); }
  catch (e) { alert('পোস্ট করা যায়নি। ' + (e.code === 'permission-denied' ? 'আপনার অ্যাকাউন্টে পোস্টের অনুমতি নেই।' : 'ইন্টারনেট দেখুন।')); }
}
async function delPost(i) {
  const p = _acache.posts[i]; if (!p || !confirm('পোস্টটি মুছবেন?')) return;
  const m = await sme(); try { await m.f.F.deleteDoc(m.f.F.doc(m.f.db, 'posts', p.id)); communityPage(); } catch (e) { alert('মোছা যায়নি।'); }
}
async function reportPost(i) {
  const p = _acache.posts[i]; if (!p) return; const why = prompt('রিপোর্টের কারণ লিখুন (যেমন: গালি, বিজ্ঞাপন, প্রতারণা)'); if (why === null) return;
  const m = await sme();
  try { await m.f.F.addDoc(m.f.F.collection(m.f.db, 'reports'), {postId: p.id, postText: String(p.text || '').slice(0, 300), postUid: p.uid, why: String(why).slice(0, 200), by: m.u.uid, createdAt: m.f.F.serverTimestamp()}); alert('রিপোর্ট জমা হয়েছে। ধন্যবাদ।'); }
  catch (e) { alert('রিপোর্ট পাঠানো যায়নি।'); }
}
async function openThread(i) {
  const p = _acache.posts[i]; if (!p) return; window._thr = p.id;
  showModal(`<div class="ph" style="display:flex;gap:10px;align-items:center"><div class="av">${esc(initial(p.name))}</div><b>${esc(p.name || '')}</b></div><div style="white-space:pre-line;margin:8px 0;line-height:1.6">${esc(p.text || '')}</div><hr><div id="thr"><div class="empty">⏳</div></div>
    <input class="inp" id="ctext" maxlength="300" placeholder="আপনার মন্তব্য লিখুন"><button class="btn sm" onclick="addComment()">পাঠান</button>`);
  loadThread();
}
async function loadThread() {
  const m = await sme(); const el = document.getElementById('thr'); if (!m || !el) return;
  try {
    const rows = await sList(m.f, ['posts', window._thr, 'comments'], m.f.F.orderBy('createdAt', 'asc'), m.f.F.limit(100)); window._cm = rows; const adm = isAdminFlag();
    el.innerHTML = rows.length ? rows.map((c, j) => `<div style="margin:8px 0;font-size:14px;background:#f3f5f1;border-radius:12px;padding:8px 10px"><b>${esc(c.name || '')}</b> <span style="font-size:11px;color:#777">${sdate(c.createdAt)}</span>${(c.uid === m.u.uid || adm) ? ` <a href="#" style="color:#dc2626;font-size:12px" onclick="delComment(${j});return false">মুছুন</a>` : ''}<div style="white-space:pre-line">${esc(c.text || '')}</div></div>`).join('') : '<div style="color:#777;font-size:13px">এখনো কোনো মন্তব্য নেই।</div>';
  } catch (e) { el.innerHTML = sErr(e); }
}
async function addComment() {
  const t = (document.getElementById('ctext').value || '').trim(); if (!t) return; const m = await sme(); if (!m) return;
  try { await m.f.F.addDoc(m.f.F.collection(m.f.db, 'posts', window._thr, 'comments'), {uid: m.u.uid, name: (cloudInfo() || {}).name || 'ব্যবহারকারী', text: t.slice(0, 300), createdAt: m.f.F.serverTimestamp()}); document.getElementById('ctext').value = ''; loadThread(); }
  catch (e) { alert('মন্তব্য পাঠানো যায়নি।'); }
}
async function delComment(j) {
  const c = (window._cm || [])[j]; if (!c) return; const m = await sme();
  try { await m.f.F.deleteDoc(m.f.F.doc(m.f.db, 'posts', window._thr, 'comments', c.id)); loadThread(); } catch (e) { alert('মোছা যায়নি।'); }
}

// ---------- চাকরিপ্রার্থী (বেকার) আইডি ----------
const seekerId = uid => 'CB-' + String(uid).slice(0, 6).toUpperCase();
const LIC_OPTS = ['লার্নার / এখনো লাইসেন্স নেই', 'মোটরসাইকেল', 'হালকা (Light)', 'মধ্যম (Medium)', 'ভারী (Heavy)', 'ভারী + পিএসভি'];
async function seekerPage(dist = '') {
  sShell('চাকরিপ্রার্থী আইডি', 'home', '🪪', 'আপনার পরিচয় তৈরি করুন, চাকরিদাতারা আপনাকে খুঁজে পাবেন');
  if (!CLOUD_ON()) return sbody(sNeedSetup());
  const m = await sme(); if (!m) return sbody(sNeedLogin());
  try {
    const mine = await m.f.F.getDoc(m.f.F.doc(m.f.db, 'seekers', m.u.uid));
    const rows = await sList(m.f, ['seekers'], m.f.F.orderBy('createdAt', 'desc'), m.f.F.limit(60)); _acache.seekers = rows;
    const me_ = mine.exists() ? mine.data() : null; const adm = isAdminFlag();
    const shown = rows.filter(r => !dist || String(r.district || '').includes(dist));
    sbody(`<div class="cx"><b>${me_ ? '✅ আপনার আইডি: <span class="sid">' + seekerId(m.u.uid) + '</span>' : '🪪 নিজের চাকরিপ্রার্থী আইডি বানান'}</b>
      <div class="hint">চাকরিদাতা বা মালিকরা এখানে দেখে ড্রাইভার খুঁজতে পারেন। শুধু লগইন করা ব্যবহারকারীরা দেখতে পারে।</div>
      <input class="inp" id="sk_n" placeholder="নাম" value="${esc((me_ && me_.name) || (cloudInfo() || {}).name || '')}">
      <input class="inp" id="sk_d" placeholder="জেলা / এলাকা" value="${esc((me_ && me_.district) || '')}">
      <select class="inp" id="sk_l">${LIC_OPTS.map(o => `<option ${me_ && me_.lic === o ? 'selected' : ''}>${o}</option>`).join('')}</select>
      <input class="inp" id="sk_e" type="number" min="0" max="50" placeholder="অভিজ্ঞতা (বছর)" value="${me_ ? esc(me_.exp || '') : ''}">
      <textarea class="inp" id="sk_a" rows="2" maxlength="200" placeholder="নিজের সম্পর্কে সংক্ষেপে">${esc((me_ && me_.about) || '')}</textarea>
      <input class="inp" id="sk_p" placeholder="ফোন নম্বর (ঐচ্ছিক)" value="${esc((me_ && me_.phone) || '')}">
      <label style="display:block;font-size:14px;margin:6px 0"><input type="checkbox" id="sk_s" ${me_ && me_.showPhone ? 'checked' : ''}>ফোন নম্বর অন্যদের দেখান</label>
      <label style="display:block;font-size:14px;margin:6px 0;line-height:1.5"><input type="checkbox" id="sk_c" ${me_ ? 'checked' : ''}>আমি সম্মতি দিচ্ছি, আমার এই তথ্য লগইন করা অন্য ব্যবহারকারীরা দেখতে পারবে।</label>
      <button class="btn sm" onclick="seekerSave()">💾 সেভ করুন</button>${me_ ? '<button class="btn sm" style="background:#dc2626" onclick="seekerDel()">আইডি মুছুন</button>' : ''}</div>
      <div class="sec-h" style="margin:18px 2px 6px">চাকরিপ্রার্থীদের তালিকা</div>
      <input class="inp" id="sk_f" placeholder="🔍 জেলা দিয়ে খুঁজুন" value="${esc(dist)}" onchange="seekerPage(this.value)">` +
      (shown.length ? shown.map((r, i) => `<div class="cx sk"><div class="top"><span class="sid">${esc(seekerId(r.uid))}</span><b style="display:inline">${esc(r.name || '')}</b></div>
        <span class="pill">📍 ${esc(r.district || '—')}</span><span class="pill">📜 ${esc(r.lic || '—')}</span><span class="pill">⏱️ ${esc(r.exp || 0)} বছর</span>
        ${r.about ? `<div class="hint" style="margin-top:8px">${esc(r.about)}</div>` : ''}${r.showPhone && r.phone ? `<div><a class="btn sm" style="text-decoration:none;display:inline-block;margin-top:8px" href="tel:${esc(String(r.phone).replace(/[^\d+]/g, ''))}">📞 ${esc(r.phone)}</a></div>` : ''}
        ${adm ? `<button class="btn sm" style="background:#dc2626" onclick="seekerAdminDel(${i})">🗑️ মুছুন</button>` : ''}</div>`).join('') : sEmpty('🧑‍✈️', 'কেউ নেই।')));
  } catch (e) { sbody(sErr(e)); }
}
async function seekerSave() {
  const v = id => (document.getElementById(id).value || '').trim();
  if (!document.getElementById('sk_c').checked) return alert('সম্মতির ঘরে টিক দিন।');
  if (!v('sk_n') || !v('sk_d')) return alert('নাম ও জেলা দিন।');
  const m = await sme(); if (!m) return;
  try {
    await m.f.F.setDoc(m.f.F.doc(m.f.db, 'seekers', m.u.uid), {uid: m.u.uid, name: v('sk_n').slice(0, 60), district: v('sk_d').slice(0, 60), lic: v('sk_l'), exp: Math.max(0, Math.min(50, +v('sk_e') || 0)), about: v('sk_a').slice(0, 200), phone: v('sk_p').slice(0, 20), showPhone: document.getElementById('sk_s').checked, createdAt: m.f.F.serverTimestamp()});
    seekerPage();
  } catch (e) { alert('সেভ করা যায়নি।'); }
}
async function seekerDel() { if (!confirm('আপনার আইডি মুছে ফেলবেন?')) return; const m = await sme(); try { await m.f.F.deleteDoc(m.f.F.doc(m.f.db, 'seekers', m.u.uid)); seekerPage(); } catch (e) { alert('মোছা যায়নি।'); } }
async function seekerAdminDel(i) { const r = _acache.seekers[i]; if (!r || !confirm('মুছবেন?')) return; const m = await sme(); try { await m.f.F.deleteDoc(m.f.F.doc(m.f.db, 'seekers', r.uid)); seekerPage(); } catch (e) { alert('মোছা যায়নি।'); } }

// ---------- অ্যাডমিন প্যানেল ----------
let _picked = '', _logoPicked = null, _presetType = '', _presetParent = '';
const gv = id => { const e = document.getElementById(id); return e ? (e.value || '').trim() : ''; };
const chk = id => { const e = document.getElementById(id); return !!(e && e.checked); };
// কোন ধরনে কোন ঘর দেখাবে
const AD_VIS = {
  notice: ['title', 'body', 'url', 'img', 'pin'], section: ['title', 'sub', 'ic', 'body', 'img', 'url', 'mt'], tip: ['body'], article: ['title', 'body', 'url', 'img'],
  video: ['title', 'body', 'url', 'img'], audio: ['title', 'body', 'url', 'img'], image: ['title', 'body', 'url', 'img'], job: ['title', 'body', 'job'], quiz: ['title', 'quiz'],
  node: ['parent', 'title', 'titleEn', 'ic', 'color', 'body', 'bodyEn', 'lang', 'img', 'url', 'mt', 'ord']
};
const AD_HELP = {
  notice: 'সবাই নোটিশ বোর্ডে দেখবে। "হোমে পিন" দিলে অ্যাপ খুললেই হোমে ভেসে থাকবে।',
  section: 'হোম পাতায় একটি নতুন আইকন যোগ হবে। চাপলে আপনার লেখা, ভিডিও, অডিও বা ছবি খুলবে।',
  tip: '"আজকের টিপস" এর তালিকায় যোগ হবে। শুধু টিপসের লেখাটি দিন।',
  node: 'যেকোনো আইকন বা পাতার ভিতরে নতুন অধ্যায় বা উপ-অধ্যায়। "কোথায় বসবে" ঘরে বেছে নিন। বাংলা ও ইংরেজি দুটোই লিখতে পারেন।',
  quiz: 'মডেল টেস্ট ও আজকের প্রশ্নে যোগ হবে। প্রশ্ন, চারটি উত্তর ও সঠিক উত্তরটি বেছে দিন।', article: 'নোটিশ বোর্ডে লেখা হিসেবে দেখাবে। বড় লেখা দিতে পারবেন।', video: 'YouTube লিংক বা সরাসরি ভিডিও ফাইলের লিংক দিন।',
  audio: 'অডিও ফাইলের (mp3 ইত্যাদি) লিংক দিন।', image: 'ছবির লিংক দিন।', job: 'অ্যাপের চাকরির তালিকায় মিশে যাবে, মেয়াদ শেষে নিজে সরে যাবে।'
};
function adToggle() {
  const t = gv('ad_t'), vis = AD_VIS[t] || [];
  ['parent', 'titleEn', 'bodyEn', 'lang', 'color', 'ord', 'title', 'sub', 'ic', 'body', 'url', 'img', 'mt', 'pin', 'job', 'quiz'].forEach(k => { const e = document.getElementById('adg_' + k); if (e) e.style.display = vis.includes(k) ? 'block' : 'none'; });
  const h = document.getElementById('ad_help'); if (h) h.textContent = AD_HELP[t] || '';
}
async function adminPage(sec = 'pub', editId = '') {
  sShell('অ্যাডমিন প্যানেল', 'profile', '🛡️', 'অ্যাপের সব কনটেন্ট এখান থেকে বদলান');
  if (!CLOUD_ON()) return sbody(sNeedSetup());
  const m = await sme(); if (!m) return sbody(adminLoginView());
  let role = null; try { role = await adminRole(); } catch (e) { return sbody(sErr(e)); }
  try { role ? localStorage.setItem('isAdmin', role) : localStorage.removeItem('isAdmin'); } catch (e) {}
  if (!role) return sbody(`<div class="cx"><b>আপনি এখনো অ্যাডমিন নন</b><div class="hint">লগইন করা আইডি: <b>${esc((m.u && m.u.email) || '')}</b><br>এটি অ্যাডমিন তালিকার নম্বর বা Gmail না হলে অন্য আইডিতে লগইন করুন। তালিকার আইডি হলে Firebase এ Rules "Publish" হয়েছে কিনা দেখুন।</div><div class="hint">আপনার UID (চেপে ধরে কপি করুন):</div><div style="word-break:break-all;user-select:all;font-family:monospace;background:#f3f5f1;border-radius:10px;padding:8px">${esc(m.u.uid)}</div></div>
    <div class="cx"><b>আপনি অ্যাপের মালিক হলে (একবারের কাজ)</b><ol style="padding-left:20px;font-size:14px;line-height:1.7;margin:6px 0">
    <li>Firebase Console এ Firestore Database → Data খুলুন।</li><li><b>Start collection</b> চাপুন, Collection ID লিখুন: <b>admins</b></li>
    <li>Document ID তে উপরের UID বসান।</li><li>ফিল্ড নাম <b>role</b>, ধরন string, মান <b>owner</b> দিয়ে Save করুন।</li>
    <li>অ্যাপে ফিরে এই পাতা আবার খুলুন।</li></ol></div>
    <button class="btn" onclick="adminPage()">🔄 আবার দেখুন</button>
    <div class="warn">অন্য কেউ অ্যাডমিন হতে চাইলে তার UID মালিককে পাঠাবেন, অথবা মালিক "অ্যাডমিন" ট্যাব থেকে তার মোবাইল নম্বর দিয়ে যোগ করবেন।</div>`);
  const tabs = [['pub', '✍️ নতুন'], ['list', '📚 সব কনটেন্ট'], ['set', '🎨 রং ও পরিচয়'], ['lay', '🧩 সাজানো'], ['qg', '🤖 প্রশ্ন বানান'], ['ads', '📣 বিজ্ঞাপন ও খবর'], ['contact', '📞 যোগাযোগ'], ['rep', '🚩 রিপোর্ট'], ['adm', '👥 অ্যাডমিন']];
  const bar = `<div class="seg">${tabs.map(t => `<button class="${sec === t[0] ? 'on' : ''}" onclick="adminPage('${t[0]}')">${t[1]}</button>`).join('')}</div>`;
  try {
    let h = '';
    if (sec === 'pub') {
      _picked = '';
      let e = null;
      if (editId) { const all = await sList(m.f, ['content'], m.f.F.orderBy('createdAt', 'desc'), m.f.F.limit(200)); _acache.content = all.map(mapRow); e = _acache.content.find(x => x.id === editId) || null; }
      const j = (e && e.job) || {}; const ty = (e && e.type) || _presetType || 'notice'; const pre = (e && e.parent) || _presetParent || ''; _presetType = ''; _presetParent = '';
      h = `<div class="cx"><b>${e ? '✏️ সম্পাদনা' : '✍️ নতুন কনটেন্ট'}</b>
        <select class="inp" id="ad_t" onchange="adToggle()" ${e ? 'disabled' : ''}>${TYPE_SEL.map(k => `<option value="${k}" ${ty === k ? 'selected' : ''}>${TYPE_LBL[k]}</option>`).join('')}</select>
        <div class="hint" id="ad_help"></div>
        <div id="adg_parent"><div class="hint" style="margin:0 0 4px">কোথায় বসবে (কোন আইকন বা পাতার ভিতরে)</div><select class="inp" id="ad_parent">${parentOpts(pre, e && e.id)}</select></div>
        <div id="adg_title"><input class="inp" id="ad_title" placeholder="শিরোনাম" value="${esc((e && e.title) || '')}"></div>
        <div id="adg_titleEn"><input class="inp" id="ad_titleEn" placeholder="ইংরেজি শিরোনাম (ঐচ্ছিক)" value="${esc((e && e.titleEn) || '')}"></div>
        <div id="adg_sub"><input class="inp" id="ad_sub" placeholder="ছোট বর্ণনা (আইকনের নিচে বা পাতার উপরে দেখাবে)" value="${esc((e && e.sub) || '')}"></div>
        <div id="adg_ic"><input class="inp" id="ad_ic" maxlength="4" placeholder="আইকন (একটি ইমোজি, যেমন 🚕)" value="${esc((e && e.ic) || '')}"></div>
        <div id="adg_body"><textarea class="inp" id="ad_body" rows="10" placeholder="লেখা / বিবরণ (বড় লেখাও দিতে পারেন)">${esc((e && e.body) || '')}</textarea><div class="hint">সাজানোর নিয়ম: <b># বড় শিরোনাম</b> • <b>## মাঝারি শিরোনাম</b> • <b>- তালিকার লেখা</b> • <b>**মোটা লেখা**</b></div></div>
        <div id="adg_bodyEn"><textarea class="inp" id="ad_bodyEn" rows="6" placeholder="ইংরেজি লেখা (ঐচ্ছিক)">${esc((e && e.bodyEn) || '')}</textarea></div>
        <div id="adg_lang"><select class="inp" id="ad_lang">${[['auto', 'অ্যাপের ভাষা অনুযায়ী দেখাবে'], ['bn', 'শুধু বাংলা'], ['en', 'শুধু ইংরেজি'], ['both', 'বাংলা ও ইংরেজি দুটোই একসাথে']].map(x => `<option value="${x[0]}" ${((e && e.lang) || 'auto') === x[0] ? 'selected' : ''}>${x[1]}</option>`).join('')}</select></div>
        <div id="adg_color"><div class="hint" style="margin:0 0 4px">পাতার রং</div><div class="rowline"><input type="color" id="ad_color" value="${esc((e && e.color) || '#0369a1')}" style="width:56px;height:40px;border:0;background:none;padding:0"><label><input type="checkbox" id="ad_nocolor" ${e && !e.color ? 'checked' : ''}>রং ছাড়া (সাধারণ)</label></div></div>
        <div id="adg_ord"><input class="inp" id="ad_ord" type="number" placeholder="ক্রম নম্বর (ছোট নম্বর আগে, যেমন ১, ২, ৩)" value="${e && e.ord ? e.ord : ''}"></div>
        <div id="adg_img"><div class="hint" style="margin:0 0 4px">ছবি (গ্যালারি থেকে বাছুন, নিজে ছোট হয়ে যাবে)</div>${e && okImg(e.img) ? `<img id="ad_imgprev" src="${e.img}" style="max-width:100%;border-radius:12px;margin-bottom:6px"><label style="display:block;margin:4px 0"><input type="checkbox" id="ad_imgdel">ছবিটি সরান</label>` : '<img id="ad_imgprev" style="display:none;max-width:100%;border-radius:12px;margin-bottom:6px">'}<input type="file" id="ad_img" accept="image/*" onchange="adPick(this)"></div>
        <div id="adg_quiz"><input class="inp" id="ad_q1" placeholder="উত্তর ১" value="${esc(((e && e.quiz && e.quiz.o) || [])[0] || '')}"><input class="inp" id="ad_q2" placeholder="উত্তর ২" value="${esc(((e && e.quiz && e.quiz.o) || [])[1] || '')}"><input class="inp" id="ad_q3" placeholder="উত্তর ৩" value="${esc(((e && e.quiz && e.quiz.o) || [])[2] || '')}"><input class="inp" id="ad_q4" placeholder="উত্তর ৪" value="${esc(((e && e.quiz && e.quiz.o) || [])[3] || '')}"><select class="inp" id="ad_qa">${[0, 1, 2, 3].map(i => `<option value="${i}" ${e && e.quiz && +e.quiz.a === i ? 'selected' : ''}>সঠিক উত্তর: ${i + 1} নম্বর</option>`).join('')}</select><input class="inp" id="ad_qe" placeholder="ব্যাখ্যা (ঐচ্ছিক, উত্তর দেওয়ার পর দেখাবে)" value="${esc((e && e.quiz && e.quiz.e) || '')}">
          ${e ? '' : `<div class="hint" style="margin-top:10px"><b>একসাথে অনেক প্রশ্ন দিতে</b> নিচের ঘরে প্রতি লাইনে একটি প্রশ্ন লিখুন (উপরের ঘরগুলো ফাঁকা রাখুন):<br>প্রশ্ন | উত্তর১ | উত্তর২ | উত্তর৩ | উত্তর৪ | সঠিক নম্বর | ব্যাখ্যা<br><span style="color:#6b7280">উদাহরণ: লাল বাতিতে কী করবেন? | থামবেন | যাবেন | হর্ন দেবেন | ধীরে যাবেন | ১ | লাল মানে থামা</span></div><textarea class="inp" id="ad_bulk" rows="6" placeholder="প্রশ্ন | উত্তর১ | উত্তর২ | উত্তর৩ | উত্তর৪ | সঠিক নম্বর | ব্যাখ্যা"></textarea>`}</div>
        <div id="adg_url"><input class="inp" id="ad_url" placeholder="লিংক (YouTube, ভিডিও, অডিও, ছবি বা ওয়েবসাইট)" value="${esc((e && e.url) || '')}"></div>
        <div id="adg_mt"><select class="inp" id="ad_mt"><option value="none">লিংকটি বাটন হিসেবে দেখান</option>${['video', 'audio', 'image', 'pdf'].map(k => `<option value="${k}" ${e && e.mt === k ? 'selected' : ''}>লিংকটি ${{video: 'ভিডিও', audio: 'অডিও', image: 'ছবি', pdf: 'PDF (বাটন)'}[k]} হিসেবে চালান</option>`).join('')}</select></div>
        <div id="adg_pin"><label style="display:block;margin:6px 0"><input type="checkbox" id="ad_pin" ${e && e.pin ? 'checked' : ''}>হোম পাতায় পিন করুন</label></div>
        <div id="adg_job"><input class="inp" id="ad_c" placeholder="কোম্পানি" value="${esc(j.c || '')}"><input class="inp" id="ad_s" placeholder="বেতন" value="${esc(j.s || '')}"><input class="inp" id="ad_lic" placeholder="লাইসেন্স" value="${esc(j.lic || '')}"><input class="inp" id="ad_loc" placeholder="লোকেশন" value="${esc(j.loc || '')}"><input class="inp" id="ad_dl" type="date" value="${esc(j.deadline || '')}"><input class="inp" id="ad_ph" placeholder="ফোন" value="${esc(j.phone || '')}"><select class="inp" id="ad_kind"><option value="local" ${j.kind !== 'foreign' ? 'selected' : ''}>দেশি চাকরি</option><option value="foreign" ${j.kind === 'foreign' ? 'selected' : ''}>বিদেশি চাকরি</option></select></div>
        <label style="display:block;margin:8px 0"><input type="checkbox" id="ad_pub" ${!e || e.pub ? 'checked' : ''}>প্রকাশিত (টিক না থাকলে অ্যাপে লুকানো থাকবে)</label>
        <div id="ad_msg" class="warn" style="display:none"></div>
        <button class="btn" onclick="adSave('${esc(editId)}')">${e ? '💾 আপডেট করুন' : '🚀 প্রকাশ করুন'}</button></div>`;
    } else if (sec === 'list') {
      const all = await sList(m.f, ['content'], m.f.F.orderBy('createdAt', 'desc'), m.f.F.limit(200)); _acache.content = all.map(mapRow);
      h = _acache.content.filter(c => !['contact', 'config', 'ad', 'ticker'].includes(c.type)).length ? _acache.content.map((c, i) => ['contact', 'config', 'ad', 'ticker'].includes(c.type) ? '' : `<div class="cx"><div class="rowline"><span class="tag" style="background:#b45309">${TYPE_LBL[c.type] || c.type}</span>${c.pub ? '' : '<span class="tag">লুকানো</span>'}${c.pin ? '<span class="tag" style="background:#0369a1">📌 পিন</span>' : ''}</div>
        <b style="margin-top:6px">${esc(c.title || (c.body || '').slice(0, 50))}</b><div class="hint">${sdate(c.at)}</div>
        <button class="btn sm" onclick="adminPage('pub','${esc(c.id)}')">✏️ সম্পাদনা</button><button class="btn sm" style="background:#475569" onclick="adHide(${i})">${c.pub ? '🙈 লুকান' : '👁️ দেখান'}</button><button class="btn sm" style="background:#dc2626" onclick="adDel('${esc(c.id)}')">🗑️ মুছুন</button></div>`).join('') : sEmpty('📭', 'কিছু প্রকাশ করা হয়নি। "নতুন" ট্যাব থেকে শুরু করুন।');
    } else if (sec === 'ads') {
      const all = await sList(m.f, ['content'], m.f.F.orderBy('createdAt', 'desc'), m.f.F.limit(500)); _acache.content = all.map(mapRow); h = adsForm();
    } else if (sec === 'qg') {
      const all = await sList(m.f, ['content'], m.f.F.orderBy('createdAt', 'desc'), m.f.F.limit(500)); _acache.content = all.map(mapRow); h = qgForm();
    } else if (sec === 'lay') {
      layInit(); h = layForm();
    } else if (sec === 'set') {
      h = settingsForm();
    } else if (sec === 'contact') {
      const k = contactData();
      h = `<div class="cx"><b>📞 যোগাযোগ পাতার তথ্য</b><div class="hint">ব্যবহারকারীরা "যোগাযোগ" আইকনে চাপলে এগুলো দেখবে। লিংক বা নম্বর পেস্ট করুন, খালি রাখলে ওই বাটন দেখাবে না।</div>
        <input class="inp" id="ct_name" placeholder="নাম" value="${esc(k.name)}">
        <input class="inp" id="ct_role" placeholder="পদ ও প্রতিষ্ঠান" value="${esc(k.role)}">
        <textarea class="inp" id="ct_about" rows="2" placeholder="ছোট পরিচয় বা বার্তা (ঐচ্ছিক)">${esc(k.about)}</textarea>
        <input class="inp" id="ct_fb" placeholder="ফেসবুক লিংক (যেমন https://facebook.com/...)" value="${esc(k.fb)}">
        <input class="inp" id="ct_wa" placeholder="হোয়াটসঅ্যাপ নম্বর (যেমন 017XXXXXXXX) বা wa.me লিংক" value="${esc(k.wa)}">
        <input class="inp" id="ct_mail" placeholder="জিমেইল (যেমন name@gmail.com)" value="${esc(k.mail)}">
        <input class="inp" id="ct_phone" placeholder="ফোন নম্বর (ঐচ্ছিক)" value="${esc(k.phone)}">
        <input class="inp" id="ct_x1n" placeholder="অতিরিক্ত লিংকের নাম (যেমন ইউটিউব, ওয়েবসাইট)" value="${esc(k.x1n)}">
        <input class="inp" id="ct_x1" placeholder="অতিরিক্ত লিংক (https://...)" value="${esc(k.x1)}">
        <div id="ad_msg" class="warn" style="display:none"></div>
        <button class="btn" onclick="adContactSave()">💾 সেভ করুন</button> <button class="btn sm" style="background:#475569" onclick="open_('contact')">👁️ দেখে নিন</button></div>`;
    } else if (sec === 'rep') {
      const rows = await sList(m.f, ['reports'], m.f.F.orderBy('createdAt', 'desc'), m.f.F.limit(50)); _acache.reports = rows;
      h = rows.length ? rows.map((r, i) => `<div class="cx"><div style="white-space:pre-line">${esc(r.postText || '')}</div><div class="hint" style="color:#b45309">কারণ: ${esc(r.why || '')}</div>
        <button class="btn sm" style="background:#dc2626" onclick="repAct(${i},'post')">🗑️ পোস্ট মুছুন</button><button class="btn sm" style="background:#7f1d1d" onclick="repAct(${i},'ban')">🚫 ব্যবহারকারী বন্ধ</button><button class="btn sm" style="background:#64748b" onclick="repAct(${i},'dismiss')">বাতিল</button></div>`).join('') : sEmpty('✅', 'কোনো রিপোর্ট নেই।');
    } else if (sec === 'adm') {
      const rows = await sList(m.f, ['admins']); _acache.admins = rows;
      h = rows.map((a, i) => `<div class="cx"><div class="rowline"><div class="av">${esc(initial(a.name || a.id))}</div><div><b style="display:inline">${esc(a.name || a.id)}</b><br><span class="tag" style="background:${a.role === 'owner' ? '#b45309' : '#0369a1'}">${a.role === 'owner' ? 'মালিক' : 'অ্যাডমিন'}</span></div></div>${(role === 'owner' && a.id !== m.u.uid) ? `<button class="btn sm" style="background:#dc2626;margin-top:8px" onclick="admRemove(${i})">সরান</button>` : ''}</div>`).join('') +
        (role === 'owner' ? `<div class="cx"><b>➕ নতুন অ্যাডমিন যোগ</b><div class="hint">যাকে যোগ করবেন, তাকে আগে অ্যাপে অ্যাকাউন্ট খুলে লগইন করতে হবে। তার মোবাইল নম্বর বা ইমেইল দিন।</div>
          <input class="inp" id="adm_id" placeholder="মোবাইল নম্বর বা ইমেইল"><div id="ad_msg" class="warn" style="display:none"></div><button class="btn sm" onclick="admAdd()">যোগ করুন</button></div>` : '<div class="warn">নতুন অ্যাডমিন যোগ বা সরাতে পারেন শুধু মালিক।</div>');
    }
    sbody(bar + h); if (sec === 'pub') adToggle();
  } catch (e) { sbody(bar + sErr(e)); }
}
function adMsg(t) { const b = document.getElementById('ad_msg'); if (b) { b.style.display = 'block'; b.textContent = t; } }
async function adUpload(m) {
  const fi = document.getElementById('ad_file'); const file = fi && fi.files && fi.files[0]; if (!file) return '';
  if (file.size > 50 * 1024 * 1024) throw {message: 'ফাইল ৫০ মেগাবাইটের বেশি।'};
  const base = `https://www.gstatic.com/firebasejs/${FB_VERSION}/`;
  const S = window.__ST_MOCK || await import(base + 'firebase-storage.js');
  const st = S.getStorage(m.f.app); const safe = file.name.replace(/[^\w.\-]/g, '_');
  const ref = S.ref(st, 'content/' + Date.now() + '_' + safe); adMsg('⏳ আপলোড হচ্ছে...');
  await S.uploadBytes(ref, file); return await S.getDownloadURL(ref);
}
async function adSave(editId) {
  const m = await sme(); if (!m) return; const type = editId ? ((_acache.content.find(x => x.id === editId) || {}).type || gv('ad_t')) : gv('ad_t'); const vis = AD_VIS[type] || [];
  if (vis.includes('title') && !gv('ad_title') && !gv('ad_titleEn') && !(type === 'quiz' && gv('ad_bulk'))) return adMsg('শিরোনাম দিন।');
  if (type === 'tip' && !gv('ad_body')) return adMsg('টিপসের লেখা দিন।');
  try {
    adMsg('⏳ সেভ হচ্ছে...'); let url = vis.includes('url') ? gv('ad_url') : ''; const up = await adUpload(m); if (up) url = up;
    if (url && !safeUrl(url)) return adMsg('লিংকটি ঠিক নয়। যেমন: https://example.com বা www.example.com');
    const d = {type, title: vis.includes('title') ? gv('ad_title').slice(0, 150) : '', body: gv('ad_body').slice(0, 20000), url, pub: chk('ad_pub'), by: m.u.uid};
    if (vis.includes('img')) { const old = editId ? ((_acache.content.find(x => x.id === editId) || {}).img || '') : ''; d.img = _picked || (chk('ad_imgdel') ? '' : old); }
    if (type === 'quiz') {
      const bulk = gv('ad_bulk');
      if (!editId && bulk) {
        const rows = parseQuizBulk(bulk); if (!rows.length) return adMsg('কোনো প্রশ্ন বোঝা যায়নি। প্রতি লাইনে: প্রশ্ন | উত্তর১ | উত্তর২ | ... | সঠিক নম্বর');
        if (rows.length > 100) return adMsg('একবারে সর্বোচ্চ ১০০টি প্রশ্ন দিন।');
        for (const r of rows) await m.f.F.addDoc(m.f.F.collection(m.f.db, 'content'), {type: 'quiz', title: r.q, body: '', url: '', pub: chk('ad_pub'), by: m.u.uid, quiz: {o: r.o, a: r.a, e: r.e}, createdAt: m.f.F.serverTimestamp()});
        await refreshContent(); return adminPage('list');
      }
      const o = [1, 2, 3, 4].map(n => gv('ad_q' + n)).filter(Boolean); const a = +gv('ad_qa') || 0; if (o.length < 2) return adMsg('কমপক্ষে দুটি উত্তর দিন।'); if (!gv('ad_q' + (a + 1))) return adMsg('সঠিক উত্তরের ঘরটি ফাঁকা।'); d.quiz = {o: [1, 2, 3, 4].map(n => gv('ad_q' + n)), a, e: gv('ad_qe').slice(0, 400)};
    }
    if (type === 'section') { d.sub = gv('ad_sub').slice(0, 120); d.ic = Array.from(gv('ad_ic') || '📌').slice(0, 2).join(''); d.mt = gv('ad_mt') || 'none'; }
    if (type === 'notice') d.pin = chk('ad_pin');
    if (type === 'node') {
      d.parent = gv('ad_parent'); if (!d.parent) return adMsg('কোথায় বসবে তা বেছে নিন।');
      d.titleEn = gv('ad_titleEn').slice(0, 150); d.bodyEn = gv('ad_bodyEn').slice(0, 20000); d.lang = gv('ad_lang') || 'auto';
      d.color = chk('ad_nocolor') ? '' : gv('ad_color'); d.ord = +gv('ad_ord') || 0; d.ic = Array.from(gv('ad_ic') || '').slice(0, 2).join(''); d.mt = gv('ad_mt') || 'none';
    }
    if (type === 'job') d.job = {c: gv('ad_c'), s: gv('ad_s'), lic: gv('ad_lic'), loc: gv('ad_loc'), deadline: gv('ad_dl'), phone: gv('ad_ph'), kind: gv('ad_kind') || 'local', url};
    if (editId) await m.f.F.setDoc(m.f.F.doc(m.f.db, 'content', editId), d, {merge: true});
    else { d.createdAt = m.f.F.serverTimestamp(); await m.f.F.addDoc(m.f.F.collection(m.f.db, 'content'), d); }
    await refreshContent();
    if (type === 'node' && d.parent) { rebuildStack(d.parent); return reopenKey(d.parent); }
    adminPage('list');
  } catch (e) { adMsg('⚠️ ' + ((e && e.code === 'permission-denied') ? 'অনুমতি নেই।' : (e && e.message) || 'সেভ হয়নি।')); }
}
async function adHide(i) {
  const c = _acache.content[i]; if (!c) return; const m = await sme();
  try { await m.f.F.setDoc(m.f.F.doc(m.f.db, 'content', c.id), {pub: !c.pub}, {merge: true}); await refreshContent(); adminPage('list'); } catch (e) { alert('বদলানো যায়নি।'); }
}
async function adDel(id) { if (!confirm('মুছে ফেলবেন?')) return; const m = await sme(); try { await m.f.F.deleteDoc(m.f.F.doc(m.f.db, 'content', id)); await refreshContent(); adminPage('list'); } catch (e) { alert('মোছা যায়নি।'); } }
async function repAct(i, act) {
  const r = _acache.reports[i]; if (!r) return; const m = await sme(); const D = m.f.F;
  try {
    if (act === 'post') await D.deleteDoc(D.doc(m.f.db, 'posts', r.postId));
    if (act === 'ban') { if (!confirm('এই ব্যবহারকারী আর পোস্ট বা মন্তব্য করতে পারবে না। নিশ্চিত?')) return; await D.setDoc(D.doc(m.f.db, 'banned', r.postUid), {at: Date.now(), by: m.u.uid}); }
    await D.deleteDoc(D.doc(m.f.db, 'reports', r.id)); adminPage('rep');
  } catch (e) { alert('কাজটি করা যায়নি।'); }
}
async function admAdd() {
  const key = loginEmail(gv('adm_id')); if (!key) return adMsg('সঠিক মোবাইল নম্বর বা ইমেইল দিন।');
  const m = await sme();
  try {
    const rows = await sList(m.f, ['profiles'], m.f.F.where('idKey', '==', key));
    if (!rows.length) return adMsg('এই আইডির কাউকে পাওয়া যায়নি। তাকে আগে অ্যাপে অ্যাকাউন্ট খুলে লগইন করতে বলুন।');
    await m.f.F.setDoc(m.f.F.doc(m.f.db, 'admins', rows[0].id), {role: 'admin', name: rows[0].name || '', by: m.u.uid, at: Date.now()}); adminPage('adm');
  } catch (e) { adMsg('⚠️ যোগ করা যায়নি।'); }
}
async function admRemove(i) {
  const a = _acache.admins[i]; if (!a || !confirm('এই অ্যাডমিনকে সরাবেন?')) return; const m = await sme();
  try { await m.f.F.deleteDoc(m.f.F.doc(m.f.db, 'admins', a.id)); adminPage('adm'); } catch (e) { alert('সরানো যায়নি।'); }
}


// ---------- যোগাযোগ পাতা ----------
const CONTACT_DEF = {name: 'নজরুল ইসলাম', role: 'জিএসসি অপারেটর, বিমান বাংলাদেশ এয়ারলাইন্স', about: 'এই অ্যাপের নির্মাতা। কোনো প্রশ্ন, পরামর্শ বা সমস্যা থাকলে জানাতে পারেন।', fb: '', wa: '', mail: '', phone: '', x1n: '', x1: ''};
function contactData() {
  const c = ADMIN_CONTENT.find(x => x.type === 'contact'); const k = (c && c.contact) || {};
  const o = Object.assign({}, CONTACT_DEF);
  Object.keys(CONTACT_DEF).forEach(f => { if (k[f] !== undefined && k[f] !== null) o[f] = k[f]; });
  if (c && c.title) o.name = c.title; if (c && c.body) o.role = c.body;
  return o;
}
function ctDigits(v) { let d = String(v || '').replace(/[০-৯]/g, ch => '০১২৩৪৫৬৭৮৯'.indexOf(ch)).replace(/\D/g, ''); if (d.startsWith('00')) d = d.slice(2); if (d.startsWith('0')) d = '88' + d; return d; }
const ctFb = v => { v = String(v || '').trim(); if (!v) return ''; if (/^https?:\/\//i.test(v)) return v; if (/^(www\.)?(facebook|fb)\.com/i.test(v)) return 'https://' + v; return /^[\w.\-]+$/.test(v.replace(/^@/, '')) ? 'https://facebook.com/' + v.replace(/^@/, '') : ''; };
const ctWa = v => { v = String(v || '').trim(); if (!v) return ''; if (/^https?:\/\//i.test(v)) return v; const d = ctDigits(v); return d.length >= 10 ? 'https://wa.me/' + d : ''; };
const ctMail = v => { v = String(v || '').trim().replace(/^mailto:/i, ''); return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v) ? 'mailto:' + v : ''; };
const ctTel = v => { const d = String(v || '').replace(/[০-৯]/g, ch => '০১২৩৪৫৬৭৮৯'.indexOf(ch)).replace(/[^\d+]/g, ''); return d.length >= 6 ? 'tel:' + d : ''; };
function contactPage() {
  tab = 'profile'; const k = contactData();
  const btn = (href, ic, label, col) => href ? `<a class="btn" style="display:flex;align-items:center;gap:10px;background:${col};text-decoration:none;margin:10px 0;padding:13px 18px" href="${esc(href)}" target="_blank" rel="noopener" onclick="goUrl(this.getAttribute('href'));return false"><span style="font-size:22px">${ic}</span>${esc(label)}</a>` : '';
  const links = btn(ctFb(k.fb), '📘', 'ফেসবুকে মেসেজ / প্রোফাইল', '#1877f2') + btn(ctWa(k.wa), '💬', 'হোয়াটসঅ্যাপে মেসেজ', '#128c4a') + btn(ctMail(k.mail), '✉️', 'জিমেইলে লিখুন', '#d93025') + btn(ctTel(k.phone), '📞', 'ফোনে কল করুন', '#0b6e4f') + btn(safeUrl(k.x1), '🔗', k.x1n || 'আরও লিংক', '#475569');
  render(pageHead('যোগাযোগ') + hero('📞', 'যোগাযোগ', 'প্রশ্ন, পরামর্শ বা সমস্যা জানান') + `<div class="pad"><div class="cx" style="text-align:center;border-left:0;border-top:5px solid #ffc20e">
    <div class="av" style="width:72px;height:72px;font-size:32px;margin:4px auto 10px">${esc(initial(k.name))}</div>
    <div style="font-size:12.5px;color:#6b726c">অ্যাপ নির্মাতা</div><div style="font-size:20px;font-weight:800;margin:2px 0">${esc(k.name)}</div>
    <div style="font-size:14.5px;font-weight:600;color:#006a4e;line-height:1.5">${esc(k.role)}</div>
    ${k.about ? `<div class="hint" style="margin-top:10px">${esc(k.about)}</div>` : ''}</div>` +
    (links ? `<div class="cx" style="border-left-color:#ffc20e">${links}</div>` : '<div class="warn">যোগাযোগের লিংক শীঘ্রই যোগ করা হবে।</div>') +
    (isAdminFlag() ? `<button class="btn sm" style="background:#b45309" onclick="push(()=>contactPage());adminPage('contact')">✏️ লিংক বদলান (অ্যাডমিন)</button>` : '') + '</div>');
}
async function adContactSave() {
  const m = await sme(); if (!m) return;
  const o = {}; ['name', 'role', 'about', 'fb', 'wa', 'mail', 'phone', 'x1n', 'x1'].forEach(f => { o[f] = gv('ct_' + f).slice(0, 300); });
  if (o.fb && !ctFb(o.fb)) return adMsg('ফেসবুক লিংকটি ঠিক নয়।');
  if (o.wa && !ctWa(o.wa)) return adMsg('হোয়াটসঅ্যাপ নম্বর ঠিক নয়।');
  if (o.mail && !ctMail(o.mail)) return adMsg('জিমেইল ঠিকানা ঠিক নয়।');
  if (o.x1 && !safeUrl(o.x1)) return adMsg('অতিরিক্ত লিংকটি ঠিক নয়।');
  try {
    adMsg('⏳ সেভ হচ্ছে...');
    await m.f.F.setDoc(m.f.F.doc(m.f.db, 'content', 'contact'), {type: 'contact', title: o.name, body: o.role, pub: true, by: m.u.uid, createdAt: m.f.F.serverTimestamp(), contact: o});
    await refreshContent(); adMsg('✅ সেভ হয়েছে।');
  } catch (e) { adMsg('⚠️ ' + ((e && e.code === 'permission-denied') ? 'অনুমতি নেই।' : 'সেভ হয়নি। ইন্টারনেট দেখুন।')); }
}

// ---------- ছবি ছোট করে ডেটাতে রাখা (Storage ছাড়াই, বিনামূল্যের প্ল্যানে চলে) ----------
const okImg = u => typeof u === 'string' && /^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+\/=]+$/.test(u) && u.length < 1000000;
function imgToData(file, maxPx, png) {
  return new Promise((res, rej) => {
    const fr = new FileReader();
    fr.onerror = () => rej(new Error('ছবি পড়া যায়নি'));
    fr.onload = () => {
      const im = new Image();
      im.onerror = () => rej(new Error('এটি ছবি নয়'));
      im.onload = () => {
        let px = maxPx, q = png ? 0.9 : 0.78, out = '';
        for (let i = 0; i < 5; i++) {
          const k = Math.min(1, px / Math.max(im.width, im.height)), c = document.createElement('canvas');
          c.width = Math.max(1, Math.round(im.width * k)); c.height = Math.max(1, Math.round(im.height * k));
          const g = c.getContext('2d'); if (!png) { g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height); }
          g.drawImage(im, 0, 0, c.width, c.height);
          out = c.toDataURL(png ? 'image/png' : 'image/jpeg', q);
          if (out.length < (png ? 150000 : 650000)) return res(out);
          px = Math.round(px * 0.75); q = Math.max(0.5, q - 0.08);
        }
        rej(new Error('ছবিটি অনেক বড়। ছোট ছবি বাছুন।'));
      };
      im.src = fr.result;
    };
    fr.readAsDataURL(file);
  });
}
async function adPick(inp) {
  const f = inp.files && inp.files[0]; if (!f) return; adMsg('⏳ ছবি ছোট করা হচ্ছে...');
  try {
    _picked = await imgToData(f, 1000, false);
    const p = document.getElementById('ad_imgprev'); if (p) { p.src = _picked; p.style.display = 'block'; }
    adMsg('✅ ছবি তৈরি। এবার নিচের বাটন চাপুন।');
  } catch (e) { _picked = ''; adMsg('⚠️ ' + (e.message || 'ছবি নেওয়া যায়নি')); }
}

// ---------- বড় লেখা সাজানো: # শিরোনাম, ## উপশিরোনাম, - তালিকা, **মোটা** ----------
function rich(t) {
  const COLS = {red: '#dc2626', green: '#15803d', blue: '#1d4ed8', orange: '#c2410c', purple: '#7e22ce', grey: '#6b7280'};
  const inl = x => esc(x).replace(/\*\*(.+?)\*\*/g, '<b>$1</b>').replace(/\{(red|green|blue|orange|purple|grey):(.+?)\}/g, (m, c, t) => `<span style="color:${COLS[c]};font-weight:700">${t}</span>`).replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g, (m, t, u) => `<a href="${u}" target="_blank" rel="noopener" onclick="goUrl(this.getAttribute('href'));return false" style="color:var(--p2);font-weight:700;text-decoration:underline">${t}</a>`);
  let out = '', ul = false;
  String(t || '').split('\n').forEach(raw => {
    const l = raw.replace(/\s+$/, '');
    if (/^\s*[-•]\s+/.test(l)) { if (!ul) { out += '<ul style="margin:6px 0;padding-left:22px">'; ul = true; } out += '<li style="margin:3px 0">' + inl(l.replace(/^\s*[-•]\s+/, '')) + '</li>'; return; }
    if (ul) { out += '</ul>'; ul = false; }
    if (/^##\s+/.test(l)) out += '<h4 style="margin:12px 0 4px;font-size:16.5px;color:var(--p2)">' + inl(l.replace(/^##\s+/, '')) + '</h4>';
    else if (/^#\s+/.test(l)) out += '<h3 style="margin:14px 0 6px;font-size:19px">' + inl(l.replace(/^#\s+/, '')) + '</h3>';
    else if (!l.trim()) out += '<div style="height:9px"></div>';
    else out += '<div style="line-height:1.7">' + inl(l) + '</div>';
  });
  return out + (ul ? '</ul>' : '');
}

// ---------- অ্যাপের নাম, লোগো, রং ও আইকন (অ্যাডমিন বদলাতে পারে) ----------
const CFG_DEF = {name: 'চালক ভাই', sub: 'শেখা • কাগজপত্র • চাকরি', ic: '🛞', logo: '', c1: '#006a4e', pg: '#f4f5f1', cd: '#ffffff', tx: '#1a1a1a', bism: true, tiles: {}, layout: null};
function APPCFG() {
  const c = ADMIN_CONTENT.find(x => x.type === 'config'); const k = (c && c.cfg) || {};
  const o = Object.assign({}, CFG_DEF); Object.keys(CFG_DEF).forEach(f => { if (k[f] !== undefined && k[f] !== null && k[f] !== '') o[f] = k[f]; });
  if (c && okImg(c.img)) o.logo = c.img;
  return o;
}
const appName = () => APPCFG().name;
const appSub = () => APPCFG().sub;
function appLogoHtml() { const c = APPCFG(); return `<span class="logo">${okImg(c.logo) ? `<img src="${c.logo}" alt="">` : esc(c.ic)}</span>`; }
const tileOv = id => { const t = APPCFG().tiles; return (t && t[id]) || {}; };
function hexMix(h, to, t) {
  const p = x => [1, 3, 5].map(i => parseInt(x.slice(i, i + 2), 16)); const a = p(h), b = p(to);
  return '#' + a.map((v, i) => Math.round(v + (b[i] - v) * t).toString(16).padStart(2, '0')).join('');
}
function applyTheme() {
  try {
    const c = APPCFG(); const r = document.documentElement.style; let c1 = /^#[0-9a-fA-F]{6}$/.test(c.c1) ? c.c1 : CFG_DEF.c1; try { const uc = localStorage.getItem('ucolor'); if (uc && /^#[0-9a-fA-F]{6}$/.test(uc)) c1 = uc; } catch (e) {}
    const hx = (v, d) => /^#[0-9a-fA-F]{6}$/.test(v) ? v : d; r.setProperty('--pg', hx(c.pg, '#f4f5f1')); r.setProperty('--cd', hx(c.cd, '#ffffff')); r.setProperty('--tx', hx(c.tx, '#1a1a1a')); r.setProperty('--p2', c1); r.setProperty('--p1', hexMix(c1, '#000000', 0.22)); r.setProperty('--tint', hexMix(c1, '#ffffff', 0.88)); r.setProperty('--g2', c1); r.setProperty('--g1', hexMix(c1, '#000000', 0.22));
    document.title = c.name; const tm = document.querySelector('meta[name=theme-color]'); if (tm) tm.setAttribute('content', hexMix(c1, '#000000', 0.22));
  } catch (e) {}
}
applyTheme();

const THEMES = [['সবুজ', '#006a4e', '#f4f5f1', '#ffffff', '#fff', '#1a1a1a'], ['নীল', '#0b5ed7', '#eef3fb', '#ffffff', '#fff', '#16202e'], ['বেগুনি', '#6d28d9', '#f5f1fb', '#ffffff', '#fff', '#241a33'], ['লাল', '#b91c1c', '#fbf1f1', '#ffffff', '#fff', '#2b1a1a'], ['কমলা', '#c2410c', '#fbf3ec', '#ffffff', '#fff', '#2d1f14'], ['টিল', '#0f766e', '#eef7f6', '#ffffff', '#fff', '#13292a'], ['গোলাপি', '#be185d', '#fcf0f5', '#ffffff', '#fff', '#2e1823'], ['কালচে', '#1f2937', '#e5e7eb', '#f9fafb', '#fff', '#111827'], ['সোনালি', '#92400e', '#faf5e8', '#fffdf6', '#fff', '#2b2216'], ['আকাশি', '#0284c7', '#edf7fc', '#ffffff', '#fff', '#12283a']];
function cfPreset(i) { const t = THEMES[i]; [['cf_c1', t[1]], ['cf_pg', t[2]], ['cf_cd', t[3]], ['cf_tx', t[5]]].forEach(x => { const e = document.getElementById(x[0]); if (e) e.value = x[1]; }); cfLive(); }
function cfLive() { const g = id => (document.getElementById(id) || {}).value; const r = document.documentElement.style, c1 = g('cf_c1'); if (!c1) return; r.setProperty('--p2', c1); r.setProperty('--p1', hexMix(c1, '#000000', 0.22)); r.setProperty('--tint', hexMix(c1, '#ffffff', 0.88)); r.setProperty('--pg', g('cf_pg')); r.setProperty('--cd', g('cf_cd')); r.setProperty('--tx', g('cf_tx')); }
function settingsForm() {
  const c = APPCFG(); const tiles = typeof homeGroups === 'function' ? homeGroups(true).flatMap(g => g[1]).filter(t => String(t.id).indexOf('sec_') !== 0) : [];
  const quick = typeof QUICK !== 'undefined' ? QUICK.filter(q => !tiles.some(t => t.id === q[0])).map(q => ({id: q[0], name: q[2], ic: q[1]})) : [];
  const all = quick.concat(tiles); const seen = new Set();
  return `<div class="cx"><b>🎨 অ্যাপের পরিচয়</b><div class="hint">নাম, লোগো ও রং বদলালে হোম, মেনু ও শুরুর পর্দা সব জায়গায় বদলে যায়।</div>
    <input class="inp" id="cf_name" placeholder="অ্যাপের নাম" value="${esc(c.name)}">
    <input class="inp" id="cf_sub" placeholder="নামের নিচের ছোট লেখা" value="${esc(c.sub)}">
    <input class="inp" id="cf_ic" maxlength="4" placeholder="লোগো (একটি ইমোজি)" value="${esc(c.ic)}">
    <div class="hint" style="margin:0 0 4px">অথবা নিজের লোগো ছবি (ছবি থাকলে ইমোজির বদলে ওটা দেখাবে)</div>
    ${okImg(c.logo) ? `<img id="cf_prev" src="${c.logo}" style="width:64px;height:64px;border-radius:16px;object-fit:cover;display:block;margin:4px 0"><label style="display:block;margin:4px 0"><input type="checkbox" id="cf_logodel">লোগো ছবিটি সরান</label>` : '<img id="cf_prev" style="display:none;width:64px;height:64px;border-radius:16px;object-fit:cover;margin:4px 0">'}
    <input type="file" id="cf_logo" accept="image/*" onchange="cfPickLogo(this)">
    <div class="hint" style="margin-top:12px">তৈরি রঙের সাজ (একটা চাপলেই পুরো অ্যাপ বদলে যাবে, তারপর সেভ করুন)</div>
    <div class="presets">${THEMES.map((t, i) => `<button onclick="cfPreset(${i})" style="background:linear-gradient(135deg,${t[1]} 50%,${t[3]} 50%)"><span style="color:${t[4]}">${t[0]}</span></button>`).join('')}</div>
    <div class="hint" style="margin-top:12px">নিজের পছন্দের রং</div>
    ${[['cf_c1', 'হেডার, বাটন ও মূল রং', c.c1], ['cf_pg', 'পাতার পেছনের রং', c.pg], ['cf_cd', 'কার্ড ও বাক্সের রং', c.cd], ['cf_tx', 'লেখার রং', c.tx]].map(x => `<div class="rowline" style="margin:6px 0"><input type="color" id="${x[0]}" value="${esc(x[2])}" oninput="cfLive()" style="width:54px;height:40px;border:0;background:none;padding:0"><span>${x[1]}</span></div>`).join('')}
    <label style="display:block;margin:10px 0"><input type="checkbox" id="cf_bism" ${c.bism !== false ? 'checked' : ''}>অ্যাপ খোলার সময় "বিসমিল্লাহির রাহমানির রাহিম" দেখান</label></div></div>
    <div class="cx"><b>🔲 হোমের আইকন</b><div class="hint">যেকোনো আইকনের নাম ও ইমোজি বদলান, বা লুকিয়ে দিন। ফাঁকা রাখলে আগের নামই থাকবে।</div>
    ${all.filter(t => !seen.has(t.id) && seen.add(t.id)).map(t => { const o = (c.tiles || {})[t.id] || {}; return `<div style="display:flex;gap:6px;align-items:center;margin:6px 0" data-tid="${esc(t.id)}"><input class="inp tc_ic" style="width:58px;margin:0;text-align:center" maxlength="4" value="${esc(o.ic || '')}" placeholder="${esc(t.ic)}"><input class="inp tc_nm" style="margin:0;flex:1" value="${esc(o.name || '')}" placeholder="${esc(t.name)}"><label style="font-size:12px;white-space:nowrap"><input type="checkbox" class="tc_hd" ${o.hide ? 'checked' : ''}>লুকান</label></div>`; }).join('')}</div>
    <div id="ad_msg" class="warn" style="display:none"></div>
    <button class="btn" onclick="cfSave()">💾 সেভ করুন</button> <button class="btn sm" style="background:#475569" onclick="cfReset()">↩️ আগের অবস্থায় ফেরান</button>`;
}
async function cfPickLogo(inp) {
  const f = inp.files && inp.files[0]; if (!f) return; adMsg('⏳ লোগো ছোট করা হচ্ছে...');
  try { _logoPicked = await imgToData(f, 200, true); const p = document.getElementById('cf_prev'); if (p) { p.src = _logoPicked; p.style.display = 'block'; } adMsg('✅ লোগো তৈরি। এবার সেভ করুন।'); }
  catch (e) { _logoPicked = null; adMsg('⚠️ ' + (e.message || 'লোগো নেওয়া যায়নি')); }
}
async function cfSave() {
  const m = await sme(); if (!m) return;
  const tiles = {}; document.querySelectorAll('[data-tid]').forEach(r => {
    const o = {}; const ic = r.querySelector('.tc_ic').value.trim(), nm = r.querySelector('.tc_nm').value.trim(), hd = r.querySelector('.tc_hd').checked;
    if (ic) o.ic = Array.from(ic).slice(0, 2).join(''); if (nm) o.name = nm.slice(0, 40); if (hd) o.hide = true;
    if (Object.keys(o).length) tiles[r.getAttribute('data-tid')] = o;
  });
  const prev = ADMIN_CONTENT.find(x => x.type === 'config'); const old = prev && okImg(prev.img) ? prev.img : '';
  const img = _logoPicked || (chk('cf_logodel') ? '' : old);
  const cfg = {name: gv('cf_name').slice(0, 40) || CFG_DEF.name, sub: gv('cf_sub').slice(0, 60), ic: Array.from(gv('cf_ic') || CFG_DEF.ic).slice(0, 2).join(''), c1: gv('cf_c1') || CFG_DEF.c1, pg: gv('cf_pg') || CFG_DEF.pg, cd: gv('cf_cd') || CFG_DEF.cd, tx: gv('cf_tx') || CFG_DEF.tx, bism: chk('cf_bism'), tiles, layout: (prev && prev.cfg && prev.cfg.layout) || null};
  try {
    adMsg('⏳ সেভ হচ্ছে...');
    await m.f.F.setDoc(m.f.F.doc(m.f.db, 'content', 'appconfig'), {type: 'config', title: 'config', pub: true, by: m.u.uid, createdAt: m.f.F.serverTimestamp(), cfg, img});
    _logoPicked = null; await refreshContent(); applyTheme(); adMsg('✅ সেভ হয়েছে। হোমে গিয়ে দেখুন।');
  } catch (e) { adMsg('⚠️ ' + ((e && e.code === 'permission-denied') ? 'অনুমতি নেই।' : 'সেভ হয়নি। ইন্টারনেট দেখুন।')); }
}
async function cfReset() {
  if (!confirm('অ্যাপের নাম, লোগো, রং ও আইকনের সব বদল আগের অবস্থায় ফিরবে। নিশ্চিত?')) return; const m = await sme(); if (!m) return;
  try { await m.f.F.deleteDoc(m.f.F.doc(m.f.db, 'content', 'appconfig')); _logoPicked = null; await refreshContent(); applyTheme(); adminPage('set'); } catch (e) { adMsg('⚠️ হয়নি।'); }
}

// =====================================================================
//  অ্যাডমিন বিল্ডার: যেকোনো আইকন/পাতার ভিতরে অধ্যায়, উপ-অধ্যায়, লিংক, রং, বাংলা-ইংরেজি
// =====================================================================
function pk(bn, en, mode) {
  bn = bn || ''; en = en || '';
  if (mode === 'both') return bn && en ? bn + '\n\n' + en : (bn || en);
  if (mode === 'en') return en || bn;
  if (mode === 'bn') return bn || en;
  return (typeof LANG !== 'undefined' && LANG === 'en' && en) ? en : (bn || en);
}
const nTitle = c => { if (c.lang === 'both' && c.title && c.titleEn) return c.title + ' / ' + c.titleEn; return pk(c.title, c.titleEn, c.lang); };
const nBody = c => pk(c.body, c.bodyEn, c.lang);
const nodeKids = key => ADMIN_CONTENT.filter(c => c.type === 'node' && c.parent === key).sort((a, b) => (a.ord || 0) - (b.ord || 0) || (a.at || 0) - (b.at || 0));
const colOk = c => /^#[0-9a-fA-F]{6}$/.test(c || '') ? c : '';
function keyName(k) {
  if (k.indexOf('n_') === 0) { const n = ADMIN_CONTENT.find(c => c.id === k.slice(2)) || _acache.content.find(c => c.id === k.slice(2)); return n ? nTitle(n) : k; }
  if (k.indexOf('sec_') === 0) { const n = ADMIN_CONTENT.find(c => c.id === k.slice(4)) || _acache.content.find(c => c.id === k.slice(4)); return n ? (n.title || k) : k; }
  const t = (typeof homeGroups === 'function' ? homeGroups(true).flatMap(g => g[1]) : []).find(c => c.id === k);
  return t ? ((tileOv(k).name) || (typeof SHORT !== 'undefined' && SHORT[k]) || t.name) : k;
}
function parentOpts(sel, selfId) {
  const rows = _acache.content.length ? _acache.content : ADMIN_CONTENT; const seen = new Set(); let h = '<optgroup label="অ্যাপের আইকন">';
  (typeof homeGroups === 'function' ? homeGroups(true).flatMap(g => g[1]) : []).forEach(t => { if (String(t.id).indexOf('sec_') === 0 || seen.has(t.id)) return; seen.add(t.id); h += `<option value="${esc(t.id)}" ${sel === t.id ? 'selected' : ''}>${esc(keyName(t.id))}</option>`; });
  h += '</optgroup><optgroup label="আপনার বানানো সেকশন">';
  rows.filter(c => c.type === 'section').forEach(c => { h += `<option value="sec_${esc(c.id)}" ${sel === 'sec_' + c.id ? 'selected' : ''}>${esc(c.title || '')}</option>`; });
  h += '</optgroup><optgroup label="আপনার বানানো পাতা (ভিতরে ঢুকবে)">';
  rows.filter(c => c.type === 'node' && c.id !== selfId).forEach(c => { h += `<option value="n_${esc(c.id)}" ${sel === 'n_' + c.id ? 'selected' : ''}>↳ ${esc(nTitle(c))}</option>`; });
  return h + '</optgroup>';
}
function reopenKey(k) {
  if (k.indexOf('n_') === 0) return nodePage(k.slice(2));
  if (k.indexOf('sec_') === 0) return sectionPage(k.slice(4));
  stack.pop(); open_(k);
}
function rebuildStack(key) {
  const anc = []; let k = key;
  while (k.indexOf('n_') === 0) { const n = ADMIN_CONTENT.find(c => c.id === k.slice(2)); if (!n) break; k = n.parent; anc.unshift(k); }
  stack = [() => home()].concat(anc.map(a => () => reopenKey(a)));
}
function nodeGo(id, from) { stack.push(() => reopenKey(from)); nodePage(id); }
function adAddHere(key) { _presetType = 'node'; _presetParent = key; stack.push(() => reopenKey(key)); adminPage('pub'); }
function adEditNode(id) { stack.push(() => nodePage(id)); adminPage('pub', id); }
async function adDelNode(id, key) {
  if (!confirm('এই পাতা মুছবেন? এর ভিতরের পাতাগুলোও আর দেখা যাবে না।')) return; const m = await sme(); if (!m) return;
  try { await m.f.F.deleteDoc(m.f.F.doc(m.f.db, 'content', id)); await refreshContent(); rebuildStack(key); reopenKey(key); } catch (e) { alert('মোছা যায়নি।'); }
}
function nodeCard(c, from) {
  const col = colOk(c.color) || '#0369a1', n = nodeKids('n_' + c.id).length;
  return `<div class="nk" style="border-left-color:${col}" onclick="nodeGo('${esc(c.id)}','${esc(from)}')"><span class="nki" style="background:${col}22;color:${col}">${esc(c.ic || (c.url && !c.body && !c.bodyEn ? '🔗' : '📄'))}</span><div class="nkt"><b>${esc(nTitle(c))}</b>${n ? `<small>${bn(n)}টি বিষয়</small>` : ''}</div><span class="nka">›</span></div>`;
}
function adminBar(key, c) {
  if (!(typeof isAdminFlag === 'function' && isAdminFlag())) return '';
  return `<div class="adbar"><span>🛡️ অ্যাডমিন</span><button onclick="adAddHere('${esc(key)}')">➕ এখানে নতুন যোগ</button>${c ? `<button onclick="adEditNode('${esc(c.id)}')">✏️ বদলান</button><button style="background:#b91c1c" onclick="adDelNode('${esc(c.id)}','${esc(c.parent)}')">🗑️</button>` : ''}</div>`;
}
function injectKids(key) {
  try {
    if (['quiz', 'roadtest', 'signquiz', 'account', 'lang', 'share', 'cv', 'admin', 'contact', 'board', 'community', 'seeker', 'courses'].includes(key)) return;
    const old = document.getElementById('kids'); if (old) old.remove();
    const k = nodeKids(key), adm = adminBar(key, key.indexOf('n_') === 0 ? ADMIN_CONTENT.find(c => c.id === key.slice(2)) : null);
    if (!k.length && !adm) return;
    const host = document.querySelector('#app .page-h') || document.querySelector('#app .hero'); if (!host) return;
    let anchor = host; const hero = host.nextElementSibling; if (hero && hero.classList.contains('hero')) anchor = hero;
    anchor.insertAdjacentHTML('afterend', `<div class="pad" id="kids">${adm}${k.map(c => nodeCard(c, key)).join('')}</div>`);
  } catch (e) {}
}
function nodePage(id) {
  tab = 'home'; const c = ADMIN_CONTENT.find(x => x.id === id);
  if (!c) return render(pageHead('পাতা') + '<div class="pad">' + sEmpty('🔍', 'এই পাতাটি আর নেই।') + '</div>');
  const col = colOk(c.color), key = 'n_' + id, body = nBody(c);
  render(pageHead(nTitle(c)) + `<div class="pad"><div class="cx" ${col ? `style="border-top:5px solid ${col}"` : ''}>${c.ic ? `<div style="font-size:34px">${esc(c.ic)}</div>` : ''}<h3 style="margin:4px 0 8px;${col ? 'color:' + col : ''}">${esc(nTitle(c))}</h3>${mediaHtml(c)}${body ? `<div class="rich" style="margin-top:8px">${rich(body)}</div>` : ''}${linkBtn(c.url)}${body ? speakBtn(body) : ''}</div></div>`);
  injectKids(key);
}
// ক্রমে সাজানো যায় এমন ছোট কার্ড CSS
(function () { const st = document.createElement('style'); st.textContent = `
.nk{display:flex;align-items:center;gap:12px;background:#fff;border:1px solid #e5e7eb;border-left:6px solid #0369a1;border-radius:14px;padding:12px;margin:9px 0;box-shadow:0 2px 8px rgba(0,0,0,.05)}
.nk:active{transform:scale(.99)}.nki{width:44px;height:44px;border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:22px;flex:none}
.nkt{flex:1}.nkt b{display:block;font-size:16px}.nkt small{color:#6b7280}.nka{font-size:22px;color:#9ca3af}
.adbar{display:flex;flex-wrap:wrap;gap:6px;align-items:center;background:#fff7ed;border:1.5px dashed #fb923c;border-radius:12px;padding:8px;margin:8px 0;font-size:13px;font-weight:700;color:#9a3412}
.adbar button{border:0;background:#c2410c;color:#fff;border-radius:10px;padding:8px 10px;font:inherit;font-size:13px}
.adtop{margin:10px 12px 0;border-radius:16px;overflow:hidden;position:relative;background:#fff;border:1px solid #e5e7eb;box-shadow:0 4px 14px rgba(0,0,0,.1)}
.adtop img{width:100%;display:block;max-height:240px;object-fit:cover}.adtop .at{padding:12px 14px;font-weight:700;font-size:16px}
.adlbl{position:absolute;top:6px;left:6px;background:rgba(0,0,0,.55);color:#fff;border-radius:8px;font-size:10px;padding:2px 7px}
#bars{position:fixed;bottom:0;left:50%;transform:translateX(-50%);width:100%;max-width:480px;z-index:70}
.adbot{display:flex;align-items:center;gap:8px;background:#fff;border-top:1px solid #e5e7eb;padding:6px 8px;box-shadow:0 -3px 12px rgba(0,0,0,.08)}
.adbot img{height:42px;width:68px;object-fit:cover;border-radius:8px;flex:none}.adbot span{flex:1;font-size:13px;font-weight:600;line-height:1.3}
.adbot i{font-style:normal;color:#9ca3af;padding:4px 8px;font-size:16px}
.tkr{display:flex;align-items:stretch;background:#111827;color:#fff;overflow:hidden;height:34px}
.tkr b{background:#dc2626;padding:0 12px;display:flex;align-items:center;font-size:13px;flex:none;z-index:2}
.tkr div{flex:1;overflow:hidden;white-space:nowrap;display:flex;align-items:center}
.tkr span{display:inline-block;padding-left:100%;animation:tkm 30s linear infinite;font-size:14px}
@keyframes tkm{to{transform:translateX(-100%)}}
body.dark .nk,body.dark .adbot,body.dark .adtop{background:#1f2937;border-color:#374151}
`; document.head.appendChild(st); })();

// =====================================================================
//  বিজ্ঞাপন (উপরে বড়, নিচে ছোট) ও টিভির মতো খবরের লাইন
// =====================================================================
const adDoc = id => ADMIN_CONTENT.find(c => c.id === id);
let _adBotX = false;
function topAd() {
  const a = adDoc('ad_top'); if (!a || !(okImg(a.img) || a.body)) return '';
  const u = safeUrl(a.url);
  return `<${u ? 'a href="' + esc(u) + '" target="_blank" rel="noopener" onclick="goUrl(this.href);return false"' : 'div'} class="adtop" style="display:block;color:inherit;text-decoration:none"><span class="adlbl" ${okImg(a.img) ? '' : 'style="position:static;display:inline-block;margin:8px 0 0 12px;background:#6b7280"'}>বিজ্ঞাপন</span>${okImg(a.img) ? `<img src="${a.img}" alt="">` : ''}${a.body ? `<div class="at">${esc(a.body)}</div>` : ''}</${u ? 'a' : 'div'}>`;
}
function renderBars() {
  let b = document.getElementById('bars'); if (!b) { b = document.createElement('div'); b.id = 'bars'; document.body.appendChild(b); }
  const a = adDoc('ad_bot'), t = adDoc('ticker'); let h = '';
  if (a && !_adBotX && (okImg(a.img) || a.body)) { const u = safeUrl(a.url); h += `<div class="adbot" ${u ? `onclick="goUrl('${esc(u)}')"` : ''}>${okImg(a.img) ? `<img src="${a.img}" alt="">` : ''}<span>${esc(a.body || '')}<small style="display:block;color:#9ca3af;font-size:10px">বিজ্ঞাপন</small></span><i onclick="event.stopPropagation();_adBotX=true;renderBars()">✕</i></div>`; }
  const lines = t && t.body ? t.body.split('\n').map(x => x.trim()).filter(Boolean) : [];
  if (lines.length) { const txt = lines.join('   ●   '); h += `<div class="tkr"><b>${esc(t.label || 'খবর')}</b><div><span style="animation-duration:${Math.max(14, Math.round(txt.length * 0.32))}s">${esc(txt)}</span></div></div>`; }
  b.innerHTML = h; const ap = document.getElementById('app'); if (ap) ap.style.paddingBottom = (h ? b.offsetHeight + 14 : 16) + 'px';
}
function adsForm() {
  const g = id => _acache.content.find(c => c.id === id) || {};
  const t = g('ad_top'), bt = g('ad_bot'), tk = g('ticker');
  const blk = (k, title, hint, o) => `<div class="cx"><b>${title}</b><div class="hint">${hint}</div>
    <label style="display:block;margin:6px 0"><input type="checkbox" id="${k}_on" ${o.pub ? 'checked' : ''}>চালু আছে</label>
    <textarea class="inp" id="${k}_tx" rows="2" placeholder="বিজ্ঞাপনের লেখা">${esc(o.body || '')}</textarea>
    <input class="inp" id="${k}_url" placeholder="লিংক (ঐচ্ছিক, https://...)" value="${esc(o.url || '')}">
    ${okImg(o.img) ? `<img id="${k}_prev" src="${o.img}" style="max-width:100%;max-height:120px;border-radius:10px;display:block;margin:6px 0"><label style="display:block"><input type="checkbox" id="${k}_del">ছবি সরান</label>` : `<img id="${k}_prev" style="display:none;max-width:100%;max-height:120px;border-radius:10px;margin:6px 0">`}
    <input type="file" accept="image/*" onchange="adAdPick(this,'${k}')"><button class="btn sm" style="margin-top:8px" onclick="adAdSave('${k}')">💾 সেভ করুন</button></div>`;
  return blk('ad_top', '🖼️ উপরের বড় বিজ্ঞাপন', 'অ্যাপের হোম পাতার একদম উপরে বড় করে দেখাবে। ছবি, লেখা বা দুটোই দিতে পারেন।', t) +
    blk('ad_bot', '📌 নিচের ছোট বিজ্ঞাপন', 'সব পাতার নিচে ছোট্ট একটি লাইনে দেখাবে। ব্যবহারকারী ✕ চাপলে ওই বার বন্ধ হবে।', bt) +
    `<div class="cx"><b>📰 খবরের লাইন (টিভির মতো চলবে)</b><div class="hint">প্রতি লাইনে একটি করে খবর লিখুন। সব খবর নিচে একটানা চলতে থাকবে। যা মন চায় লিখতে পারেন।</div>
    <label style="display:block;margin:6px 0"><input type="checkbox" id="tk_on" ${tk.pub ? 'checked' : ''}>চালু আছে</label>
    <input class="inp" id="tk_label" placeholder="বাঁ পাশের লেবেল (যেমন: খবর, নোটিশ)" value="${esc(tk.label || 'খবর')}">
    <textarea class="inp" id="tk_tx" rows="6" placeholder="একটি লাইনে একটি খবর">${esc(tk.body || '')}</textarea>
    <button class="btn sm" onclick="adTickSave()">💾 সেভ করুন</button></div><div id="ad_msg" class="warn" style="display:none"></div>`;
}
const _adImgs = {};
async function adAdPick(inp, k) {
  const f = inp.files && inp.files[0]; if (!f) return; adMsg('⏳ ছবি ছোট করা হচ্ছে...');
  try { _adImgs[k] = await imgToData(f, 900, false); const p = document.getElementById(k + '_prev'); if (p) { p.src = _adImgs[k]; p.style.display = 'block'; } adMsg('✅ ছবি তৈরি। এবার সেভ করুন।'); } catch (e) { adMsg('⚠️ ' + (e.message || 'ছবি নেওয়া যায়নি')); }
}
async function adAdSave(k) {
  const m = await sme(); if (!m) return; const old = (_acache.content.find(c => c.id === k) || {}).img || '';
  const url = gv(k + '_url'); if (url && !safeUrl(url)) return adMsg('লিংকটি ঠিক নয়। যেমন: https://example.com বা www.example.com');
  const img = _adImgs[k] || (chk(k + '_del') ? '' : old);
  try { adMsg('⏳ সেভ হচ্ছে...'); await m.f.F.setDoc(m.f.F.doc(m.f.db, 'content', k), {type: 'ad', slot: k === 'ad_top' ? 'top' : 'bot', title: 'ad', body: gv(k + '_tx').slice(0, 300), url, img, pub: chk(k + '_on'), by: m.u.uid, createdAt: m.f.F.serverTimestamp()}); delete _adImgs[k]; await refreshContent(); renderBars(); adMsg('✅ সেভ হয়েছে।'); } catch (e) { adMsg('⚠️ সেভ হয়নি।'); }
}
async function adTickSave() {
  const m = await sme(); if (!m) return;
  try { adMsg('⏳ সেভ হচ্ছে...'); await m.f.F.setDoc(m.f.F.doc(m.f.db, 'content', 'ticker'), {type: 'ticker', title: 'ticker', body: gv('tk_tx').slice(0, 3000), label: gv('tk_label').slice(0, 12) || 'খবর', pub: chk('tk_on'), by: m.u.uid, createdAt: m.f.F.serverTimestamp()}); await refreshContent(); renderBars(); adMsg('✅ সেভ হয়েছে।'); } catch (e) { adMsg('⚠️ সেভ হয়নি।'); }
}

// =====================================================================
//  হোমের আইকন নিজের মতো সাজানো: ক্রম বদল, অন্য গ্রুপে নেওয়া, গ্রুপের নাম বদল
// =====================================================================
const layoutOv = () => { const l = APPCFG().layout; return Array.isArray(l) && l.length ? l : null; };
function applyLayout(groups) {
  const lay = layoutOv(); if (!lay) return groups;
  const all = {}; groups.forEach(g => g[1].forEach(t => { all[t.id] = t; })); const used = new Set();
  const out = lay.map(g => [String(g.name || ''), (g.ids || []).map(id => { used.add(id); return all[id]; }).filter(Boolean)]);
  const rest = Object.keys(all).filter(id => !used.has(id)).map(id => all[id]);
  if (rest.length) { const k = out.findIndex(g => g[0] === 'নতুন আইকন'); if (k >= 0) out[k][1] = out[k][1].concat(rest); else out.push(['নতুন আইকন', rest]); }
  return out;
}
let _lay = [];
function layInit() { const g = homeGroups(true); _lay = g.map(x => ({name: x[0], ids: x[1].map(t => t.id)})); }
function layCommit() { document.querySelectorAll('[data-gi]').forEach(e => { const i = +e.getAttribute('data-gi'); if (_lay[i]) _lay[i].name = e.value.trim().slice(0, 40); }); }
function layForm() {
  const tiles = {}; homeGroups(true).forEach(g => g[1].forEach(t => { tiles[t.id] = t; }));
  return `<div class="cx"><b>🧩 হোমের আইকন সাজান</b><div class="hint">⬆⬇ চাপলে আইকন ওঠানামা করে (গ্রুপের শেষে গেলে পরের গ্রুপে চলে যায়)। "কোথায়" থেকে সরাসরি অন্য গ্রুপে পাঠানো যায়। গ্রুপের নামও বদলানো যায়। শেষে সেভ করুন।</div></div><div id="layBox">${layHtml(tiles)}</div>
  <div id="ad_msg" class="warn" style="display:none"></div>
  <button class="btn" onclick="laySave()">💾 সেভ করুন</button> <button class="btn sm" onclick="layNewG()">➕ নতুন গ্রুপ</button> <button class="btn sm" style="background:#475569" onclick="layReset()">↩️ আগের সাজ</button>`;
}
function layHtml(tiles) {
  if (!tiles) { tiles = {}; homeGroups(true).forEach(g => g[1].forEach(t => { tiles[t.id] = t; })); }
  return _lay.map((g, gi) => `<div class="cx"><div class="rowline"><input class="inp" style="margin:0;font-weight:800" data-gi="${gi}" value="${esc(g.name)}"><button class="btn sm" style="margin:0" onclick="layMoveG(${gi},-1)">⬆</button><button class="btn sm" style="margin:0" onclick="layMoveG(${gi},1)">⬇</button><button class="btn sm" style="margin:0;background:#dc2626" onclick="layDelG(${gi})">🗑️</button></div>
    ${g.ids.map((id, ti) => { const t = tiles[id] || {}; return `<div class="layrow"><span class="lai">${esc(tileOv(id).ic || t.ic || '•')}</span><span class="lan">${esc(keyName(id))}</span><button onclick="layMoveT(${gi},${ti},-1)">⬆</button><button onclick="layMoveT(${gi},${ti},1)">⬇</button><select onchange="layTo(${gi},${ti},this.value)"><option value="">কোথায়</option>${_lay.map((x, k) => k === gi ? '' : `<option value="${k}">${esc(x.name || 'গ্রুপ ' + (k + 1))}</option>`).join('')}</select></div>`; }).join('') || '<div class="hint">এই গ্রুপে এখন কিছু নেই।</div>'}</div>`).join('');
}
function layRefresh() { const b = document.getElementById('layBox'); if (b) b.innerHTML = layHtml(); }
function layMoveG(i, d) { layCommit(); const j = i + d; if (j < 0 || j >= _lay.length) return; [_lay[i], _lay[j]] = [_lay[j], _lay[i]]; layRefresh(); }
function layMoveT(gi, ti, d) {
  layCommit(); const g = _lay[gi], id = g.ids[ti], nt = ti + d;
  if (nt >= 0 && nt < g.ids.length) { g.ids.splice(ti, 1); g.ids.splice(nt, 0, id); }
  else if (d < 0 && gi > 0) { g.ids.splice(ti, 1); _lay[gi - 1].ids.push(id); }
  else if (d > 0 && gi < _lay.length - 1) { g.ids.splice(ti, 1); _lay[gi + 1].ids.unshift(id); }
  layRefresh();
}
function layTo(gi, ti, v) { if (v === '') return; layCommit(); const id = _lay[gi].ids.splice(ti, 1)[0]; _lay[+v].ids.push(id); layRefresh(); }
function layNewG() { layCommit(); _lay.push({name: 'নতুন গ্রুপ', ids: []}); layRefresh(); }
function layDelG(i) {
  layCommit(); const g = _lay[i]; if (g.ids.length) { if (!confirm('এই গ্রুপের আইকনগুলো আগের গ্রুপে চলে যাবে। ঠিক আছে?')) return; const to = i > 0 ? i - 1 : 1; if (_lay[to]) _lay[to].ids = _lay[to].ids.concat(g.ids); else return alert('অন্তত একটি গ্রুপ থাকতে হবে।'); }
  _lay.splice(i, 1); layRefresh();
}
async function laySave() {
  layCommit(); const m = await sme(); if (!m) return;
  const layout = _lay.filter(g => g.name || g.ids.length).map(g => ({name: g.name || 'গ্রুপ', ids: g.ids}));
  try { adMsg('⏳ সেভ হচ্ছে...'); await m.f.F.setDoc(m.f.F.doc(m.f.db, 'content', 'appconfig'), {type: 'config', title: 'config', pub: true, by: m.u.uid, cfg: {layout}}, {merge: true}); await refreshContent(); adMsg('✅ সেভ হয়েছে। হোমে গিয়ে দেখুন।'); } catch (e) { adMsg('⚠️ সেভ হয়নি।'); }
}
async function layReset() {
  if (!confirm('হোমের সাজ আগের অবস্থায় ফিরবে। নিশ্চিত?')) return; const m = await sme(); if (!m) return;
  try { await m.f.F.setDoc(m.f.F.doc(m.f.db, 'content', 'appconfig'), {cfg: {layout: null}}, {merge: true}); await refreshContent(); layInit(); layRefresh(); adMsg('✅ আগের সাজে ফিরেছে।'); } catch (e) { adMsg('⚠️ হয়নি।'); }
}
(function () { const st = document.createElement('style'); st.textContent = `.layrow{display:flex;align-items:center;gap:6px;margin:6px 0;padding:6px;border-radius:10px;background:var(--tint)}.lai{font-size:20px;width:28px;text-align:center}.lan{flex:1;font-size:14px;font-weight:600}.layrow button{border:0;background:var(--p2);color:#fff;border-radius:8px;width:34px;height:32px}.layrow select{max-width:84px;font:inherit;font-size:12px;border-radius:8px;border:1px solid #cbd5e1;height:32px}`; document.head.appendChild(st); })();

const _bd = v => String(v).replace(/[০-৯]/g, ch => '০১২৩৪৫৬৭৮৯'.indexOf(ch));
function parseQuizBulk(t) {
  const out = [];
  String(t).split('\n').forEach(line => {
    const p = line.split(/[|｜]/).map(x => x.trim()); if (p.length < 4 || !p[0]) return;
    let opts, ans, ex = '';
    const numIdx = p.findIndex((x, i) => i >= 3 && /^[১-৪1-4]$/.test(x));
    if (numIdx > 0) { opts = p.slice(1, numIdx); ans = +_bd(p[numIdx]) - 1; ex = p.slice(numIdx + 1).join(' | '); } else { opts = p.slice(1, 5); ans = 0; }
    opts = opts.filter(Boolean); if (opts.length < 2 || !(ans >= 0 && ans < opts.length)) return;
    out.push({q: p[0].slice(0, 200), o: opts.slice(0, 4), a: ans, e: ex.slice(0, 400)});
  });
  return out;
}

// =====================================================================
//  ইউজারের নিজের পছন্দের রং (৭টি)
// =====================================================================
const UCOLORS = [['সবুজ', '#006a4e'], ['নীল', '#0b5ed7'], ['বেগুনি', '#6d28d9'], ['লাল', '#b91c1c'], ['কমলা', '#c2410c'], ['গোলাপি', '#be185d'], ['টিল', '#0f766e']];
function ucolorBox() {
  let cur = ''; try { cur = localStorage.getItem('ucolor') || ''; } catch (e) {}
  return `<div class="box" style="text-align:center"><b>🎨 আমার পছন্দের রং</b><div style="font-size:13px;color:#666;margin:4px 0 8px">অ্যাপের রং আপনার মতো বদলে নিন</div><div style="display:flex;justify-content:center;gap:9px;flex-wrap:wrap">${UCOLORS.map(c => `<button aria-label="${c[0]}" onclick="setUColor('${c[1]}')" style="width:40px;height:40px;border-radius:50%;border:${cur === c[1] ? '4px solid #111' : '2px solid #fff'};box-shadow:0 1px 5px rgba(0,0,0,.35);background:${c[1]}"></button>`).join('')}</div>${cur ? '<button class="btn sm" style="background:#64748b;margin-top:10px" onclick="setUColor(\'\')">↩️ অ্যাপের আসল রং</button>' : ''}</div>`;
}
function setUColor(c) { try { c ? localStorage.setItem('ucolor', c) : localStorage.removeItem('ucolor'); } catch (e) {} applyTheme(); profile(); }

// =====================================================================
//  🤖 প্রশ্ন বানান: AI (Claude/ChatGPT) দিয়ে বানিয়ে সরাসরি অ্যাপে বসানো
// =====================================================================
const QG_TOPICS = ['ট্রাফিক সাইন', 'রাস্তার নিয়ম ও ট্রাফিক আইন', 'ড্রাইভিং লাইসেন্স ও BRTA', 'গাড়ির যন্ত্রাংশ ও যত্ন', 'নিরাপদ ড্রাইভিং ও প্রাথমিক চিকিৎসা', 'বাংলা ভাষা ও সাহিত্য', 'ইংরেজি', 'গণিত', 'সাধারণ জ্ঞান', 'বাংলাদেশ বিষয়াবলি', 'সরকারি চাকরির প্রস্তুতি'];
function qgForm() {
  const secs = _acache.content.filter(c => c.type === 'section');
  return `<div class="cx"><b>১️⃣ AI এর জন্য নির্দেশ বানান</b><div class="hint">বিষয় ও সংখ্যা বেছে "কপি করুন" চাপুন। তারপর Claude বা ChatGPT-তে পেস্ট করুন। ওরা ঠিক অ্যাপের ধরনে প্রশ্ন বানিয়ে দেবে।</div>
    <select class="inp" id="qg_topic">${QG_TOPICS.map(t => `<option>${t}</option>`).join('')}</select>
    <input class="inp" id="qg_own" placeholder="অথবা নিজের বিষয় লিখুন (ঐচ্ছিক)">
    <div class="two"><select class="inp" id="qg_kind"><option value="mcq">MCQ (৪টি উত্তর)</option><option value="w">লিখিত প্রশ্ন-উত্তর</option></select><input class="inp" id="qg_n" type="number" min="1" max="50" value="20" placeholder="কয়টি"></div>
    <select class="inp" id="qg_lv"><option>সহজ</option><option selected>মাঝারি</option><option>কঠিন</option></select>
    <button class="btn" onclick="qgCopy()">📋 নির্দেশ কপি করুন</button><textarea class="inp" id="qg_prompt" rows="4" readonly style="display:none;font-size:12px"></textarea></div>
  <div class="cx"><b>২️⃣ MCQ বসান</b><div class="hint">AI যা বানিয়েছে তা এখানে পেস্ট করুন। প্রতি লাইনে একটি প্রশ্ন:<br>প্রশ্ন | উত্তর১ | উত্তর২ | উত্তর৩ | উত্তর৪ | সঠিক নম্বর | ব্যাখ্যা</div>
    <textarea class="inp" id="qg_mcq" rows="7" placeholder="এখানে পেস্ট করুন"></textarea><button class="btn" onclick="qgMcq()">✅ কুইজে যোগ করুন</button></div>
  <div class="cx"><b>৩️⃣ লিখিত প্রশ্ন-উত্তর বসান</b><div class="hint">প্রতি লাইনে: প্রশ্ন | উত্তর। এগুলো একটি সুন্দর পাতা হয়ে আপনার বেছে নেওয়া জায়গায় বসবে।</div>
    <input class="inp" id="qg_title" placeholder="পাতার নাম (যেমন: ট্রাফিক আইনের লিখিত প্রশ্ন)">
    <select class="inp" id="qg_parent">${parentOpts('')}</select>
    <textarea class="inp" id="qg_w" rows="7" placeholder="প্রশ্ন | উত্তর"></textarea><button class="btn" onclick="qgWritten()">✅ পাতা বানান</button></div>
  <div id="ad_msg" class="warn" style="display:none"></div>`;
}
function qgCopy() {
  const t = gv('qg_own') || gv('qg_topic'), n = Math.max(1, Math.min(50, +gv('qg_n') || 20)), lv = gv('qg_lv'), mcq = gv('qg_kind') === 'mcq';
  const p = mcq
    ? `বাংলাদেশের ড্রাইভার ও চাকরিপ্রার্থীদের জন্য "${t}" বিষয়ে ${n}টি ${lv} মানের MCQ প্রশ্ন বানাও। ভাষা সহজ বাংলা।\nনিয়ম: প্রতিটি প্রশ্ন আলাদা লাইনে, ঠিক এই ছকে, আর কিছু লিখবে না (কোনো নম্বর, তারা বা বাড়তি কথা নয়):\nপ্রশ্ন | উত্তর১ | উত্তর২ | উত্তর৩ | উত্তর৪ | সঠিক উত্তরের নম্বর (১ থেকে ৪) | এক লাইনে ব্যাখ্যা\nতথ্য অবশ্যই নির্ভুল ও বাংলাদেশের আইন অনুযায়ী হতে হবে। নিশ্চিত না হলে সেই প্রশ্ন বাদ দাও।`
    : `বাংলাদেশের ড্রাইভার ও চাকরিপ্রার্থীদের জন্য "${t}" বিষয়ে ${n}টি ${lv} মানের লিখিত প্রশ্ন ও সংক্ষিপ্ত উত্তর বানাও। ভাষা সহজ বাংলা।\nনিয়ম: প্রতিটি প্রশ্ন আলাদা লাইনে, ঠিক এই ছকে, আর কিছু লিখবে না:\nপ্রশ্ন | উত্তর\nতথ্য অবশ্যই নির্ভুল ও বাংলাদেশের আইন অনুযায়ী হতে হবে। নিশ্চিত না হলে সেই প্রশ্ন বাদ দাও।`;
  const ta = document.getElementById('qg_prompt'); ta.value = p; ta.style.display = 'block'; ta.select();
  let ok = false; try { if (navigator.clipboard && navigator.clipboard.writeText) { navigator.clipboard.writeText(p); ok = true; } else ok = document.execCommand('copy'); } catch (e) { try { ok = document.execCommand('copy'); } catch (e2) {} }
  adMsg(ok ? '✅ কপি হয়েছে। এবার Claude বা ChatGPT-তে পেস্ট করুন।' : 'উপরের লেখাটি চেপে ধরে কপি করুন।');
}
async function qgMcq() {
  const m = await sme(); if (!m) return; const rows = parseQuizBulk(gv('qg_mcq'));
  if (!rows.length) return adMsg('কোনো প্রশ্ন বোঝা যায়নি। প্রতি লাইনে: প্রশ্ন | উত্তর১ | উত্তর২ | উত্তর৩ | উত্তর৪ | সঠিক নম্বর');
  if (rows.length > 100) return adMsg('একবারে সর্বোচ্চ ১০০টি।');
  try { adMsg('⏳ যোগ হচ্ছে...'); for (const r of rows) await m.f.F.addDoc(m.f.F.collection(m.f.db, 'content'), {type: 'quiz', title: r.q, body: '', url: '', pub: true, by: m.u.uid, quiz: {o: r.o, a: r.a, e: r.e}, createdAt: m.f.F.serverTimestamp()}); await refreshContent(); document.getElementById('qg_mcq').value = ''; adMsg('✅ ' + rows.length + 'টি প্রশ্ন কুইজে যোগ হয়েছে। মডেল টেস্টে দেখুন।'); } catch (e) { adMsg('⚠️ যোগ হয়নি।'); }
}
async function qgWritten() {
  const m = await sme(); if (!m) return; const title = gv('qg_title'), parent = gv('qg_parent');
  if (!title) return adMsg('পাতার নাম দিন।');
  const rows = gv('qg_w').split('\n').map(l => l.split(/[|｜]/).map(x => x.trim())).filter(p => p.length >= 2 && p[0] && p[1]);
  if (!rows.length) return adMsg('কোনো প্রশ্ন বোঝা যায়নি। প্রতি লাইনে: প্রশ্ন | উত্তর');
  const body = rows.map((p, i) => `**${i + 1}. ${p[0]}**\n${p.slice(1).join(' | ')}\n`).join('\n');
  if (body.length > 19000) return adMsg('অনেক বড় হয়ে গেছে। দুই ভাগে দিন।');
  try { adMsg('⏳ বানানো হচ্ছে...'); await m.f.F.addDoc(m.f.F.collection(m.f.db, 'content'), {type: 'node', parent, title: title.slice(0, 150), titleEn: '', body, bodyEn: '', lang: 'auto', color: '#0369a1', ic: '📝', ord: 0, mt: 'none', url: '', pub: true, by: m.u.uid, createdAt: m.f.F.serverTimestamp()}); await refreshContent(); document.getElementById('qg_w').value = ''; adMsg('✅ ' + rows.length + 'টি প্রশ্নের পাতা তৈরি। "' + keyName(parent) + '" এর ভিতরে দেখুন।'); } catch (e) { adMsg('⚠️ হয়নি।'); }
}

// =====================================================================
//  অ্যাডমিন লগইন (সাইড মেনুর 🛡️ অ্যাডমিন থেকে, বা ওয়েবে ঠিকানার শেষে #admin)
// =====================================================================
function adminLoginView() {
  const web = !(window.Capacitor && Capacitor.isNativePlatform && Capacitor.isNativePlatform());
  return `<div class="cx"><b>🛡️ অ্যাডমিন লগইন</b><div class="hint">শুধু অ্যাডমিনের আইডি দিয়ে ঢোকা যায়। মোবাইল নম্বর ও পাসওয়ার্ড দিন।</div>
    <input class="inp" id="al_id" placeholder="মোবাইল নম্বর (01XXXXXXXXX) বা ইমেইল" autocomplete="username"><input class="inp" id="al_pw" type="password" placeholder="পাসওয়ার্ড" autocomplete="current-password">
    <div id="ad_msg" class="warn" style="display:none"></div>
    <button class="btn" onclick="adLogin()">🔐 লগইন</button>
    ${web ? '<button class="btn" style="background:#4285f4;margin-top:8px" onclick="adGoogle()">🔵 Gmail (Google) দিয়ে লগইন</button>' : ''}</div>
    <div class="cx"><b>প্রথমবার?</b><div class="hint">আগে "লগইন ও ব্যাকআপ" পাতা থেকে অ্যাডমিনের মোবাইল নম্বর দিয়ে নতুন অ্যাকাউন্ট খুলুন। তারপর এখানে এসে লগইন করুন। নম্বরটি অ্যাডমিন তালিকায় থাকলে প্যানেল নিজে খুলে যাবে।</div>
    <button class="btn sm" onclick="open_('account')">নতুন অ্যাকাউন্ট খুলুন</button></div>`;
}
async function adLogin() {
  const id = gv('al_id'), pw = document.getElementById('al_pw').value; if (!id || !pw) return adMsg('আইডি ও পাসওয়ার্ড দিন।');
  try { adMsg('⏳ অপেক্ষা করুন...'); await cloudLogin(id, pw); try { await upsertProfile(); } catch (e) {} adminPage(); } catch (e) { adMsg('⚠️ ' + (typeof cloudErr === 'function' ? cloudErr(e) : 'লগইন হয়নি।')); }
}
async function adGoogle() {
  try {
    adMsg('⏳ Google খুলছে...'); const f = await fb(); const r = await f.A.signInWithPopup(f.auth, new f.A.GoogleAuthProvider()); const u = r.user;
    setCloudInfo({id: u.email || u.uid, name: u.displayName || '', uid: u.uid, last: 0}); try { await upsertProfile(); } catch (e) {} adminPage();
  } catch (e) {
    const c = e && e.code; adMsg('⚠️ ' + (c === 'auth/popup-closed-by-user' ? 'লগইন বাতিল হয়েছে।' : c === 'auth/unauthorized-domain' ? 'এই ওয়েবসাইটের ঠিকানা Firebase এর Authorized domains এ যোগ করা হয়নি।' : c === 'auth/operation-not-allowed' ? 'Firebase এ Google লগইন চালু করা হয়নি।' : 'Google লগইন হয়নি। আবার চেষ্টা করুন।'));
  }
}
